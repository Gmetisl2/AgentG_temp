window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "7XMqbg7KvuvqpYApGJraKmjlonSZvB4ZvkKwkB3P",
      "createdAt" : "2024-12-03T20:29:38.174Z",
      "lastSeenAt" : "2024-12-03T20:29:38.176Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "LLoR3XivslJQFP6NrpMG2UPt3jxVQtpDhtWdTSVM",
      "createdAt" : "2024-12-11T01:18:12.314Z",
      "lastSeenAt" : "2024-12-11T01:18:12.316Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "129032",
      "token" : "GsnOKmFit0Km8LPODUbWgM7CqGCecFrXlddNHRDN",
      "createdAt" : "2024-12-03T20:52:42.731Z",
      "lastSeenAt" : "2024-12-11T02:58:46.277Z",
      "clientApplicationName" : "Twitter for iPhone (Twitter)"
    }
  }
]