window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1864044295654912000",
      "screenNameChange" : {
        "changedAt" : "2024-12-03T20:30:33.000Z",
        "changedFrom" : "Gmetis125359",
        "changedTo" : "gMetisl2"
      }
    }
  }
]