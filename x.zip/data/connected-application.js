window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "privacyPolicyUrl" : "https://www.periscope.tv/privacy",
        "termsAndConditionsUrl" : "https://www.periscope.tv/tos"
      },
      "name" : "Periscope Web",
      "description" : "Periscope Web",
      "permissions" : [
        "read",
        "write",
        "emailaddress"
      ],
      "approvedAt" : "2025-01-11T00:04:41.000Z",
      "id" : "12766916"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : ""
      },
      "name" : "Twitter for iPhone",
      "description" : "Twitter for iPhone",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2024-12-11T02:58:46.000Z",
      "id" : "129032"
    }
  }
]