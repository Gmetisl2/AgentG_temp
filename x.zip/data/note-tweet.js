window.YTD.note_tweet.part0 = [
  {
    "noteTweet" : {
      "noteTweetId" : "1878231282179858432",
      "updatedAt" : "2025-01-12T00:03:28.000Z",
      "lifecycle" : {
        "value" : "1",
        "name" : "Active",
        "originalName" : "Active",
        "annotations" : { }
      },
      "createdAt" : "2025-01-12T00:03:28.000Z",
      "core" : {
        "styletags" : [
          {
            "styleTypes" : [
              {
                "value" : "0",
                "name" : "Bold",
                "originalName" : "BOLD",
                "annotations" : { }
              }
            ],
            "fromIndex" : "108",
            "toIndex" : "131"
          },
          {
            "styleTypes" : [
              {
                "value" : "0",
                "name" : "Bold",
                "originalName" : "BOLD",
                "annotations" : { }
              }
            ],
            "fromIndex" : "148",
            "toIndex" : "159"
          }
        ],
        "urls" : [ ],
        "text" : "If you are not selected for the testing, don't worry! You can still enjoy juicy boosted LP rewards from the Hercules Dex Nitro Pool, offering almost 200% APR. Your participation and support are invaluable, and there will be many more opportunities to get involved and earn rewards.\n\n@TheHerculesDEX #LP",
        "mentions" : [
          {
            "screenName" : "TheHerculesDEX",
            "fromIndex" : "283",
            "toIndex" : "298"
          }
        ],
        "cashtags" : [ ],
        "hashtags" : [
          {
            "text" : "LP",
            "fromIndex" : "299",
            "toIndex" : "302"
          }
        ]
      }
    }
  },
  {
    "noteTweet" : {
      "noteTweetId" : "1878231278870515712",
      "updatedAt" : "2025-01-12T00:03:27.000Z",
      "lifecycle" : {
        "value" : "1",
        "name" : "Active",
        "originalName" : "Active",
        "annotations" : { }
      },
      "createdAt" : "2025-01-12T00:03:27.000Z",
      "core" : {
        "styletags" : [ ],
        "urls" : [ ],
        "text" : "🚀 Exciting News! 🚀\n\nWe're thrilled to announce the 3-day beta testing launch for gMetis, starting on January 12th evening! 🏅\n\nWe've selected the 5 most engaging community members for this exclusive opportunity. 🎉 Additionally, we're inviting some high-profile ecosystem individuals from Metis and other projects to join us. Invitations will be sent to a separate testing group on Telegram.\n\nThe reward pool for the 3-day testing event is 4M $gMetis (~5 Metis). \n\n🚨 Be aware of scammers! 🚨 We will make an announcement in the official Telegram group before opening the test group.\n\nStay active and engaged for a chance to participate and earn boosted rewards! 🌟\n\nThis is just the beginning of our journey. Let’s make history together! 🚀💪\n\n#BetaTesting #gMetis #MetisL2 #AIAgents #Web3 #CommunityEngagement",
        "mentions" : [ ],
        "cashtags" : [
          {
            "text" : "gMetis",
            "fromIndex" : "441",
            "toIndex" : "448"
          }
        ],
        "hashtags" : [
          {
            "text" : "BetaTesting",
            "fromIndex" : "738",
            "toIndex" : "750"
          },
          {
            "text" : "gMetis",
            "fromIndex" : "751",
            "toIndex" : "758"
          },
          {
            "text" : "MetisL2",
            "fromIndex" : "759",
            "toIndex" : "767"
          },
          {
            "text" : "AIAgents",
            "fromIndex" : "768",
            "toIndex" : "777"
          },
          {
            "text" : "Web3",
            "fromIndex" : "778",
            "toIndex" : "783"
          },
          {
            "text" : "CommunityEngagement",
            "fromIndex" : "784",
            "toIndex" : "804"
          }
        ]
      }
    }
  },
  {
    "noteTweet" : {
      "noteTweetId" : "1877843412944068608",
      "updatedAt" : "2025-01-10T22:22:12.000Z",
      "lifecycle" : {
        "value" : "1",
        "name" : "Active",
        "originalName" : "Active",
        "annotations" : { }
      },
      "createdAt" : "2025-01-10T22:22:12.000Z",
      "core" : {
        "urls" : [ ],
        "text" : "🚀 ** It’s been an incredibly busy few days!** \nWe're excited to share some major milestones as we did at @Web3_Matters show today\n\nFirst, we've secured our first official partnership with the top-tier web3 gaming project @explore_thecore. 🎮 We're thrilled to provide AaaS (Agent as a Service) to their community, enhancing social engagement. 💬\n\nSecondly, we've joined forces with the @MetisGovernance team to offer AaaS and elevate awareness on @MetisL2 governance topics. 🗳️✨\n\nLastly, we're gearing up for a 3-day beta testing launch this Sunday, with boosted rewards! 🏅 We encourage all top CEG voters to update their profiles with (now or current) Telegram username.\n\nStay tuned for more updates! 🌟 This is just the beginning of our exciting journey. Let’s keep pushing forward together. 🚀💪 #gMetis #MetisL2 #AIAgents #Web3 #Gaming #CommunityEngagement",
        "mentions" : [
          {
            "screenName" : "Web3_Matters",
            "fromIndex" : "105",
            "toIndex" : "118"
          },
          {
            "screenName" : "explore_thecore",
            "fromIndex" : "221",
            "toIndex" : "237"
          },
          {
            "screenName" : "MetisGovernance",
            "fromIndex" : "384",
            "toIndex" : "400"
          },
          {
            "screenName" : "MetisL2",
            "fromIndex" : "445",
            "toIndex" : "453"
          }
        ],
        "cashtags" : [ ],
        "hashtags" : [
          {
            "text" : "gMetis",
            "fromIndex" : "794",
            "toIndex" : "801"
          },
          {
            "text" : "MetisL2",
            "fromIndex" : "802",
            "toIndex" : "810"
          },
          {
            "text" : "AIAgents",
            "fromIndex" : "811",
            "toIndex" : "820"
          },
          {
            "text" : "Web3",
            "fromIndex" : "821",
            "toIndex" : "826"
          },
          {
            "text" : "Gaming",
            "fromIndex" : "827",
            "toIndex" : "834"
          },
          {
            "text" : "CommunityEngagement",
            "fromIndex" : "835",
            "toIndex" : "855"
          }
        ]
      }
    }
  }
]