window.YTD.verified_organization.part0 = [
  {
    "verifiedOrganization" : { }
  }
]