window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "10.75",
        "udid" : "F1ACA15C-2E78-4E02-AA8A-615328FA02BF",
        "deviceType" : "Twitter for iOS",
        "token" : "UoOwyKUZmR2fxazw7vxv4M3Hw3EwdzdcUueMQHndJGE=",
        "updatedDate" : "2025.01.10",
        "createdDate" : "2024.12.11"
      }
    }
  },
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "10.75",
        "udid" : "F1ACA15C-2E78-4E02-AA8A-615328FA02BF",
        "deviceType" : "Twitter for iOS",
        "token" : "bNYyw40pQEpSZSXxX8a/0piBszQjz4Z+wCVw8z3Obag=",
        "updatedDate" : "2025.01.09",
        "createdDate" : "2024.12.11"
      }
    }
  }
]