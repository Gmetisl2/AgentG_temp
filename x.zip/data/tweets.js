window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1878231282280505620"
          ],
          "editableUntil" : "2025-01-12T01:03:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1878231282280505620/photo/1",
            "indices" : [
              "274",
              "297"
            ],
            "url" : "https://t.co/M2KA0UkdjQ",
            "media_url" : "http://pbs.twimg.com/media/GhDRNUHWgAEHVqq.jpg",
            "id_str" : "1878231071281545217",
            "id" : "1878231071281545217",
            "media_url_https" : "https://pbs.twimg.com/media/GhDRNUHWgAEHVqq.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "293",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "166",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1432",
                "h" : "350",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/M2KA0UkdjQ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "297"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1878231278987935992",
      "id_str" : "1878231282280505620",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1878231282280505620",
      "in_reply_to_status_id" : "1878231278987935992",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 12 00:03:28 +0000 2025",
      "favorited" : false,
      "full_text" : "If you are not selected for the testing, don't worry! You can still enjoy juicy boosted LP rewards from the Hercules Dex Nitro Pool, offering almost 200% APR. Your participation and support are invaluable, and there will be many more opportunities to get involved and earn… https://t.co/M2KA0UkdjQ",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1878231282280505620/photo/1",
            "indices" : [
              "274",
              "297"
            ],
            "url" : "https://t.co/M2KA0UkdjQ",
            "media_url" : "http://pbs.twimg.com/media/GhDRNUHWgAEHVqq.jpg",
            "id_str" : "1878231071281545217",
            "id" : "1878231071281545217",
            "media_url_https" : "https://pbs.twimg.com/media/GhDRNUHWgAEHVqq.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "293",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "166",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1432",
                "h" : "350",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/M2KA0UkdjQ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1878231278987935992"
          ],
          "editableUntil" : "2025-01-12T01:03:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "270"
      ],
      "favorite_count" : "0",
      "id_str" : "1878231278987935992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1878231278987935992",
      "created_at" : "Sun Jan 12 00:03:27 +0000 2025",
      "favorited" : false,
      "full_text" : "🚀 Exciting News! 🚀\n\nWe're thrilled to announce the 3-day beta testing launch for gMetis, starting on January 12th evening! 🏅\n\nWe've selected the 5 most engaging community members for this exclusive opportunity. 🎉 Additionally, we're inviting some high-profile ecosystem…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877843413086732781"
          ],
          "editableUntil" : "2025-01-10T23:22:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Web3 Matters",
            "screen_name" : "Web3_Matters",
            "indices" : [
              "105",
              "118"
            ],
            "id_str" : "1625423467733479424",
            "id" : "1625423467733479424"
          },
          {
            "name" : "The CORE",
            "screen_name" : "explore_thecore",
            "indices" : [
              "221",
              "237"
            ],
            "id_str" : "1640266105850675200",
            "id" : "1640266105850675200"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "279"
      ],
      "favorite_count" : "32",
      "id_str" : "1877843413086732781",
      "truncated" : false,
      "retweet_count" : "9",
      "id" : "1877843413086732781",
      "created_at" : "Fri Jan 10 22:22:12 +0000 2025",
      "favorited" : false,
      "full_text" : "🚀 ** It’s been an incredibly busy few days!** \nWe're excited to share some major milestones as we did at @Web3_Matters show today\n\nFirst, we've secured our first official partnership with the top-tier web3 gaming project @explore_thecore. 🎮 We're thrilled to provide AaaS (Agent…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877833768422998396"
          ],
          "editableUntil" : "2025-01-10T22:43:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Tomas Drvo",
            "screen_name" : "tommi1881",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1451286547916107780",
            "id" : "1451286547916107780"
          },
          {
            "name" : "Natalia Ameline",
            "screen_name" : "Natalia_Ameline",
            "indices" : [
              "11",
              "27"
            ],
            "id_str" : "522851045",
            "id" : "522851045"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "28",
              "36"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Natalia Ameline",
            "screen_name" : "Natalia_Ameline",
            "indices" : [
              "104",
              "120"
            ],
            "id_str" : "522851045",
            "id" : "522851045"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1877833768422998396/photo/1",
            "indices" : [
              "176",
              "199"
            ],
            "url" : "https://t.co/3yhODBFvD9",
            "media_url" : "http://pbs.twimg.com/media/Gg9n27sXEAA1ULc.jpg",
            "id_str" : "1877833763071135744",
            "id" : "1877833763071135744",
            "media_url_https" : "https://pbs.twimg.com/media/Gg9n27sXEAA1ULc.jpg",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/3yhODBFvD9"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "199"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1877816434039943588",
      "id_str" : "1877833768422998396",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877833768422998396",
      "in_reply_to_status_id" : "1877816434039943588",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 10 21:43:53 +0000 2025",
      "favorited" : false,
      "full_text" : "@tommi1881 @Natalia_Ameline @MetisL2 Checked with the official team and relieved to confirm to you that @Natalia_Ameline is part of the team and nothing has changed on that :) https://t.co/3yhODBFvD9",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1877833768422998396/photo/1",
            "indices" : [
              "176",
              "199"
            ],
            "url" : "https://t.co/3yhODBFvD9",
            "media_url" : "http://pbs.twimg.com/media/Gg9n27sXEAA1ULc.jpg",
            "id_str" : "1877833763071135744",
            "id" : "1877833763071135744",
            "media_url_https" : "https://pbs.twimg.com/media/Gg9n27sXEAA1ULc.jpg",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/3yhODBFvD9"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877816434039943588"
          ],
          "editableUntil" : "2025-01-10T21:35:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tomas Drvo",
            "screen_name" : "tommi1881",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1451286547916107780",
            "id" : "1451286547916107780"
          },
          {
            "name" : "Natalia Ameline",
            "screen_name" : "Natalia_Ameline",
            "indices" : [
              "11",
              "27"
            ],
            "id_str" : "522851045",
            "id" : "522851045"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "109",
              "117"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "157"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1877800885570433057",
      "id_str" : "1877816434039943588",
      "in_reply_to_user_id" : "1451286547916107780",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877816434039943588",
      "in_reply_to_status_id" : "1877800885570433057",
      "created_at" : "Fri Jan 10 20:35:00 +0000 2025",
      "favorited" : false,
      "full_text" : "@tommi1881 @Natalia_Ameline As of my knowledge nothing changed but you might think about asking the official @MetisL2 team :)\nWe are a project based on Metis",
      "lang" : "en",
      "in_reply_to_screen_name" : "tommi1881",
      "in_reply_to_user_id_str" : "1451286547916107780"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877800036488122698"
          ],
          "editableUntil" : "2025-01-10T20:29:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The CORE",
            "screen_name" : "explore_thecore",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1640266105850675200",
            "id" : "1640266105850675200"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "17",
              "25"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1877797992704410082",
      "id_str" : "1877800036488122698",
      "in_reply_to_user_id" : "1640266105850675200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877800036488122698",
      "in_reply_to_status_id" : "1877797992704410082",
      "created_at" : "Fri Jan 10 19:29:51 +0000 2025",
      "favorited" : false,
      "full_text" : "@explore_thecore @MetisL2 🚀 🚀 🚀",
      "lang" : "qme",
      "in_reply_to_screen_name" : "explore_thecore",
      "in_reply_to_user_id_str" : "1640266105850675200"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877764836538318951"
          ],
          "editableUntil" : "2025-01-10T18:09:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Web3 Matters",
            "screen_name" : "Web3_Matters",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1625423467733479424",
            "id" : "1625423467733479424"
          },
          {
            "name" : "InsightX",
            "screen_name" : "InsightXnetwork",
            "indices" : [
              "14",
              "30"
            ],
            "id_str" : "1695891930280796160",
            "id" : "1695891930280796160"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "148"
      ],
      "favorite_count" : "4",
      "in_reply_to_status_id_str" : "1877760001986474253",
      "id_str" : "1877764836538318951",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877764836538318951",
      "in_reply_to_status_id" : "1877760001986474253",
      "created_at" : "Fri Jan 10 17:09:58 +0000 2025",
      "favorited" : false,
      "full_text" : "@Web3_Matters @InsightXnetwork Was just talking about the Bubblechart on your platform. \nWould be great to have Metis between the available networks",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877760001986474253"
          ],
          "editableUntil" : "2025-01-10T17:50:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Web3 Matters",
            "screen_name" : "Web3_Matters",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1625423467733479424",
            "id" : "1625423467733479424"
          },
          {
            "name" : "InsightX",
            "screen_name" : "InsightXnetwork",
            "indices" : [
              "14",
              "30"
            ],
            "id_str" : "1695891930280796160",
            "id" : "1695891930280796160"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1877756399188341074",
      "id_str" : "1877760001986474253",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877760001986474253",
      "in_reply_to_status_id" : "1877756399188341074",
      "created_at" : "Fri Jan 10 16:50:46 +0000 2025",
      "favorited" : false,
      "full_text" : "@Web3_Matters @InsightXnetwork",
      "lang" : "qam",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877756399188341074"
          ],
          "editableUntil" : "2025-01-10T17:36:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Web3 Matters",
            "screen_name" : "Web3_Matters",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1625423467733479424",
            "id" : "1625423467733479424"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/emdIgyrH3D",
            "expanded_url" : "http://app.insightx.network/bubblemaps",
            "display_url" : "app.insightx.network/bubblemaps",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1877748831405617406",
      "id_str" : "1877756399188341074",
      "in_reply_to_user_id" : "1625423467733479424",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877756399188341074",
      "in_reply_to_status_id" : "1877748831405617406",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 10 16:36:27 +0000 2025",
      "favorited" : false,
      "full_text" : "@Web3_Matters https://t.co/emdIgyrH3D",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Web3_Matters",
      "in_reply_to_user_id_str" : "1625423467733479424"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877754713073950799"
          ],
          "editableUntil" : "2025-01-10T17:29:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Trav 🇨🇦",
            "screen_name" : "Trav_hube_shirt",
            "indices" : [
              "38",
              "54"
            ],
            "id_str" : "1438971640239386625",
            "id" : "1438971640239386625"
          },
          {
            "name" : "cobi.bean",
            "screen_name" : "L2cobi",
            "indices" : [
              "55",
              "62"
            ],
            "id_str" : "1825933621322035200",
            "id" : "1825933621322035200"
          },
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "64",
              "74"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          },
          {
            "name" : "Muttis Dog",
            "screen_name" : "Muttis_MetisDog",
            "indices" : [
              "75",
              "91"
            ],
            "id_str" : "1767229975772663808",
            "id" : "1767229975772663808"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "92",
              "106"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/BtpbU2FE0d",
            "expanded_url" : "https://x.com/Web3_Matters/status/1877748831405617406",
            "display_url" : "x.com/Web3_Matters/s…",
            "indices" : [
              "122",
              "145"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "145"
      ],
      "favorite_count" : "14",
      "id_str" : "1877754713073950799",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1877754713073950799",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 10 16:29:45 +0000 2025",
      "favorited" : false,
      "full_text" : "We are having a great discussion with @Trav_hube_shirt @L2cobi  @0xQuantic @Muttis_MetisDog @MemAiOfficial . come join us https://t.co/BtpbU2FE0d",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877648290100990240"
          ],
          "editableUntil" : "2025-01-10T10:26:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1877646647435411540",
      "id_str" : "1877648290100990240",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877648290100990240",
      "in_reply_to_status_id" : "1877646647435411540",
      "created_at" : "Fri Jan 10 09:26:52 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisL2 We love you too Intern &lt;3",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877648126565126568"
          ],
          "editableUntil" : "2025-01-10T10:26:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "63",
              "71"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "8",
      "in_reply_to_status_id_str" : "1877630669901197605",
      "id_str" : "1877648126565126568",
      "in_reply_to_user_id" : "1854114889041874944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877648126565126568",
      "in_reply_to_status_id" : "1877630669901197605",
      "created_at" : "Fri Jan 10 09:26:13 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisForgeDev Time to reclaim the throne as the #1 factory on @MetisL2",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisForgeDev",
      "in_reply_to_user_id_str" : "1854114889041874944"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877463138691416170"
          ],
          "editableUntil" : "2025-01-09T22:11:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Trav 🇨🇦",
            "screen_name" : "Trav_hube_shirt",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1438971640239386625",
            "id" : "1438971640239386625"
          },
          {
            "name" : "cobi.bean",
            "screen_name" : "L2cobi",
            "indices" : [
              "17",
              "24"
            ],
            "id_str" : "1825933621322035200",
            "id" : "1825933621322035200"
          },
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "25",
              "35"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          },
          {
            "name" : "kevin cto",
            "screen_name" : "ctokev",
            "indices" : [
              "36",
              "43"
            ],
            "id_str" : "1867588777989828608",
            "id" : "1867588777989828608"
          },
          {
            "name" : "Muttis Dog",
            "screen_name" : "Muttis_MetisDog",
            "indices" : [
              "44",
              "60"
            ],
            "id_str" : "1767229975772663808",
            "id" : "1767229975772663808"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "146"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1877429439958544642",
      "id_str" : "1877463138691416170",
      "in_reply_to_user_id" : "1438971640239386625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877463138691416170",
      "in_reply_to_status_id" : "1877429439958544642",
      "created_at" : "Thu Jan 09 21:11:08 +0000 2025",
      "favorited" : false,
      "full_text" : "@Trav_hube_shirt @L2cobi @0xQuantic @ctokev @Muttis_MetisDog Excited to be the guest in your show. I’ll make sure to make it memorable tomorrow ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "Trav_hube_shirt",
      "in_reply_to_user_id_str" : "1438971640239386625"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877439660651069609"
          ],
          "editableUntil" : "2025-01-09T20:37:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "cobi.bean",
            "screen_name" : "L2cobi",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1825933621322035200",
            "id" : "1825933621322035200"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1877428730559070691",
      "id_str" : "1877439660651069609",
      "in_reply_to_user_id" : "1825933621322035200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877439660651069609",
      "in_reply_to_status_id" : "1877428730559070691",
      "created_at" : "Thu Jan 09 19:37:50 +0000 2025",
      "favorited" : false,
      "full_text" : "@L2cobi Challenge",
      "lang" : "en",
      "in_reply_to_screen_name" : "L2cobi",
      "in_reply_to_user_id_str" : "1825933621322035200"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877428063555751952"
          ],
          "editableUntil" : "2025-01-09T19:51:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "cobi.bean",
            "screen_name" : "L2cobi",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1825933621322035200",
            "id" : "1825933621322035200"
          },
          {
            "name" : "Trav 🇨🇦",
            "screen_name" : "Trav_hube_shirt",
            "indices" : [
              "8",
              "24"
            ],
            "id_str" : "1438971640239386625",
            "id" : "1438971640239386625"
          },
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "25",
              "35"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          },
          {
            "name" : "kevin cto",
            "screen_name" : "ctokev",
            "indices" : [
              "36",
              "43"
            ],
            "id_str" : "1867588777989828608",
            "id" : "1867588777989828608"
          },
          {
            "name" : "Muttis Dog",
            "screen_name" : "Muttis_MetisDog",
            "indices" : [
              "44",
              "60"
            ],
            "id_str" : "1767229975772663808",
            "id" : "1767229975772663808"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1877421992976007333",
      "id_str" : "1877428063555751952",
      "in_reply_to_user_id" : "1825933621322035200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877428063555751952",
      "in_reply_to_status_id" : "1877421992976007333",
      "created_at" : "Thu Jan 09 18:51:45 +0000 2025",
      "favorited" : false,
      "full_text" : "@L2cobi @Trav_hube_shirt @0xQuantic @ctokev @Muttis_MetisDog We have a lot to share!",
      "lang" : "en",
      "in_reply_to_screen_name" : "L2cobi",
      "in_reply_to_user_id_str" : "1825933621322035200"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877340216937079034"
          ],
          "editableUntil" : "2025-01-09T14:02:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Artemis",
            "screen_name" : "Artemisfinance",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1747168873441550336",
            "id" : "1747168873441550336"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/jQQ4ANonaW",
            "expanded_url" : "https://x.com/explore_thecore/status/1877325674664386796?s=46",
            "display_url" : "x.com/explore_thecor…",
            "indices" : [
              "31",
              "54"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1877338148138516522",
      "id_str" : "1877340216937079034",
      "in_reply_to_user_id" : "1747168873441550336",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1877340216937079034",
      "in_reply_to_status_id" : "1877338148138516522",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 09 13:02:41 +0000 2025",
      "favorited" : false,
      "full_text" : "@Artemisfinance Already here:\n\nhttps://t.co/jQQ4ANonaW",
      "lang" : "en",
      "in_reply_to_screen_name" : "Artemisfinance",
      "in_reply_to_user_id_str" : "1747168873441550336"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877328768831746060"
          ],
          "editableUntil" : "2025-01-09T13:17:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The CORE",
            "screen_name" : "explore_thecore",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1640266105850675200",
            "id" : "1640266105850675200"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "17",
              "25"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "62",
              "76"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "Metis Developers 🌿",
            "screen_name" : "MetisDevs",
            "indices" : [
              "78",
              "88"
            ],
            "id_str" : "1778079891663081472",
            "id" : "1778079891663081472"
          },
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "89",
              "99"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "4",
      "in_reply_to_status_id_str" : "1877325674664386796",
      "id_str" : "1877328768831746060",
      "in_reply_to_user_id" : "1640266105850675200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877328768831746060",
      "in_reply_to_status_id" : "1877325674664386796",
      "created_at" : "Thu Jan 09 12:17:12 +0000 2025",
      "favorited" : false,
      "full_text" : "@explore_thecore @MetisL2 Looking forward to work with you! \n\n@MetisForgeDev  @MetisDevs @0xQuantic",
      "lang" : "en",
      "in_reply_to_screen_name" : "explore_thecore",
      "in_reply_to_user_id_str" : "1640266105850675200"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877326864366137732"
          ],
          "editableUntil" : "2025-01-09T13:09:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "202",
              "209"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The CORE",
            "screen_name" : "explore_thecore",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1640266105850675200",
            "id" : "1640266105850675200"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "233",
              "241"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/4kCsDF7JHH",
            "expanded_url" : "https://x.com/explore_thecore/status/1877325674664386796",
            "display_url" : "x.com/explore_thecor…",
            "indices" : [
              "273",
              "296"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "296"
      ],
      "favorite_count" : "5",
      "id_str" : "1877326864366137732",
      "in_reply_to_user_id" : "1640266105850675200",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1877326864366137732",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 09 12:09:38 +0000 2025",
      "favorited" : false,
      "full_text" : "@explore_thecore is one of if not the best web3 gaming project we ever set our foot on. \nNow we are privileged to excited to announce our strategic partnership with them. 🤝\n\nWe are not only focusing on #gMetis only but the growth of @MetisL2 as a whole eco \n\n2025 LFG! 🔥 🚀 https://t.co/4kCsDF7JHH",
      "lang" : "en",
      "in_reply_to_screen_name" : "explore_thecore",
      "in_reply_to_user_id_str" : "1640266105850675200"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877323467852288213"
          ],
          "editableUntil" : "2025-01-09T12:56:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Arabcoin🌿𝕏",
            "screen_name" : "Iamarabcoin",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1534925673734852609",
            "id" : "1534925673734852609"
          },
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "13",
              "22"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "94",
              "103"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "162"
      ],
      "favorite_count" : "6",
      "in_reply_to_status_id_str" : "1877298559562715420",
      "id_str" : "1877323467852288213",
      "in_reply_to_user_id" : "1534925673734852609",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1877323467852288213",
      "in_reply_to_status_id" : "1877298559562715420",
      "created_at" : "Thu Jan 09 11:56:08 +0000 2025",
      "favorited" : false,
      "full_text" : "@Iamarabcoin @VestaDAO ┏━━┓┏━━┓┏━━┓┏━━ ┓\n┗━┓┃┃┏┓┃┗━┓┃┃ ┏━┛ \n┏━┛┃┃┃┃┃┏━┛┃┃ ┗━┓ \n┃  the year of @gMetisL2 🌿━┓┃\n┃┏━┛┃┃┃┃┃┏━┛┏ ┓┃┃\n┃┗━┓┃┗┛┃┃┗━┓┃ ┗┛┃\n┗━━┛┗━━┛┗━━┛┗━━ ┛",
      "lang" : "en",
      "in_reply_to_screen_name" : "Iamarabcoin",
      "in_reply_to_user_id_str" : "1534925673734852609"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877322911016440166"
          ],
          "editableUntil" : "2025-01-09T12:53:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Luca",
            "screen_name" : "jpeg_luciano",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1374278040990195712",
            "id" : "1374278040990195712"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1877316901896073664",
      "id_str" : "1877322911016440166",
      "in_reply_to_user_id" : "1374278040990195712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877322911016440166",
      "in_reply_to_status_id" : "1877316901896073664",
      "created_at" : "Thu Jan 09 11:53:55 +0000 2025",
      "favorited" : false,
      "full_text" : "@jpeg_luciano 💯That is why we build our business case on community rewarding AI Agent. 🤖",
      "lang" : "en",
      "in_reply_to_screen_name" : "jpeg_luciano",
      "in_reply_to_user_id_str" : "1374278040990195712"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877322561559670962"
          ],
          "editableUntil" : "2025-01-09T12:52:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "27",
      "id_str" : "1877322561559670962",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1877322561559670962",
      "created_at" : "Thu Jan 09 11:52:32 +0000 2025",
      "favorited" : false,
      "full_text" : "I don’t think anyone is ready for what’s coming now\n\nWait for it…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876943370397913124"
          ],
          "editableUntil" : "2025-01-08T11:45:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1876921892822561100",
      "id_str" : "1876943370397913124",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876943370397913124",
      "in_reply_to_status_id" : "1876921892822561100",
      "created_at" : "Wed Jan 08 10:45:46 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis fam",
      "lang" : "und",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876755049231053045"
          ],
          "editableUntil" : "2025-01-07T23:17:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "11",
              "18"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Developers 🌿",
            "screen_name" : "MetisDevs",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1778079891663081472",
            "id" : "1778079891663081472"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1876259028038451421",
      "id_str" : "1876755049231053045",
      "in_reply_to_user_id" : "1778079891663081472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876755049231053045",
      "in_reply_to_status_id" : "1876259028038451421",
      "created_at" : "Tue Jan 07 22:17:26 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisDevs #gMetis Indeed🌿",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisDevs",
      "in_reply_to_user_id_str" : "1778079891663081472"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876754723451089172"
          ],
          "editableUntil" : "2025-01-07T23:16:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "16",
              "23"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Artemis",
            "screen_name" : "Artemisfinance",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1747168873441550336",
            "id" : "1747168873441550336"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1876252379022074013",
      "id_str" : "1876754723451089172",
      "in_reply_to_user_id" : "1747168873441550336",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876754723451089172",
      "in_reply_to_status_id" : "1876252379022074013",
      "created_at" : "Tue Jan 07 22:16:09 +0000 2025",
      "favorited" : false,
      "full_text" : "@Artemisfinance #gMetis friends! Let's save the intern",
      "lang" : "en",
      "in_reply_to_screen_name" : "Artemisfinance",
      "in_reply_to_user_id_str" : "1747168873441550336"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876754463177732311"
          ],
          "editableUntil" : "2025-01-07T23:15:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "@Likeey™️",
            "screen_name" : "Liikeey",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "1248019709146079236",
            "id" : "1248019709146079236"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "213"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1876754379702710312",
      "id_str" : "1876754463177732311",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876754463177732311",
      "in_reply_to_status_id" : "1876754379702710312",
      "created_at" : "Tue Jan 07 22:15:07 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisForgeDev @Liikeey Than and just than I'd consider moving further that way - and even than you'd heavily rely on a platform unless you build your own... but than are you offering the comfort as in you vision?",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876754379702710312"
          ],
          "editableUntil" : "2025-01-07T23:14:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "@Likeey™️",
            "screen_name" : "Liikeey",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "1248019709146079236",
            "id" : "1248019709146079236"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "301"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1876754318163943496",
      "id_str" : "1876754379702710312",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876754379702710312",
      "in_reply_to_status_id" : "1876754318163943496",
      "created_at" : "Tue Jan 07 22:14:47 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisForgeDev @Liikeey First one must prove presence in a certain ecosystem. Not only MC wise but in social presence, being DOXed and Community Verified is another step. \nIn the topic of AI Agents open-source your project might offer elevated trust as well to make sure users can understand whats up.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876754318163943496"
          ],
          "editableUntil" : "2025-01-07T23:14:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "@Likeey™️",
            "screen_name" : "Liikeey",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "1248019709146079236",
            "id" : "1248019709146079236"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "289"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1876746638665863643",
      "id_str" : "1876754318163943496",
      "in_reply_to_user_id" : "1854114889041874944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876754318163943496",
      "in_reply_to_status_id" : "1876746638665863643",
      "created_at" : "Tue Jan 07 22:14:32 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisForgeDev @Liikeey I see more potential than those above. \nMight be a nice usecase though if there is interest/demand. \nFor now I believe (or maybe I'd just like to believe) there is still a great lack of trust in using tools other than well audited defi tools. This is a good thing 👇",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisForgeDev",
      "in_reply_to_user_id_str" : "1854114889041874944"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876570796174475630"
          ],
          "editableUntil" : "2025-01-07T11:05:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Muttis Dog",
            "screen_name" : "Muttis_MetisDog",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1767229975772663808",
            "id" : "1767229975772663808"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1876347790785462385",
      "id_str" : "1876570796174475630",
      "in_reply_to_user_id" : "1767229975772663808",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876570796174475630",
      "in_reply_to_status_id" : "1876347790785462385",
      "created_at" : "Tue Jan 07 10:05:17 +0000 2025",
      "favorited" : false,
      "full_text" : "@Muttis_MetisDog Gm doggo",
      "lang" : "en",
      "in_reply_to_screen_name" : "Muttis_MetisDog",
      "in_reply_to_user_id_str" : "1767229975772663808"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876570488950153219"
          ],
          "editableUntil" : "2025-01-07T11:04:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1876570488950153219/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/gjkzCLdiN3",
            "media_url" : "http://pbs.twimg.com/media/Ggrq6b5XQAAm8rg.jpg",
            "id_str" : "1876570484394901504",
            "id" : "1876570484394901504",
            "media_url_https" : "https://pbs.twimg.com/media/Ggrq6b5XQAAm8rg.jpg",
            "sizes" : {
              "large" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "534",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/gjkzCLdiN3"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1876559486174826720",
      "id_str" : "1876570488950153219",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876570488950153219",
      "in_reply_to_status_id" : "1876559486174826720",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jan 07 10:04:04 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisL2 Love all that 5 points there ;) https://t.co/gjkzCLdiN3",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1876570488950153219/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/gjkzCLdiN3",
            "media_url" : "http://pbs.twimg.com/media/Ggrq6b5XQAAm8rg.jpg",
            "id_str" : "1876570484394901504",
            "id" : "1876570484394901504",
            "media_url_https" : "https://pbs.twimg.com/media/Ggrq6b5XQAAm8rg.jpg",
            "sizes" : {
              "large" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "534",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/gjkzCLdiN3"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876210275910881535"
          ],
          "editableUntil" : "2025-01-06T11:12:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "4",
              "13"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1876210275910881535/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/CFKY8iwqqm",
            "media_url" : "http://pbs.twimg.com/media/GgmjTIDXYAEqSpw.jpg",
            "id_str" : "1876210268750962689",
            "id" : "1876210268750962689",
            "media_url_https" : "https://pbs.twimg.com/media/GgmjTIDXYAEqSpw.jpg",
            "sizes" : {
              "medium" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "511",
                "resize" : "fit"
              },
              "large" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/CFKY8iwqqm"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1875485314254581892",
      "id_str" : "1876210275910881535",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876210275910881535",
      "in_reply_to_status_id" : "1875485314254581892",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 06 10:12:42 +0000 2025",
      "favorited" : false,
      "full_text" : "lol @elonmusk too? Cheers! https://t.co/CFKY8iwqqm",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1876210275910881535/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/CFKY8iwqqm",
            "media_url" : "http://pbs.twimg.com/media/GgmjTIDXYAEqSpw.jpg",
            "id_str" : "1876210268750962689",
            "id" : "1876210268750962689",
            "media_url_https" : "https://pbs.twimg.com/media/GgmjTIDXYAEqSpw.jpg",
            "sizes" : {
              "medium" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "511",
                "resize" : "fit"
              },
              "large" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/CFKY8iwqqm"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876206127932916207"
          ],
          "editableUntil" : "2025-01-06T10:56:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "20",
              "28"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1876206127932916207/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/7eDU8jrjdt",
            "media_url" : "http://pbs.twimg.com/media/GgmfcYrXEAASOfu.png",
            "id_str" : "1876206029785993216",
            "id" : "1876206029785993216",
            "media_url_https" : "https://pbs.twimg.com/media/GgmfcYrXEAASOfu.png",
            "sizes" : {
              "medium" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "511",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/7eDU8jrjdt"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "id_str" : "1876206127932916207",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876206127932916207",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 06 09:56:13 +0000 2025",
      "favorited" : false,
      "full_text" : "@elonmusk  Cheers?\n\n@MetisL2 https://t.co/7eDU8jrjdt",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1876206127932916207/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/7eDU8jrjdt",
            "media_url" : "http://pbs.twimg.com/media/GgmfcYrXEAASOfu.png",
            "id_str" : "1876206029785993216",
            "id" : "1876206029785993216",
            "media_url_https" : "https://pbs.twimg.com/media/GgmfcYrXEAASOfu.png",
            "sizes" : {
              "medium" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "511",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "748",
                "h" : "562",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/7eDU8jrjdt"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876057461045785009"
          ],
          "editableUntil" : "2025-01-06T01:05:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "14",
              "22"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "167",
              "180"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "244"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1875939062571503651",
      "id_str" : "1876057461045785009",
      "in_reply_to_user_id" : "296606110",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1876057461045785009",
      "in_reply_to_status_id" : "1875939062571503651",
      "created_at" : "Mon Jan 06 00:05:28 +0000 2025",
      "favorited" : false,
      "full_text" : "@josefabregab @MetisL2 We have our beta test starting from 12.01 for the top 10 CEG contributor (yes we are Community Verified Project) and top 5 most engaging users.\n@josefabregab - Would you consider to be our celebrity guest for the testing?",
      "lang" : "en",
      "in_reply_to_screen_name" : "josefabregab",
      "in_reply_to_user_id_str" : "296606110"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875489328362877394"
          ],
          "editableUntil" : "2025-01-04T11:27:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "vitalik.eth",
            "screen_name" : "VitalikButerin",
            "indices" : [
              "7",
              "22"
            ],
            "id_str" : "295218901",
            "id" : "295218901"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "4",
      "in_reply_to_status_id_str" : "1875485314254581892",
      "id_str" : "1875489328362877394",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875489328362877394",
      "in_reply_to_status_id" : "1875485314254581892",
      "created_at" : "Sat Jan 04 10:27:55 +0000 2025",
      "favorited" : false,
      "full_text" : "Cheers @VitalikButerin !",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875485314254581892"
          ],
          "editableUntil" : "2025-01-04T11:11:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1875485314254581892/photo/1",
            "indices" : [
              "55",
              "78"
            ],
            "url" : "https://t.co/8IhKydHvKO",
            "media_url" : "http://pbs.twimg.com/media/GgcP3UzW4AAR8BM.png",
            "id_str" : "1875485212974440448",
            "id" : "1875485212974440448",
            "media_url_https" : "https://pbs.twimg.com/media/GgcP3UzW4AAR8BM.png",
            "sizes" : {
              "medium" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "534",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/8IhKydHvKO"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "27",
      "id_str" : "1875485314254581892",
      "truncated" : false,
      "retweet_count" : "12",
      "id" : "1875485314254581892",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jan 04 10:11:58 +0000 2025",
      "favorited" : false,
      "full_text" : "Hol' up\nI know that guy but what's in his hand?\nHmm... https://t.co/8IhKydHvKO",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1875485314254581892/photo/1",
            "indices" : [
              "55",
              "78"
            ],
            "url" : "https://t.co/8IhKydHvKO",
            "media_url" : "http://pbs.twimg.com/media/GgcP3UzW4AAR8BM.png",
            "id_str" : "1875485212974440448",
            "id" : "1875485212974440448",
            "media_url_https" : "https://pbs.twimg.com/media/GgcP3UzW4AAR8BM.png",
            "sizes" : {
              "medium" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "534",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "701",
                "h" : "550",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/8IhKydHvKO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875287432767402105"
          ],
          "editableUntil" : "2025-01-03T22:05:39.784Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "90",
              "97"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Big•Såmmie",
            "screen_name" : "BigSammieFx",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1777371555804196867",
            "id" : "1777371555804196867"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "114",
              "123"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1875287432767402105",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875287432767402105",
      "created_at" : "Fri Jan 03 21:05:39 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @BigSammieFx: 𝐀𝐬 𝐚 𝐜𝐫𝐲𝐩𝐭𝐨 𝐞𝐧𝐭𝐡𝐮𝐬𝐢𝐚𝐬𝐭, 𝐈'𝐦 𝐚𝐥𝐰𝐚𝐲𝐬 𝐨𝐧 𝐭𝐡𝐞 𝐥𝐨𝐨𝐤𝐨𝐮𝐭 𝐟𝐨𝐫 𝐞𝐱𝐜𝐢𝐭𝐢𝐧𝐠 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬. #gMetis 𝐢𝐬 𝐨𝐧𝐞 𝐨𝐟 𝐭𝐡𝐞𝐦.\n@gMetisl2 \n\n🧵👇 https://t.…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875210150476456105"
          ],
          "editableUntil" : "2025-01-03T16:58:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "9",
              "23"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1875195866388267218",
      "id_str" : "1875210150476456105",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875210150476456105",
      "in_reply_to_status_id" : "1875195866388267218",
      "created_at" : "Fri Jan 03 15:58:34 +0000 2025",
      "favorited" : false,
      "full_text" : "@MetisL2 @MetisForgeDev Absolutely pumped to be here! 🤖 🚀",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875204929390100732"
          ],
          "editableUntil" : "2025-01-03T16:37:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "14",
              "22"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Chainlink",
            "screen_name" : "chainlink",
            "indices" : [
              "23",
              "33"
            ],
            "id_str" : "1530530365",
            "id" : "1530530365"
          },
          {
            "name" : "Aave",
            "screen_name" : "aave",
            "indices" : [
              "34",
              "39"
            ],
            "id_str" : "867100084248469505",
            "id" : "867100084248469505"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1875173367990415513",
      "id_str" : "1875204929390100732",
      "in_reply_to_user_id" : "296606110",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875204929390100732",
      "in_reply_to_status_id" : "1875173367990415513",
      "created_at" : "Fri Jan 03 15:37:49 +0000 2025",
      "favorited" : false,
      "full_text" : "@josefabregab @MetisL2 @chainlink @aave 🔥 🔥 🔥",
      "lang" : "qme",
      "in_reply_to_screen_name" : "josefabregab",
      "in_reply_to_user_id_str" : "296606110"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875204547540644028"
          ],
          "editableUntil" : "2025-01-03T16:36:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "itsTerris",
            "screen_name" : "itsTerris",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "3157592785",
            "id" : "3157592785"
          },
          {
            "name" : "QWERTY23",
            "screen_name" : "alessan00412670",
            "indices" : [
              "11",
              "27"
            ],
            "id_str" : "1456275370836054018",
            "id" : "1456275370836054018"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "28",
              "42"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1875197703958962378",
      "id_str" : "1875204547540644028",
      "in_reply_to_user_id" : "3157592785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875204547540644028",
      "in_reply_to_status_id" : "1875197703958962378",
      "created_at" : "Fri Jan 03 15:36:18 +0000 2025",
      "favorited" : false,
      "full_text" : "@itsTerris @alessan00412670 @MetisForgeDev Haha indeed :D",
      "lang" : "et",
      "in_reply_to_screen_name" : "itsTerris",
      "in_reply_to_user_id_str" : "3157592785"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875080474584088810"
          ],
          "editableUntil" : "2025-01-03T08:23:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "17",
              "24"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Netswap",
            "screen_name" : "netswapofficial",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1437329962848030722",
            "id" : "1437329962848030722"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1875025660332400975",
      "id_str" : "1875080474584088810",
      "in_reply_to_user_id" : "1437329962848030722",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875080474584088810",
      "in_reply_to_status_id" : "1875025660332400975",
      "created_at" : "Fri Jan 03 07:23:17 +0000 2025",
      "favorited" : false,
      "full_text" : "@netswapofficial #gMetis",
      "lang" : "qme",
      "in_reply_to_screen_name" : "netswapofficial",
      "in_reply_to_user_id_str" : "1437329962848030722"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874233483180335329"
          ],
          "editableUntil" : "2025-01-01T00:17:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "8",
      "in_reply_to_status_id_str" : "1874231033660661960",
      "id_str" : "1874233483180335329",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1874233483180335329",
      "in_reply_to_status_id" : "1874231033660661960",
      "created_at" : "Tue Dec 31 23:17:38 +0000 2024",
      "favorited" : false,
      "full_text" : "A happy and fruitful 2025 to all!",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874231033660661960"
          ],
          "editableUntil" : "2025-01-01T00:07:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "22",
              "29"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Monkex Coffee Shop Club ☕",
            "screen_name" : "MonkexNFT",
            "indices" : [
              "53",
              "63"
            ],
            "id_str" : "1528413809030971393",
            "id" : "1528413809030971393"
          },
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "64",
              "73"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "74",
              "82"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "82"
      ],
      "favorite_count" : "12",
      "id_str" : "1874231033660661960",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1874231033660661960",
      "created_at" : "Tue Dec 31 23:07:54 +0000 2024",
      "favorited" : false,
      "full_text" : "Let this be the first #gMetis gVesta gMonkex and all\n@MonkexNFT @VestaDAO @MetisL2",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874186616291631517"
          ],
          "editableUntil" : "2024-12-31T21:11:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Smartonstuff 🌿",
            "screen_name" : "smartonstuff",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1873765966875701248",
            "id" : "1873765966875701248"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1874186251362095561",
      "id_str" : "1874186616291631517",
      "in_reply_to_user_id" : "1873765966875701248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874186616291631517",
      "in_reply_to_status_id" : "1874186251362095561",
      "created_at" : "Tue Dec 31 20:11:24 +0000 2024",
      "favorited" : false,
      "full_text" : "@smartonstuff That was deep",
      "lang" : "en",
      "in_reply_to_screen_name" : "smartonstuff",
      "in_reply_to_user_id_str" : "1873765966875701248"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874185507774853439"
          ],
          "editableUntil" : "2024-12-31T21:07:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1874163698769740114",
      "id_str" : "1874185507774853439",
      "in_reply_to_user_id" : "1439548673495547908",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874185507774853439",
      "in_reply_to_status_id" : "1874163698769740114",
      "created_at" : "Tue Dec 31 20:07:00 +0000 2024",
      "favorited" : false,
      "full_text" : "@0xQuantic Let’s make it great 👍",
      "lang" : "en",
      "in_reply_to_screen_name" : "0xQuantic",
      "in_reply_to_user_id_str" : "1439548673495547908"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874103531495710947"
          ],
          "editableUntil" : "2024-12-31T15:41:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "28",
              "35"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Arabcoin🌿𝕏",
            "screen_name" : "Iamarabcoin",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1534925673734852609",
            "id" : "1534925673734852609"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1874015122307637688",
      "id_str" : "1874103531495710947",
      "in_reply_to_user_id" : "1534925673734852609",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874103531495710947",
      "in_reply_to_status_id" : "1874015122307637688",
      "created_at" : "Tue Dec 31 14:41:15 +0000 2024",
      "favorited" : false,
      "full_text" : "@Iamarabcoin Make it count: #gMetis",
      "lang" : "en",
      "in_reply_to_screen_name" : "Iamarabcoin",
      "in_reply_to_user_id_str" : "1534925673734852609"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874102582110806247"
          ],
          "editableUntil" : "2024-12-31T15:37:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1874040440447451520",
      "id_str" : "1874102582110806247",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874102582110806247",
      "in_reply_to_status_id" : "1874040440447451520",
      "created_at" : "Tue Dec 31 14:37:29 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis brothers! 🫡",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873933086150582639"
          ],
          "editableUntil" : "2024-12-31T04:23:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Netswap",
            "screen_name" : "netswapofficial",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1437329962848030722",
            "id" : "1437329962848030722"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1873915827919217086",
      "id_str" : "1873933086150582639",
      "in_reply_to_user_id" : "1437329962848030722",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873933086150582639",
      "in_reply_to_status_id" : "1873915827919217086",
      "created_at" : "Tue Dec 31 03:23:58 +0000 2024",
      "favorited" : false,
      "full_text" : "@netswapofficial gMetis",
      "lang" : "lt",
      "in_reply_to_screen_name" : "netswapofficial",
      "in_reply_to_user_id_str" : "1437329962848030722"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873624089006612713"
          ],
          "editableUntil" : "2024-12-30T07:56:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1873624086825623970",
      "id_str" : "1873624089006612713",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873624089006612713",
      "in_reply_to_status_id" : "1873624086825623970",
      "created_at" : "Mon Dec 30 06:56:07 +0000 2024",
      "favorited" : false,
      "full_text" : "6/6\nDoes that take more time? ⏰ Yes\n\nDoes it give us the flexibility to create new services? 🙌 Also yes\n\nDoes it give us the advantage to customize and react to community feedback instantly? 💨🚀 Hell yeah!\n\nIs it actually fun and educating also for the team? 📚 Yeaaaah!!! 🎉",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873624086825623970"
          ],
          "editableUntil" : "2024-12-30T07:56:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1873624083419763076",
      "id_str" : "1873624086825623970",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873624086825623970",
      "in_reply_to_status_id" : "1873624083419763076",
      "created_at" : "Mon Dec 30 06:56:07 +0000 2024",
      "favorited" : false,
      "full_text" : "5/6\nAnd finally… Please remember, while we might not move first because we build everything from scratch on our own: 👇",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873624083419763076"
          ],
          "editableUntil" : "2024-12-30T07:56:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "265"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1873624080643228023",
      "id_str" : "1873624083419763076",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873624083419763076",
      "in_reply_to_status_id" : "1873624080643228023",
      "created_at" : "Mon Dec 30 06:56:06 +0000 2024",
      "favorited" : false,
      "full_text" : "4/6\n📱 **Get Ready for Some Fun on Telegram!** 📱\n\nWe’ve been cooking up some cool stuff, including a thrilling Telegram quiz! Get ready to test your knowledge\n\n💰 **Rewards Await!** 💰\n\nOur reward pool is 5M gMetis (~$200). \nAnd we kick off today (30.12) at 7PM UTC!!!",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873624080643228023"
          ],
          "editableUntil" : "2024-12-30T07:56:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "277"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1873624078055317518",
      "id_str" : "1873624080643228023",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873624080643228023",
      "in_reply_to_status_id" : "1873624078055317518",
      "created_at" : "Mon Dec 30 06:56:05 +0000 2024",
      "favorited" : false,
      "full_text" : "3/6\n 🚀 **Introducing Agent as a Service (AaaS)!** 🚀\n\nOur new cross-chain service is on the horizon launched from Metis! We’ll be providing the same exceptional capabilities to projects on Metis and other chains, expanding our footprint and forging partnerships.\nMore info later",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873624078055317518"
          ],
          "editableUntil" : "2024-12-30T07:56:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "271"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1873624075060576458",
      "id_str" : "1873624078055317518",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873624078055317518",
      "in_reply_to_status_id" : "1873624075060576458",
      "created_at" : "Mon Dec 30 06:56:05 +0000 2024",
      "favorited" : false,
      "full_text" : "2/6\nTop 10 CEG contributors are encouraged to update their CEG profile stating their Telegram username as their profile name (can be a brand new TG user for the sake of privacy).\n\nTop 5 engaging users to be announced before the test launch. Stay tuned for more updates! 🚀",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873624075060576458"
          ],
          "editableUntil" : "2024-12-30T07:56:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "252"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1873624072363651232",
      "id_str" : "1873624075060576458",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873624075060576458",
      "in_reply_to_status_id" : "1873624072363651232",
      "created_at" : "Mon Dec 30 06:56:04 +0000 2024",
      "favorited" : false,
      "full_text" : "1/6\n\nWe’re thrilled to announce that beta testing for AgentG 🤖 will commence not later than 12.01.2025! A small group of users (Top 10 CEG contributors and Top 5 engaging members) will get exclusive early access to this fully functional agent for 3days",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873624072363651232"
          ],
          "editableUntil" : "2024-12-30T07:56:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "252"
      ],
      "favorite_count" : "26",
      "id_str" : "1873624072363651232",
      "truncated" : false,
      "retweet_count" : "11",
      "id" : "1873624072363651232",
      "created_at" : "Mon Dec 30 06:56:03 +0000 2024",
      "favorited" : false,
      "full_text" : "🌟 **gMetis Friends!** 🌟\n\nHope you all had a nice Christmas season. We too… just got a bit busy 👇\n\nBeta testing for AgentG 🤖\n\nIntroducing Agent as a Service (AaaS) 🚀\n\nfun Telegram quiz coming today with some rewards! 👀\n\nFind out more in the full thread.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872770400092065842"
          ],
          "editableUntil" : "2024-12-27T23:23:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "83",
              "91"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1872761089584447689",
      "id_str" : "1872770400092065842",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1872770400092065842",
      "in_reply_to_status_id" : "1872761089584447689",
      "created_at" : "Fri Dec 27 22:23:52 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 One can be as good as the foundation it’s built on. \nThat’s why we are on @MetisL2",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872762425189253573"
          ],
          "editableUntil" : "2024-12-27T22:52:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1872762425189253573/photo/1",
            "indices" : [
              "22",
              "45"
            ],
            "url" : "https://t.co/rAlxF5CvYH",
            "media_url" : "http://pbs.twimg.com/media/Gf1jf7BWUAA9AGJ.jpg",
            "id_str" : "1872762420126437376",
            "id" : "1872762420126437376",
            "media_url_https" : "https://pbs.twimg.com/media/Gf1jf7BWUAA9AGJ.jpg",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/rAlxF5CvYH"
          }
        ],
        "hashtags" : [
          {
            "text" : "EnjoyTheLittleThings",
            "indices" : [
              "0",
              "21"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "17",
      "id_str" : "1872762425189253573",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1872762425189253573",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 27 21:52:11 +0000 2024",
      "favorited" : false,
      "full_text" : "#EnjoyTheLittleThings https://t.co/rAlxF5CvYH",
      "lang" : "qme",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1872762425189253573/photo/1",
            "indices" : [
              "22",
              "45"
            ],
            "url" : "https://t.co/rAlxF5CvYH",
            "media_url" : "http://pbs.twimg.com/media/Gf1jf7BWUAA9AGJ.jpg",
            "id_str" : "1872762420126437376",
            "id" : "1872762420126437376",
            "media_url_https" : "https://pbs.twimg.com/media/Gf1jf7BWUAA9AGJ.jpg",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/rAlxF5CvYH"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872738583876096477"
          ],
          "editableUntil" : "2024-12-27T21:17:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Gitcoin",
            "screen_name" : "gitcoin",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "856446453157376003",
            "id" : "856446453157376003"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1872738583876096477/photo/1",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/eDggV5Xh4y",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Gf1N0ClX0AA9yQP.jpg",
            "id_str" : "1872738576498151424",
            "id" : "1872738576498151424",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Gf1N0ClX0AA9yQP.jpg",
            "sizes" : {
              "small" : {
                "w" : "494",
                "h" : "498",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "494",
                "h" : "498",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "494",
                "h" : "498",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/eDggV5Xh4y"
          }
        ],
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1872418363768541271",
      "id_str" : "1872738583876096477",
      "in_reply_to_user_id" : "856446453157376003",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1872738583876096477",
      "in_reply_to_status_id" : "1872418363768541271",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 27 20:17:26 +0000 2024",
      "favorited" : false,
      "full_text" : "@gitcoin #gMetis https://t.co/eDggV5Xh4y",
      "lang" : "qme",
      "in_reply_to_screen_name" : "gitcoin",
      "in_reply_to_user_id_str" : "856446453157376003",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1872738583876096477/photo/1",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/eDggV5Xh4y",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Gf1N0ClX0AA9yQP.jpg",
            "id_str" : "1872738576498151424",
            "video_info" : {
              "aspect_ratio" : [
                "247",
                "249"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/Gf1N0ClX0AA9yQP.mp4"
                }
              ]
            },
            "id" : "1872738576498151424",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Gf1N0ClX0AA9yQP.jpg",
            "sizes" : {
              "small" : {
                "w" : "494",
                "h" : "498",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "494",
                "h" : "498",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "494",
                "h" : "498",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.x.com/eDggV5Xh4y"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872738149371420952"
          ],
          "editableUntil" : "2024-12-27T21:15:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1872576046681207098",
      "id_str" : "1872738149371420952",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1872738149371420952",
      "in_reply_to_status_id" : "1872576046681207098",
      "created_at" : "Fri Dec 27 20:15:43 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis we are already in 2025!",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872737590446588012"
          ],
          "editableUntil" : "2024-12-27T21:13:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/VCW1XUX3br",
            "expanded_url" : "https://t.me/gmetisio",
            "display_url" : "t.me/gmetisio",
            "indices" : [
              "144",
              "167"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "167"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1872737587762479314",
      "id_str" : "1872737590446588012",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1872737590446588012",
      "in_reply_to_status_id" : "1872737587762479314",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 27 20:13:30 +0000 2024",
      "favorited" : false,
      "full_text" : "Join us as we celebrate the holidays with knowledge, fun, and community spirit. Don’t miss this chance to be part of the gMetis experience! 🎉🎄\n\nhttps://t.co/VCW1XUX3br",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872737587762479314"
          ],
          "editableUntil" : "2024-12-27T21:13:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "256"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1872737584323150337",
      "id_str" : "1872737587762479314",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1872737587762479314",
      "in_reply_to_status_id" : "1872737584323150337",
      "created_at" : "Fri Dec 27 20:13:29 +0000 2024",
      "favorited" : false,
      "full_text" : "**Rewards**: Prizes include gMetis tokens (locked in SPNFT on Hercules DEX)\n\n**Eligibility &amp; Rules:**\n- Open to active gMetis Telegram community members.\n- Ensure one-day group participation before the contest.\n- Fair play and single-entry rules apply.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872737584323150337"
          ],
          "editableUntil" : "2024-12-27T21:13:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "270"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1872737581609439410",
      "id_str" : "1872737584323150337",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1872737584323150337",
      "in_reply_to_status_id" : "1872737581609439410",
      "created_at" : "Fri Dec 27 20:13:28 +0000 2024",
      "favorited" : false,
      "full_text" : "**Why Participate?**\n- Gain insights into blockchain and the Metis network.\n- Explore gMetis’ vision, AI agent, and innovative features.\n- Compete for exciting rewards while networking with like-minded enthusiasts.\n\n**Key Dates:**\n- **Contest**: December 30th-31st, 2024",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872737581609439410"
          ],
          "editableUntil" : "2024-12-27T21:13:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/VCW1XUXB0Z",
            "expanded_url" : "https://t.me/gmetisio",
            "display_url" : "t.me/gmetisio",
            "indices" : [
              "198",
              "221"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "221"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1872737579256418378",
      "id_str" : "1872737581609439410",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1872737581609439410",
      "in_reply_to_status_id" : "1872737579256418378",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 27 20:13:27 +0000 2024",
      "favorited" : false,
      "full_text" : "**Event Schedule:**\n- **Day 1**: Blockchain Fundamentals &amp; Metis Ecosystem Overview.\n- **Day 2**: Deep Dive into gMetis – Tokenomics, Vision, and AI Agent.\n\n**Platform**: gMetis Telegram Group\n\nhttps://t.co/VCW1XUXB0Z",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872737579256418378"
          ],
          "editableUntil" : "2024-12-27T21:13:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "247"
      ],
      "favorite_count" : "18",
      "id_str" : "1872737579256418378",
      "truncated" : false,
      "retweet_count" : "9",
      "id" : "1872737579256418378",
      "created_at" : "Fri Dec 27 20:13:27 +0000 2024",
      "favorited" : false,
      "full_text" : "🌟 **Announcing the gMetis Xmas Quiz Challenge!** 🌟\n\nJoin us for an engaging two-day event designed to educate, connect, and reward our growing community. Test your knowledge of blockchain, Metis Layer 2, and gMetis while earning exclusive rewards!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871332430201618589"
          ],
          "editableUntil" : "2024-12-24T00:09:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "36",
              "44"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "82"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1871330540336583153",
      "id_str" : "1871332430201618589",
      "in_reply_to_user_id" : "1439548673495547908",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871332430201618589",
      "in_reply_to_status_id" : "1871330540336583153",
      "created_at" : "Mon Dec 23 23:09:53 +0000 2024",
      "favorited" : false,
      "full_text" : "@0xQuantic We are here to make sure @MetisL2 will not be left out of that wave 🌊 🤖",
      "lang" : "en",
      "in_reply_to_screen_name" : "0xQuantic",
      "in_reply_to_user_id_str" : "1439548673495547908"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871332100529619321"
          ],
          "editableUntil" : "2024-12-24T00:08:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "dead_arbinaut (💙,🧡)",
            "screen_name" : "arbThunderpow",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1148478805645963264",
            "id" : "1148478805645963264"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "15",
              "30"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "67",
              "76"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "196"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1871331165195653259",
      "id_str" : "1871332100529619321",
      "in_reply_to_user_id" : "1148478805645963264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871332100529619321",
      "in_reply_to_status_id" : "1871331165195653259",
      "created_at" : "Mon Dec 23 23:08:35 +0000 2024",
      "favorited" : false,
      "full_text" : "@arbThunderpow @TheHerculesDEX We had some discussions around this @VestaDAO to appear on the Metis morning show in January. That would give a great platform for live questions. What do you think?",
      "lang" : "en",
      "in_reply_to_screen_name" : "arbThunderpow",
      "in_reply_to_user_id_str" : "1148478805645963264"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871329946490024254"
          ],
          "editableUntil" : "2024-12-24T00:00:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "dead_arbinaut (💙,🧡)",
            "screen_name" : "arbThunderpow",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1148478805645963264",
            "id" : "1148478805645963264"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "15",
              "30"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "148"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1871329521322078249",
      "id_str" : "1871329946490024254",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871329946490024254",
      "in_reply_to_status_id" : "1871329521322078249",
      "created_at" : "Mon Dec 23 23:00:01 +0000 2024",
      "favorited" : false,
      "full_text" : "@arbThunderpow @TheHerculesDEX All I can say that we are looking at an extremely hot period now!  So have a seat, grab a popcorn and let’s ride! 🔥 🤖",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871329521322078249"
          ],
          "editableUntil" : "2024-12-23T23:58:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "dead_arbinaut (💙,🧡)",
            "screen_name" : "arbThunderpow",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1148478805645963264",
            "id" : "1148478805645963264"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "15",
              "30"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "306"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1871328424842711526",
      "id_str" : "1871329521322078249",
      "in_reply_to_user_id" : "1148478805645963264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871329521322078249",
      "in_reply_to_status_id" : "1871328424842711526",
      "created_at" : "Mon Dec 23 22:58:20 +0000 2024",
      "favorited" : false,
      "full_text" : "@arbThunderpow @TheHerculesDEX Thanks for the question \nWe are nicely progressing while also making sure to react to community feedback as well about current resources.\nWhile we have our main focus on the development of the agent it is also important to take some time off for the family during Christmas 🎄",
      "lang" : "en",
      "in_reply_to_screen_name" : "arbThunderpow",
      "in_reply_to_user_id_str" : "1148478805645963264"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871324977255137604"
          ],
          "editableUntil" : "2024-12-23T23:40:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "46",
              "61"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/mvznbo90QQ",
            "expanded_url" : "https://app.hercules.exchange/nitro/0x9075C241521E4AF8a81CEa6e65B084D834803183",
            "display_url" : "app.hercules.exchange/nitro/0x9075C2…",
            "indices" : [
              "119",
              "142"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "142"
      ],
      "favorite_count" : "14",
      "id_str" : "1871324977255137604",
      "truncated" : false,
      "retweet_count" : "7",
      "id" : "1871324977255137604",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 23 22:40:16 +0000 2024",
      "favorited" : false,
      "full_text" : "Is it Christmas already?! 🎄 \n\nLP providers on @TheHerculesDEX can enjoy from today the boosted Nitro pool rewards. 🎁 \n\nhttps://t.co/mvznbo90QQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871223281929589131"
          ],
          "editableUntil" : "2024-12-23T16:56:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "MARIO",
            "screen_name" : "MDPC62",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "588767621",
            "id" : "588767621"
          },
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "8",
              "21"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "22",
              "30"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "31",
              "40"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          },
          {
            "name" : "pumpetribe",
            "screen_name" : "pumpe_meme",
            "indices" : [
              "41",
              "52"
            ],
            "id_str" : "1848478910729883649",
            "id" : "1848478910729883649"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "53",
              "67"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          },
          {
            "name" : "Medusa",
            "screen_name" : "medusa_metis",
            "indices" : [
              "68",
              "81"
            ],
            "id_str" : "1843804342698065920",
            "id" : "1843804342698065920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1871221101935972371",
      "id_str" : "1871223281929589131",
      "in_reply_to_user_id" : "588767621",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871223281929589131",
      "in_reply_to_status_id" : "1871221101935972371",
      "created_at" : "Mon Dec 23 15:56:10 +0000 2024",
      "favorited" : false,
      "full_text" : "@MDPC62 @josefabregab @MetisL2 @VestaDAO @pumpe_meme @MemAiOfficial @medusa_metis 🔥 🔥",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MDPC62",
      "in_reply_to_user_id_str" : "588767621"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871131958459482263"
          ],
          "editableUntil" : "2024-12-23T10:53:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "10",
              "17"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1871095097942495258",
      "id_str" : "1871131958459482263",
      "in_reply_to_user_id" : "1747259142182674432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871131958459482263",
      "in_reply_to_status_id" : "1871095097942495258",
      "created_at" : "Mon Dec 23 09:53:17 +0000 2024",
      "favorited" : false,
      "full_text" : "@VestaDAO #gMetis",
      "lang" : "qme",
      "in_reply_to_screen_name" : "VestaDAO",
      "in_reply_to_user_id_str" : "1747259142182674432"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870879881124344247"
          ],
          "editableUntil" : "2024-12-22T18:11:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgents",
            "indices" : [
              "134",
              "143"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "144",
              "152"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/KEW6xyJXZ4",
            "expanded_url" : "https://x.com/0xQuantic/status/1870851839710630096",
            "display_url" : "x.com/0xQuantic/stat…",
            "indices" : [
              "159",
              "182"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "182"
      ],
      "favorite_count" : "8",
      "id_str" : "1870879881124344247",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1870879881124344247",
      "possibly_sensitive" : false,
      "created_at" : "Sun Dec 22 17:11:37 +0000 2024",
      "favorited" : false,
      "full_text" : "Honestly it’s not that complicated to succeed in life, in crypto, at work or in school - just find a genius and follow what he does 👇\n#AIAgents @MetisL2 #2025 https://t.co/KEW6xyJXZ4",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870877530754027577"
          ],
          "editableUntil" : "2024-12-22T18:02:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1870851839710630096",
      "id_str" : "1870877530754027577",
      "in_reply_to_user_id" : "1439548673495547908",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870877530754027577",
      "in_reply_to_status_id" : "1870851839710630096",
      "created_at" : "Sun Dec 22 17:02:17 +0000 2024",
      "favorited" : false,
      "full_text" : "@0xQuantic Why do I feel extremely excited reading that?",
      "lang" : "en",
      "in_reply_to_screen_name" : "0xQuantic",
      "in_reply_to_user_id_str" : "1439548673495547908"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870561679890870300"
          ],
          "editableUntil" : "2024-12-21T21:07:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1870053773344743533",
      "id_str" : "1870561679890870300",
      "in_reply_to_user_id" : "1854114889041874944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870561679890870300",
      "in_reply_to_status_id" : "1870053773344743533",
      "created_at" : "Sat Dec 21 20:07:12 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisForgeDev Bring it on!",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisForgeDev",
      "in_reply_to_user_id_str" : "1854114889041874944"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870482368559247643"
          ],
          "editableUntil" : "2024-12-21T15:52:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "0",
              "7"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/9F4IhKJGaT",
            "expanded_url" : "https://x.com/TheHerculesDEX/status/1870473627197669717",
            "display_url" : "x.com/TheHerculesDEX…",
            "indices" : [
              "21",
              "44"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "3",
      "id_str" : "1870482368559247643",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1870482368559247643",
      "possibly_sensitive" : false,
      "created_at" : "Sat Dec 21 14:52:03 +0000 2024",
      "favorited" : false,
      "full_text" : "#gMetis\n\nlet’s build https://t.co/9F4IhKJGaT",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870480333264842827"
          ],
          "editableUntil" : "2024-12-21T15:43:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "84",
              "92"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "156"
      ],
      "favorite_count" : "16",
      "id_str" : "1870480333264842827",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1870480333264842827",
      "created_at" : "Sat Dec 21 14:43:57 +0000 2024",
      "favorited" : false,
      "full_text" : "🚀 Something new is on the horizon. 🌟 something you've never seen before not just on @MetisL2 but in crypto as a whole😲✨\n\nGet ready to see history being made",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870455112378057063"
          ],
          "editableUntil" : "2024-12-21T14:03:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1870418154280693950",
      "id_str" : "1870455112378057063",
      "in_reply_to_user_id" : "1439548673495547908",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870455112378057063",
      "in_reply_to_status_id" : "1870418154280693950",
      "created_at" : "Sat Dec 21 13:03:44 +0000 2024",
      "favorited" : false,
      "full_text" : "@0xQuantic So am I  🔥 🔥",
      "lang" : "en",
      "in_reply_to_screen_name" : "0xQuantic",
      "in_reply_to_user_id_str" : "1439548673495547908"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870242658087502142"
          ],
          "editableUntil" : "2024-12-20T23:59:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Gitcoin",
            "screen_name" : "gitcoin",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "856446453157376003",
            "id" : "856446453157376003"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "10"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1870218984966009190",
      "id_str" : "1870242658087502142",
      "in_reply_to_user_id" : "856446453157376003",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870242658087502142",
      "in_reply_to_status_id" : "1870218984966009190",
      "created_at" : "Fri Dec 20 22:59:31 +0000 2024",
      "favorited" : false,
      "full_text" : "@gitcoin 👀",
      "lang" : "qme",
      "in_reply_to_screen_name" : "gitcoin",
      "in_reply_to_user_id_str" : "856446453157376003"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870205440400723971"
          ],
          "editableUntil" : "2024-12-20T21:31:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "cobi.bean",
            "screen_name" : "L2cobi",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1825933621322035200",
            "id" : "1825933621322035200"
          },
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "8",
              "17"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1870183741143802354",
      "id_str" : "1870205440400723971",
      "in_reply_to_user_id" : "1825933621322035200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870205440400723971",
      "in_reply_to_status_id" : "1870183741143802354",
      "created_at" : "Fri Dec 20 20:31:38 +0000 2024",
      "favorited" : false,
      "full_text" : "@L2cobi @VestaDAO Hot stuff 🔥",
      "lang" : "en",
      "in_reply_to_screen_name" : "L2cobi",
      "in_reply_to_user_id_str" : "1825933621322035200"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870179817439801805"
          ],
          "editableUntil" : "2024-12-20T19:49:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1870174231020941545",
      "id_str" : "1870179817439801805",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870179817439801805",
      "in_reply_to_status_id" : "1870174231020941545",
      "created_at" : "Fri Dec 20 18:49:49 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 You can count on us!",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870142344420331563"
          ],
          "editableUntil" : "2024-12-20T17:20:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Maverick 🧱",
            "screen_name" : "wavymaverick",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "743148071131951104",
            "id" : "743148071131951104"
          },
          {
            "name" : "Maverick 🧱",
            "screen_name" : "wavymaverick",
            "indices" : [
              "36",
              "49"
            ],
            "id_str" : "743148071131951104",
            "id" : "743148071131951104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1870140619865133517",
      "id_str" : "1870142344420331563",
      "in_reply_to_user_id" : "743148071131951104",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1870142344420331563",
      "in_reply_to_status_id" : "1870140619865133517",
      "created_at" : "Fri Dec 20 16:20:55 +0000 2024",
      "favorited" : false,
      "full_text" : "@wavymaverick Fantastic description @wavymaverick ! Happy to have you in our circle!",
      "lang" : "en",
      "in_reply_to_screen_name" : "wavymaverick",
      "in_reply_to_user_id_str" : "743148071131951104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870142080615358558"
          ],
          "editableUntil" : "2024-12-20T17:19:52.235Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Maverick 🧱",
            "screen_name" : "wavymaverick",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "743148071131951104",
            "id" : "743148071131951104"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "104",
              "113"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1870142080615358558",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870142080615358558",
      "created_at" : "Fri Dec 20 16:19:52 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @wavymaverick: 81% of web3 projects fail due to poor community engagement and lack of transparency.\n\n@gMetisl2 is solving this with a mi…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870133352927207572"
          ],
          "editableUntil" : "2024-12-20T16:45:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "BePrometheus",
            "screen_name" : "Be_Prometheus",
            "indices" : [
              "19",
              "33"
            ],
            "id_str" : "1859231095356870656",
            "id" : "1859231095356870656"
          },
          {
            "name" : "Nextmate.AI",
            "screen_name" : "nextmate_ai",
            "indices" : [
              "38",
              "50"
            ],
            "id_str" : "1812735318480805889",
            "id" : "1812735318480805889"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/F8UkBuBRSa",
            "expanded_url" : "https://x.com/MetisGovernance/status/1870124702229836278",
            "display_url" : "x.com/MetisGovernanc…",
            "indices" : [
              "223",
              "246"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1870133352927207572/photo/1",
            "indices" : [
              "247",
              "270"
            ],
            "url" : "https://t.co/2XQpV6Jvvg",
            "media_url" : "http://pbs.twimg.com/media/GfQMXy5W4AASh_2.jpg",
            "id_str" : "1870133348204470272",
            "id" : "1870133348204470272",
            "media_url_https" : "https://pbs.twimg.com/media/GfQMXy5W4AASh_2.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "668",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "737",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "737",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/2XQpV6Jvvg"
          }
        ],
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "92",
              "99"
            ]
          },
          {
            "text" : "L2",
            "indices" : [
              "209",
              "212"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "270"
      ],
      "favorite_count" : "7",
      "id_str" : "1870133352927207572",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1870133352927207572",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 20 15:45:11 +0000 2024",
      "favorited" : false,
      "full_text" : "Congratulations to @Be_Prometheus and @nextmate_ai and of course our fantastic community at #gMetis.\n\nThis is a giant step for us! Thank you for your support with over 20000 votes!!\n\nLet’s build the future of #L2 together! https://t.co/F8UkBuBRSa https://t.co/2XQpV6Jvvg",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1870133352927207572/photo/1",
            "indices" : [
              "247",
              "270"
            ],
            "url" : "https://t.co/2XQpV6Jvvg",
            "media_url" : "http://pbs.twimg.com/media/GfQMXy5W4AASh_2.jpg",
            "id_str" : "1870133348204470272",
            "id" : "1870133348204470272",
            "media_url_https" : "https://pbs.twimg.com/media/GfQMXy5W4AASh_2.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "668",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "737",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "737",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/2XQpV6Jvvg"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870091062355653028"
          ],
          "editableUntil" : "2024-12-20T13:57:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1870036504094884245",
      "id_str" : "1870091062355653028",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870091062355653028",
      "in_reply_to_status_id" : "1870036504094884245",
      "created_at" : "Fri Dec 20 12:57:08 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 gMetis",
      "lang" : "lt",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870026689826189776"
          ],
          "editableUntil" : "2024-12-20T09:41:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "22",
              "29"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Metis Hub ( fan)",
            "screen_name" : "MetishubETH",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "970227426671452160",
            "id" : "970227426671452160"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "13",
              "21"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1869736225424441502",
      "id_str" : "1870026689826189776",
      "in_reply_to_user_id" : "970227426671452160",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870026689826189776",
      "in_reply_to_status_id" : "1869736225424441502",
      "created_at" : "Fri Dec 20 08:41:20 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetishubETH @MetisL2 $gMetis 🌿 we are here!",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetishubETH",
      "in_reply_to_user_id_str" : "970227426671452160"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870026266570616996"
          ],
          "editableUntil" : "2024-12-20T09:39:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "gVesta",
            "indices" : [
              "10",
              "17"
            ]
          },
          {
            "text" : "gMetis",
            "indices" : [
              "20",
              "27"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1870005601603821621",
      "id_str" : "1870026266570616996",
      "in_reply_to_user_id" : "1747259142182674432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870026266570616996",
      "in_reply_to_status_id" : "1870005601603821621",
      "created_at" : "Fri Dec 20 08:39:40 +0000 2024",
      "favorited" : false,
      "full_text" : "@VestaDAO $gVesta 🌿\n$gMetis 🌿",
      "lang" : "qme",
      "in_reply_to_screen_name" : "VestaDAO",
      "in_reply_to_user_id_str" : "1747259142182674432"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869893885092315315"
          ],
          "editableUntil" : "2024-12-20T00:53:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "153"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1869893882328101116",
      "id_str" : "1869893885092315315",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869893885092315315",
      "in_reply_to_status_id" : "1869893882328101116",
      "created_at" : "Thu Dec 19 23:53:37 +0000 2024",
      "favorited" : false,
      "full_text" : "4️⃣ What's next?\nStay tuned for more updates as we continue to innovate and contribute to the Metis ecosystem. Your support is crucial in this journey! 🌟",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869893882328101116"
          ],
          "editableUntil" : "2024-12-20T00:53:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgents",
            "indices" : [
              "205",
              "214"
            ]
          },
          {
            "text" : "Innovation",
            "indices" : [
              "215",
              "226"
            ]
          }
        ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "197",
              "204"
            ]
          }
        ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "226"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1869893880088317985",
      "id_str" : "1869893882328101116",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869893882328101116",
      "in_reply_to_status_id" : "1869893880088317985",
      "created_at" : "Thu Dec 19 23:53:37 +0000 2024",
      "favorited" : false,
      "full_text" : "3️⃣ Why it matters:\nBeing an Approved CVP means we are recognized for our contribution to the Metis ecosystem. It highlights our commitment to transparency, security, and community-driven growth.\n\n$gMetis #AIAgents #Innovation",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869893880088317985"
          ],
          "editableUntil" : "2024-12-20T00:53:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "209"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1869893877777281085",
      "id_str" : "1869893880088317985",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869893880088317985",
      "in_reply_to_status_id" : "1869893877777281085",
      "created_at" : "Thu Dec 19 23:53:36 +0000 2024",
      "favorited" : false,
      "full_text" : "2️⃣ What is a CVP?\nA Community Verified Project (CVP) is a project that has been vetted and approved by the community through the CEG program. This status signifies trust, transparency, and community support2.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869893877777281085"
          ],
          "editableUntil" : "2024-12-20T00:53:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CEG",
            "indices" : [
              "229",
              "233"
            ]
          },
          {
            "text" : "CVP",
            "indices" : [
              "234",
              "238"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "238"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1869893875239645599",
      "id_str" : "1869893877777281085",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869893877777281085",
      "in_reply_to_status_id" : "1869893875239645599",
      "created_at" : "Thu Dec 19 23:53:36 +0000 2024",
      "favorited" : false,
      "full_text" : "1️⃣ What is CEG?\nThe Community Ecosystem Governance (CEG) program on Metis empowers the community to vote on and verify projects. This decentralized framework ensures that the community has a real say in shaping the ecosystem1.\n\n#CEG #CVP",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869893875239645599"
          ],
          "editableUntil" : "2024-12-20T00:53:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "107",
              "115"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/J8I2EwI6SV",
            "expanded_url" : "https://snapshot.box/#/s:metislayer2.eth/proposal/0xa78367dca7840d111d1762c55bcabf18c600e7cb3783d4b766c7f821e4a9a33a",
            "display_url" : "snapshot.box/#/s:metislayer…",
            "indices" : [
              "228",
              "251"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "15",
      "id_str" : "1869893875239645599",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1869893875239645599",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 19 23:53:35 +0000 2024",
      "favorited" : false,
      "full_text" : "🚀 It is official!!! 🚀\n\nWith over 20,000 votes and nearly 600 unique wallets, we are now an Approved CVP on @MetisL2! 🎉✨\n\nThis is a huge milestone for our community, and we couldn't have done it without your amazing support! 🙌💪\n\nhttps://t.co/J8I2EwI6SV\n\nLearn more below ⬇️",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869764243710693810"
          ],
          "editableUntil" : "2024-12-19T16:18:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "10",
              "17"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Driezmann The flying Dutchman",
            "screen_name" : "DriesT99",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "785325583",
            "id" : "785325583"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1869764115276980342",
      "id_str" : "1869764243710693810",
      "in_reply_to_user_id" : "785325583",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869764243710693810",
      "in_reply_to_status_id" : "1869764115276980342",
      "created_at" : "Thu Dec 19 15:18:28 +0000 2024",
      "favorited" : false,
      "full_text" : "@DriesT99 $gMetis dude!",
      "lang" : "en",
      "in_reply_to_screen_name" : "DriesT99",
      "in_reply_to_user_id_str" : "785325583"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869764142292402424"
          ],
          "editableUntil" : "2024-12-19T16:18:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "15",
              "22"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "rekt 🌿",
            "screen_name" : "cypherpunk669",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1433279433369010177",
            "id" : "1433279433369010177"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1869320593688125561",
      "id_str" : "1869764142292402424",
      "in_reply_to_user_id" : "1433279433369010177",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869764142292402424",
      "in_reply_to_status_id" : "1869320593688125561",
      "created_at" : "Thu Dec 19 15:18:04 +0000 2024",
      "favorited" : false,
      "full_text" : "@cypherpunk669 $gMetis friend!",
      "lang" : "en",
      "in_reply_to_screen_name" : "cypherpunk669",
      "in_reply_to_user_id_str" : "1433279433369010177"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869719386300555377"
          ],
          "editableUntil" : "2024-12-19T13:20:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Competition",
            "indices" : [
              "15",
              "27"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "4",
      "in_reply_to_status_id_str" : "1869677730436202831",
      "id_str" : "1869719386300555377",
      "in_reply_to_user_id" : "1854114889041874944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869719386300555377",
      "in_reply_to_status_id" : "1869677730436202831",
      "created_at" : "Thu Dec 19 12:20:14 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisForgeDev #Competition 🔥",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MetisForgeDev",
      "in_reply_to_user_id_str" : "1854114889041874944"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869568632658993588"
          ],
          "editableUntil" : "2024-12-19T03:21:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "17",
              "24"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Netswap",
            "screen_name" : "netswapofficial",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1437329962848030722",
            "id" : "1437329962848030722"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1869554716260356159",
      "id_str" : "1869568632658993588",
      "in_reply_to_user_id" : "1437329962848030722",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869568632658993588",
      "in_reply_to_status_id" : "1869554716260356159",
      "created_at" : "Thu Dec 19 02:21:11 +0000 2024",
      "favorited" : false,
      "full_text" : "@netswapofficial #gMetis",
      "lang" : "qme",
      "in_reply_to_screen_name" : "netswapofficial",
      "in_reply_to_user_id_str" : "1437329962848030722"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869560501057032332"
          ],
          "editableUntil" : "2024-12-19T02:48:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1869274521271763114",
      "id_str" : "1869560501057032332",
      "in_reply_to_user_id" : "1854114889041874944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869560501057032332",
      "in_reply_to_status_id" : "1869274521271763114",
      "created_at" : "Thu Dec 19 01:48:52 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisForgeDev Good stuff\nThe race already started!",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisForgeDev",
      "in_reply_to_user_id_str" : "1854114889041874944"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869558972661018890"
          ],
          "editableUntil" : "2024-12-19T02:42:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "16",
              "23"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1869514883378913415",
      "id_str" : "1869558972661018890",
      "in_reply_to_user_id" : "1637191643362107392",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869558972661018890",
      "in_reply_to_status_id" : "1869514883378913415",
      "created_at" : "Thu Dec 19 01:42:48 +0000 2024",
      "favorited" : false,
      "full_text" : "@TheHerculesDEX #gMetis friend\nHave you heard of me yet? 👀",
      "lang" : "en",
      "in_reply_to_screen_name" : "TheHerculesDEX",
      "in_reply_to_user_id_str" : "1637191643362107392"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869523466401333753"
          ],
          "editableUntil" : "2024-12-19T00:21:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "231",
              "238"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Blaze",
            "screen_name" : "blazing420s",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1002488333384212480",
            "id" : "1002488333384212480"
          },
          {
            "name" : "Blaze",
            "screen_name" : "blazing420s",
            "indices" : [
              "84",
              "96"
            ],
            "id_str" : "1002488333384212480",
            "id" : "1002488333384212480"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "240",
              "248"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "249",
              "263"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "263"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1869404492938256491",
      "id_str" : "1869523466401333753",
      "in_reply_to_user_id" : "1002488333384212480",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869523466401333753",
      "in_reply_to_status_id" : "1869404492938256491",
      "created_at" : "Wed Dec 18 23:21:43 +0000 2024",
      "favorited" : false,
      "full_text" : "@blazing420s 🚶‍♂️ Ok so let’s say you came to metis following those wise words from @blazing420s what now?\n👇\nCheck out the eco. 👀 Stake your Metis or lend it in aave and look around the mid and tiny caps -&gt; you’ll find us there #gMetis\n\n@MetisL2 @MetisForgeDev",
      "lang" : "en",
      "in_reply_to_screen_name" : "blazing420s",
      "in_reply_to_user_id_str" : "1002488333384212480"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869458109976203524"
          ],
          "editableUntil" : "2024-12-18T20:02:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "rekt 🌿",
            "screen_name" : "cypherpunk669",
            "indices" : [
              "26",
              "40"
            ],
            "id_str" : "1433279433369010177",
            "id" : "1433279433369010177"
          },
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "67",
              "77"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/AN66PTQ183",
            "expanded_url" : "https://x.com/cypherpunk669/status/1869106314594685331",
            "display_url" : "x.com/cypherpunk669/…",
            "indices" : [
              "123",
              "146"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "146"
      ],
      "favorite_count" : "8",
      "id_str" : "1869458109976203524",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1869458109976203524",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 18 19:02:00 +0000 2024",
      "favorited" : false,
      "full_text" : "Hearing some rumors about @cypherpunk669 hearing some rumors about @0xQuantic hearing some rumors about new Metis grants 👀 https://t.co/AN66PTQ183",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869428367881318433"
          ],
          "editableUntil" : "2024-12-18T18:03:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/qlmaE2Iv5n",
            "expanded_url" : "https://x.com/L2cobi/status/1869427494035829222",
            "display_url" : "x.com/L2cobi/status/…",
            "indices" : [
              "27",
              "50"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "6",
      "id_str" : "1869428367881318433",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1869428367881318433",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 18 17:03:49 +0000 2024",
      "favorited" : false,
      "full_text" : "we are live. Come join us! https://t.co/qlmaE2Iv5n",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869327415866257589"
          ],
          "editableUntil" : "2024-12-18T11:22:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/uSgeJOX0OK",
            "expanded_url" : "https://x.com/L2cobi/status/1869173322333757615",
            "display_url" : "x.com/L2cobi/status/…",
            "indices" : [
              "53",
              "76"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "15",
      "in_reply_to_status_id_str" : "1869320052773671074",
      "id_str" : "1869327415866257589",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1869327415866257589",
      "in_reply_to_status_id" : "1869320052773671074",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 18 10:22:41 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis\n Hope to see today on Metis CEG AMA https://t.co/uSgeJOX0OK",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869303319245803881"
          ],
          "editableUntil" : "2024-12-18T09:46:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "BePrometheus",
            "screen_name" : "Be_Prometheus",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1859231095356870656",
            "id" : "1859231095356870656"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "81",
              "89"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1869284779570745815",
      "id_str" : "1869303319245803881",
      "in_reply_to_user_id" : "1859231095356870656",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869303319245803881",
      "in_reply_to_status_id" : "1869284779570745815",
      "created_at" : "Wed Dec 18 08:46:55 +0000 2024",
      "favorited" : false,
      "full_text" : "@Be_Prometheus @MetisL2 Congratulations! Let’s build together the future of L2 - @MetisL2 step by step!",
      "lang" : "en",
      "in_reply_to_screen_name" : "Be_Prometheus",
      "in_reply_to_user_id_str" : "1859231095356870656"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869228998523564054"
          ],
          "editableUntil" : "2024-12-18T04:51:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1868949343236948016",
      "id_str" : "1869228998523564054",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869228998523564054",
      "in_reply_to_status_id" : "1868949343236948016",
      "created_at" : "Wed Dec 18 03:51:36 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis \nbuilding -&gt; building  -&gt; socials \naaand repeat 🔁",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869226632109867518"
          ],
          "editableUntil" : "2024-12-18T04:42:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Ama",
            "indices" : [
              "33",
              "37"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "39",
              "47"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Mx31xW201h",
            "expanded_url" : "https://x.com/L2cobi/status/1869173322333757615",
            "display_url" : "x.com/L2cobi/status/…",
            "indices" : [
              "48",
              "71"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "10",
      "id_str" : "1869226632109867518",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1869226632109867518",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 18 03:42:12 +0000 2024",
      "favorited" : false,
      "full_text" : "Set the reminders and get ready! #Ama\n\n@MetisL2 https://t.co/Mx31xW201h",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869152651587494208"
          ],
          "editableUntil" : "2024-12-17T23:48:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "103",
              "110"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Elena Sinelnikova",
            "screen_name" : "ElenaCryptoChic",
            "indices" : [
              "39",
              "55"
            ],
            "id_str" : "1307756671234715648",
            "id" : "1307756671234715648"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "159",
              "167"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/J8I2EwIEIt",
            "expanded_url" : "https://snapshot.box/#/s:metislayer2.eth/proposal/0xa78367dca7840d111d1762c55bcabf18c600e7cb3783d4b766c7f821e4a9a33a",
            "display_url" : "snapshot.box/#/s:metislayer…",
            "indices" : [
              "170",
              "193"
            ]
          },
          {
            "url" : "https://t.co/ZxXcsubLio",
            "expanded_url" : "https://x.com/ElenaCryptoChic/status/1868728106082791580",
            "display_url" : "x.com/ElenaCryptoChi…",
            "indices" : [
              "194",
              "217"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "217"
      ],
      "favorite_count" : "7",
      "id_str" : "1869152651587494208",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1869152651587494208",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 17 22:48:13 +0000 2024",
      "favorited" : false,
      "full_text" : "If you haven’t voted yet do it  now as @ElenaCryptoChic says. \n\nLive with your power 💪 and vote 🗳️ for $gMetis to bring innovation and engaging community into @MetisL2 \n\nhttps://t.co/J8I2EwIEIt https://t.co/ZxXcsubLio",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869151977432842521"
          ],
          "editableUntil" : "2024-12-17T23:45:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgents",
            "indices" : [
              "164",
              "173"
            ]
          }
        ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "147",
              "154"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Quantic",
            "screen_name" : "0xQuantic",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1439548673495547908",
            "id" : "1439548673495547908"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "155",
              "163"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/J8I2EwIEIt",
            "expanded_url" : "https://snapshot.box/#/s:metislayer2.eth/proposal/0xa78367dca7840d111d1762c55bcabf18c600e7cb3783d4b766c7f821e4a9a33a",
            "display_url" : "snapshot.box/#/s:metislayer…",
            "indices" : [
              "175",
              "198"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "198"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1868693535970689410",
      "id_str" : "1869151977432842521",
      "in_reply_to_user_id" : "1439548673495547908",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869151977432842521",
      "in_reply_to_status_id" : "1868693535970689410",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 17 22:45:33 +0000 2024",
      "favorited" : false,
      "full_text" : "@0xQuantic Couldn’t agree more but be sure to separate chatbots from AI Agents 🤖 -&gt; check us out and while you’re there leave us your vote 🗳️ \n\n$gMetis @MetisL2 #AIAgents\n\nhttps://t.co/J8I2EwIEIt",
      "lang" : "en",
      "in_reply_to_screen_name" : "0xQuantic",
      "in_reply_to_user_id_str" : "1439548673495547908"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869148947245330822"
          ],
          "editableUntil" : "2024-12-17T23:33:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/J8I2EwIEIt",
            "expanded_url" : "https://snapshot.box/#/s:metislayer2.eth/proposal/0xa78367dca7840d111d1762c55bcabf18c600e7cb3783d4b766c7f821e4a9a33a",
            "display_url" : "snapshot.box/#/s:metislayer…",
            "indices" : [
              "176",
              "199"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "199"
      ],
      "favorite_count" : "11",
      "in_reply_to_status_id_str" : "1868594526052298993",
      "id_str" : "1869148947245330822",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1869148947245330822",
      "in_reply_to_status_id" : "1868594526052298993",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 17 22:33:30 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 $gMetis 🔥 \nToday the goal is CEG approval -&gt; Tomorrow is to bring new ppl into Metis ecosystem by innovating and creating an engaging community\n\nCome and vote on \n\nhttps://t.co/J8I2EwIEIt",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868966412544623080"
          ],
          "editableUntil" : "2024-12-17T11:28:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "10",
              "17"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Norbert🌿",
            "screen_name" : "Norbeegh",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "987935445026852864",
            "id" : "987935445026852864"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1868636232672313397",
      "id_str" : "1868966412544623080",
      "in_reply_to_user_id" : "987935445026852864",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868966412544623080",
      "in_reply_to_status_id" : "1868636232672313397",
      "created_at" : "Tue Dec 17 10:28:11 +0000 2024",
      "favorited" : false,
      "full_text" : "@Norbeegh #gMetis Norbert! 🌿",
      "lang" : "no",
      "in_reply_to_screen_name" : "Norbeegh",
      "in_reply_to_user_id_str" : "987935445026852864"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868963345870844199"
          ],
          "editableUntil" : "2024-12-17T11:15:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Maverick 🧱",
            "screen_name" : "wavymaverick",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "743148071131951104",
            "id" : "743148071131951104"
          },
          {
            "name" : "@Likeey™️",
            "screen_name" : "Liikeey",
            "indices" : [
              "14",
              "22"
            ],
            "id_str" : "1248019709146079236",
            "id" : "1248019709146079236"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1868947726760919071",
      "id_str" : "1868963345870844199",
      "in_reply_to_user_id" : "743148071131951104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868963345870844199",
      "in_reply_to_status_id" : "1868947726760919071",
      "created_at" : "Tue Dec 17 10:15:59 +0000 2024",
      "favorited" : false,
      "full_text" : "@wavymaverick @Liikeey 🔥🔥🔥 Love the spirit!",
      "lang" : "en",
      "in_reply_to_screen_name" : "wavymaverick",
      "in_reply_to_user_id_str" : "743148071131951104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868958361188024406"
          ],
          "editableUntil" : "2024-12-17T10:56:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgents",
            "indices" : [
              "24",
              "33"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "274"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1868615808143986842",
      "id_str" : "1868958361188024406",
      "in_reply_to_user_id" : "296606110",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868958361188024406",
      "in_reply_to_status_id" : "1868615808143986842",
      "created_at" : "Tue Dec 17 09:56:11 +0000 2024",
      "favorited" : false,
      "full_text" : "@josefabregab How about #AIAgents with utility and rewards? AI Agents are not supposed to be one sided or even act as a chatbot... thats ... a chatbot (be that on whatever platform)\nAI Agents meant to bring additional autonomous functionality.\n\nLet me know what you think ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "josefabregab",
      "in_reply_to_user_id_str" : "296606110"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868846520172425335"
          ],
          "editableUntil" : "2024-12-17T03:31:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Hero 🦸🏻‍♂️",
            "screen_name" : "MetisHero",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1731471720165564416",
            "id" : "1731471720165564416"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "11",
              "26"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "27",
              "35"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/WA07iSStIy",
            "expanded_url" : "https://x.com/gmetisl2/status/1868845784613241056?s=46",
            "display_url" : "x.com/gmetisl2/statu…",
            "indices" : [
              "124",
              "147"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "147"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1868700261969272908",
      "id_str" : "1868846520172425335",
      "in_reply_to_user_id" : "1731471720165564416",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1868846520172425335",
      "in_reply_to_status_id" : "1868700261969272908",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 17 02:31:46 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisHero @TheHerculesDEX @MetisL2 I hope this will meet your expections. I hope we can count on your vote on CEG now! ;)\n\nhttps://t.co/WA07iSStIy",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisHero",
      "in_reply_to_user_id_str" : "1731471720165564416"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868845784613241056"
          ],
          "editableUntil" : "2024-12-17T03:28:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/TljASl27Ax",
            "expanded_url" : "http://gMetis.io",
            "display_url" : "gMetis.io",
            "indices" : [
              "97",
              "120"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1868845784613241056/photo/1",
            "indices" : [
              "256",
              "279"
            ],
            "url" : "https://t.co/GHtPB8GOBi",
            "media_url" : "http://pbs.twimg.com/media/Ge95VeZXwAAQ-VM.jpg",
            "id_str" : "1868845780225736704",
            "id" : "1868845780225736704",
            "media_url_https" : "https://pbs.twimg.com/media/Ge95VeZXwAAQ-VM.jpg",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "821",
                "resize" : "fit"
              },
              "small" : {
                "w" : "621",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "750",
                "h" : "821",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/GHtPB8GOBi"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "279"
      ],
      "favorite_count" : "9",
      "id_str" : "1868845784613241056",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1868845784613241056",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 17 02:28:51 +0000 2024",
      "favorited" : false,
      "full_text" : "You asked for it, we delivered—might as well get used to it:\n\nCheck out our brand new website at https://t.co/TljASl27Ax 🚀✨\n\nEnjoy a modern look and feel with a better user experience, packed with more information and a sleeker design. Dive in and explore https://t.co/GHtPB8GOBi",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1868845784613241056/photo/1",
            "indices" : [
              "256",
              "279"
            ],
            "url" : "https://t.co/GHtPB8GOBi",
            "media_url" : "http://pbs.twimg.com/media/Ge95VeZXwAAQ-VM.jpg",
            "id_str" : "1868845780225736704",
            "id" : "1868845780225736704",
            "media_url_https" : "https://pbs.twimg.com/media/Ge95VeZXwAAQ-VM.jpg",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "821",
                "resize" : "fit"
              },
              "small" : {
                "w" : "621",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "750",
                "h" : "821",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/GHtPB8GOBi"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868770589324066959"
          ],
          "editableUntil" : "2024-12-16T22:30:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "16",
              "30"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1868770589324066959/photo/1",
            "indices" : [
              "31",
              "54"
            ],
            "url" : "https://t.co/0BCHBGItPw",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ge808VdW8AA-4e3.jpg",
            "id_str" : "1868770581539123200",
            "id" : "1868770581539123200",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ge808VdW8AA-4e3.jpg",
            "sizes" : {
              "medium" : {
                "w" : "400",
                "h" : "414",
                "resize" : "fit"
              },
              "large" : {
                "w" : "400",
                "h" : "414",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "400",
                "h" : "414",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/0BCHBGItPw"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1868676859644547517",
      "id_str" : "1868770589324066959",
      "in_reply_to_user_id" : "1637191643362107392",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868770589324066959",
      "in_reply_to_status_id" : "1868676859644547517",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 16 21:30:03 +0000 2024",
      "favorited" : false,
      "full_text" : "@TheHerculesDEX @MemAiOfficial https://t.co/0BCHBGItPw",
      "lang" : "qme",
      "in_reply_to_screen_name" : "TheHerculesDEX",
      "in_reply_to_user_id_str" : "1637191643362107392",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1868770589324066959/photo/1",
            "indices" : [
              "31",
              "54"
            ],
            "url" : "https://t.co/0BCHBGItPw",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Ge808VdW8AA-4e3.jpg",
            "id_str" : "1868770581539123200",
            "video_info" : {
              "aspect_ratio" : [
                "200",
                "207"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/Ge808VdW8AA-4e3.mp4"
                }
              ]
            },
            "id" : "1868770581539123200",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Ge808VdW8AA-4e3.jpg",
            "sizes" : {
              "medium" : {
                "w" : "400",
                "h" : "414",
                "resize" : "fit"
              },
              "large" : {
                "w" : "400",
                "h" : "414",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "400",
                "h" : "414",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.x.com/0BCHBGItPw"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868757990545015193"
          ],
          "editableUntil" : "2024-12-16T21:39:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "115",
              "123"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/moS5NHwrJA",
            "expanded_url" : "https://x.com/L2cobi/status/1868755569697263638",
            "display_url" : "x.com/L2cobi/status/…",
            "indices" : [
              "256",
              "279"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "279"
      ],
      "favorite_count" : "12",
      "id_str" : "1868757990545015193",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1868757990545015193",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 16 20:39:59 +0000 2024",
      "favorited" : false,
      "full_text" : "What we aim for is not only to create a rewarded, happy &amp; engaging community but also to bring in new faces to @MetisL2 by creating something new, relevant and innovative that fits the narrative of the season - and I’m not talking about Xmas season ;) https://t.co/moS5NHwrJA",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868757130674860101"
          ],
          "editableUntil" : "2024-12-16T21:36:34.438Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "@Likeey™️",
            "screen_name" : "Liikeey",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "1248019709146079236",
            "id" : "1248019709146079236"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "42",
              "51"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "116"
      ],
      "favorite_count" : "0",
      "id_str" : "1868757130674860101",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868757130674860101",
      "created_at" : "Mon Dec 16 20:36:34 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @Liikeey: Your vote is important to us @gMetisl2 \nHelp us bring this to reality and home🙏 https://t.co/TMCY03fRRE",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868721839591370799"
          ],
          "editableUntil" : "2024-12-16T19:16:20.388Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Arabcoin🌿𝕏",
            "screen_name" : "Iamarabcoin",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1534925673734852609",
            "id" : "1534925673734852609"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "58",
              "67"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1868721839591370799",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868721839591370799",
      "created_at" : "Mon Dec 16 18:16:20 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @Iamarabcoin: Time to cast your vote and show love for @gMetisl2 ! 🗳️ Let’s rally the squad and put GMetis where it belongs at the top.…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868708615542214940"
          ],
          "editableUntil" : "2024-12-16T18:23:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "LFG",
            "indices" : [
              "37",
              "41"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Web3nomad",
            "screen_name" : "Jeremi1Ojetunde",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1525985357522665474",
            "id" : "1525985357522665474"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "17",
              "25"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1868708512597176714",
      "id_str" : "1868708615542214940",
      "in_reply_to_user_id" : "1525985357522665474",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868708615542214940",
      "in_reply_to_status_id" : "1868708512597176714",
      "created_at" : "Mon Dec 16 17:23:47 +0000 2024",
      "favorited" : false,
      "full_text" : "@Jeremi1Ojetunde @MetisL2 Well said! #LFG",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jeremi1Ojetunde",
      "in_reply_to_user_id_str" : "1525985357522665474"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868708250235072800"
          ],
          "editableUntil" : "2024-12-16T18:22:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Hero 🦸🏻‍♂️",
            "screen_name" : "MetisHero",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1731471720165564416",
            "id" : "1731471720165564416"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "11",
              "26"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "27",
              "35"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "226"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1868700261969272908",
      "id_str" : "1868708250235072800",
      "in_reply_to_user_id" : "1731471720165564416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868708250235072800",
      "in_reply_to_status_id" : "1868700261969272908",
      "created_at" : "Mon Dec 16 17:22:20 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisHero @TheHerculesDEX @MetisL2 Appreciate the feedback! We know our shortcomings and our strength. We will make sure to update our website to ensure it’s more modern however our main efforts are on the agent development 🤖",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisHero",
      "in_reply_to_user_id_str" : "1731471720165564416"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868707023501902264"
          ],
          "editableUntil" : "2024-12-16T18:17:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "16",
              "24"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1868706805175697846",
      "id_str" : "1868707023501902264",
      "in_reply_to_user_id" : "1637191643362107392",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868707023501902264",
      "in_reply_to_status_id" : "1868706805175697846",
      "created_at" : "Mon Dec 16 17:17:27 +0000 2024",
      "favorited" : false,
      "full_text" : "@TheHerculesDEX @MetisL2 🔥 🔥 gmetis indeed",
      "lang" : "en",
      "in_reply_to_screen_name" : "TheHerculesDEX",
      "in_reply_to_user_id_str" : "1637191643362107392"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868706402908488078"
          ],
          "editableUntil" : "2024-12-16T18:14:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "25",
              "32"
            ]
          },
          {
            "text" : "AIAgents",
            "indices" : [
              "194",
              "203"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "160",
              "168"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/J8I2EwIEIt",
            "expanded_url" : "https://snapshot.box/#/s:metislayer2.eth/proposal/0xa78367dca7840d111d1762c55bcabf18c600e7cb3783d4b766c7f821e4a9a33a",
            "display_url" : "snapshot.box/#/s:metislayer…",
            "indices" : [
              "252",
              "275"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "18",
      "id_str" : "1868706402908488078",
      "truncated" : false,
      "retweet_count" : "9",
      "id" : "1868706402908488078",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 16 17:14:59 +0000 2024",
      "favorited" : false,
      "full_text" : "🚨 CEG VOTING IS LIVE FOR #gMetis!!! 🚨\nIt's time to make your voice heard and show your support! 🌟 Vote now and play a crucial role in shaping the future of the @MetisL2 ecosystem. Let's elevate #AIAgents to new heights together! 🚀\nYour vote matters 🔥\n\nhttps://t.co/J8I2EwIEIt",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868691879841378610"
          ],
          "editableUntil" : "2024-12-16T17:17:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "24",
              "39"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "79",
              "87"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/DZeKEPufRi",
            "expanded_url" : "https://app.hercules.exchange/?token2=0xFbe0F778e3c1168bc63d7b6F880Ec0d5F9E524E6",
            "display_url" : "app.hercules.exchange/?token2=0xFbe0…",
            "indices" : [
              "90",
              "113"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1868691879841378610/photo/1",
            "indices" : [
              "114",
              "137"
            ],
            "url" : "https://t.co/vhJMPW3bNb",
            "media_url" : "http://pbs.twimg.com/media/Ge7tW6hWgAA6FJE.jpg",
            "id_str" : "1868691873327382528",
            "id" : "1868691873327382528",
            "media_url_https" : "https://pbs.twimg.com/media/Ge7tW6hWgAA6FJE.jpg",
            "sizes" : {
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/vhJMPW3bNb"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "13",
      "id_str" : "1868691879841378610",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1868691879841378610",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 16 16:17:17 +0000 2024",
      "favorited" : false,
      "full_text" : "Finally white listed on @TheHerculesDEX\n\nStep by step part of the ecosystem on @MetisL2 \n\nhttps://t.co/DZeKEPufRi https://t.co/vhJMPW3bNb",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1868691879841378610/photo/1",
            "indices" : [
              "114",
              "137"
            ],
            "url" : "https://t.co/vhJMPW3bNb",
            "media_url" : "http://pbs.twimg.com/media/Ge7tW6hWgAA6FJE.jpg",
            "id_str" : "1868691873327382528",
            "id" : "1868691873327382528",
            "media_url_https" : "https://pbs.twimg.com/media/Ge7tW6hWgAA6FJE.jpg",
            "sizes" : {
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/vhJMPW3bNb"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868683256117534834"
          ],
          "editableUntil" : "2024-12-16T16:43:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "15",
              "22"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1868627468074012932",
      "id_str" : "1868683256117534834",
      "in_reply_to_user_id" : "1854114889041874944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868683256117534834",
      "in_reply_to_status_id" : "1868627468074012932",
      "created_at" : "Mon Dec 16 15:43:01 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisForgeDev #gMetis 👑",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MetisForgeDev",
      "in_reply_to_user_id_str" : "1854114889041874944"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868660244857168174"
          ],
          "editableUntil" : "2024-12-16T15:11:35.059Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "METIS",
            "indices" : [
              "18",
              "24"
            ]
          },
          {
            "text" : "gMetis",
            "indices" : [
              "60",
              "67"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Metis Hero 🦸🏻‍♂️",
            "screen_name" : "MetisHero",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1731471720165564416",
            "id" : "1731471720165564416"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "68",
              "77"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1868660244857168174",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868660244857168174",
      "created_at" : "Mon Dec 16 14:11:35 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @MetisHero: GM $METIS fam! Our time will come someday. \n\n$gMetis @gMetisl2 i hear devs here are based. Excited to see what they can prov…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868398785128526002"
          ],
          "editableUntil" : "2024-12-15T21:52:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1868224560983662730",
      "id_str" : "1868398785128526002",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868398785128526002",
      "in_reply_to_status_id" : "1868224560983662730",
      "created_at" : "Sun Dec 15 20:52:38 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis present! 🔥 🚀",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868331477257375909"
          ],
          "editableUntil" : "2024-12-15T17:25:10.755Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "33",
              "40"
            ]
          },
          {
            "text" : "MetisL2",
            "indices" : [
              "97",
              "105"
            ]
          },
          {
            "text" : "AIAgents",
            "indices" : [
              "106",
              "115"
            ]
          },
          {
            "text" : "Memewithutility",
            "indices" : [
              "116",
              "132"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1868331477257375909",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868331477257375909",
      "created_at" : "Sun Dec 15 16:25:10 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @gMetisl2: If you wonder what #gMetis is about listen our first song: “gMetis to the Moon” 🎶🎵🎧#MetisL2 #AIAgents #Memewithutility https:…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868291592806948944"
          ],
          "editableUntil" : "2024-12-15T14:46:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/TPjD3i0xvc",
            "expanded_url" : "https://x.com/TheHerculesDEX/status/1868263971981041892",
            "display_url" : "x.com/TheHerculesDEX…",
            "indices" : [
              "2",
              "25"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "5",
      "id_str" : "1868291592806948944",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1868291592806948944",
      "possibly_sensitive" : false,
      "created_at" : "Sun Dec 15 13:46:41 +0000 2024",
      "favorited" : false,
      "full_text" : "👀 https://t.co/TPjD3i0xvc",
      "lang" : "art"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868291455653175708"
          ],
          "editableUntil" : "2024-12-15T14:46:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "cryptomaniac 🚨",
            "screen_name" : "Z_Cryptomaniac",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "351822556",
            "id" : "351822556"
          },
          {
            "name" : "loq",
            "screen_name" : "loqnft",
            "indices" : [
              "16",
              "23"
            ],
            "id_str" : "1231779263369666561",
            "id" : "1231779263369666561"
          },
          {
            "name" : "stu",
            "screen_name" : "despxwned",
            "indices" : [
              "24",
              "34"
            ],
            "id_str" : "1501011281528119296",
            "id" : "1501011281528119296"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1868290904244805994",
      "id_str" : "1868291455653175708",
      "in_reply_to_user_id" : "351822556",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868291455653175708",
      "in_reply_to_status_id" : "1868290904244805994",
      "created_at" : "Sun Dec 15 13:46:08 +0000 2024",
      "favorited" : false,
      "full_text" : "@Z_Cryptomaniac @loqnft @despxwned 🔥 🔥",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Z_Cryptomaniac",
      "in_reply_to_user_id_str" : "351822556"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868286914060849542"
          ],
          "editableUntil" : "2024-12-15T14:28:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "0",
              "7"
            ]
          },
          {
            "text" : "AIAgents",
            "indices" : [
              "111",
              "120"
            ]
          },
          {
            "text" : "Innovation",
            "indices" : [
              "121",
              "132"
            ]
          },
          {
            "text" : "MEMEwithUtility",
            "indices" : [
              "133",
              "149"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "44",
              "52"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "96",
              "110"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "149"
      ],
      "favorite_count" : "10",
      "id_str" : "1868286914060849542",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1868286914060849542",
      "created_at" : "Sun Dec 15 13:28:06 +0000 2024",
      "favorited" : false,
      "full_text" : "#gMetis everyone! 🤖 🔥 \nThis week was hot on @MetisL2 and trust me we are just getting started!\n\n@MetisForgeDev #AIAgents #Innovation #MEMEwithUtility",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867890081668935932"
          ],
          "editableUntil" : "2024-12-14T12:11:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "10",
              "17"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Driezmann The flying Dutchman",
            "screen_name" : "DriesT99",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "785325583",
            "id" : "785325583"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1867889416846659691",
      "id_str" : "1867890081668935932",
      "in_reply_to_user_id" : "785325583",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867890081668935932",
      "in_reply_to_status_id" : "1867889416846659691",
      "created_at" : "Sat Dec 14 11:11:13 +0000 2024",
      "favorited" : false,
      "full_text" : "@DriesT99 #gMetis friend!",
      "lang" : "en",
      "in_reply_to_screen_name" : "DriesT99",
      "in_reply_to_user_id_str" : "785325583"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867681707014701504"
          ],
          "editableUntil" : "2024-12-13T22:23:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Intern",
            "screen_name" : "MetisIntern",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1554237904209281024",
            "id" : "1554237904209281024"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "13",
              "21"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "47",
              "61"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "81",
              "95"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "100",
              "109"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          },
          {
            "name" : "Monkex Coffee Shop Club ☕",
            "screen_name" : "MonkexNFT",
            "indices" : [
              "159",
              "169"
            ],
            "id_str" : "1528413809030971393",
            "id" : "1528413809030971393"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "191"
      ],
      "favorite_count" : "14",
      "in_reply_to_status_id_str" : "1867680251863802191",
      "id_str" : "1867681707014701504",
      "in_reply_to_user_id" : "1554237904209281024",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1867681707014701504",
      "in_reply_to_status_id" : "1867680251863802191",
      "created_at" : "Fri Dec 13 21:23:13 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisIntern @MetisL2 How about now thanks to  @MetisForgeDev for making it safe @MemAiOfficial and @gMetisl2 for making it running with the narrative and ofc @MonkexNFT for being the OG dude",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisIntern",
      "in_reply_to_user_id_str" : "1554237904209281024"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867677186989469970"
          ],
          "editableUntil" : "2024-12-13T22:05:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "252",
              "259"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "260",
              "268"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "268"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1867677183873102322",
      "id_str" : "1867677186989469970",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1867677186989469970",
      "in_reply_to_status_id" : "1867677183873102322",
      "created_at" : "Fri Dec 13 21:05:15 +0000 2024",
      "favorited" : false,
      "full_text" : "🏗️ **Step-by-Step Delivery:**\n\nExpect continuous updates and a step-by-step delivery approach. This is our mid-term goal and narrative. Stay tuned for exciting developments! 📈🚀\n\n---\nJoin the gMetis revolution and be part of something groundbreaking! 🌟 #gMetis @MetisL2",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867677183873102322"
          ],
          "editableUntil" : "2024-12-13T22:05:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "158"
      ],
      "favorite_count" : "6",
      "in_reply_to_status_id_str" : "1867677179720741001",
      "id_str" : "1867677183873102322",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1867677183873102322",
      "in_reply_to_status_id" : "1867677179720741001",
      "created_at" : "Fri Dec 13 21:05:15 +0000 2024",
      "favorited" : false,
      "full_text" : "🤖**Bot Concerns?**\n\nWorried about bots? Don’t be! We’ll fight AI with AI, ensuring genuine interactions and a thriving, human-centric community experience. 🙌🤖",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867677179720741001"
          ],
          "editableUntil" : "2024-12-13T22:05:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [
          {
            "text" : "gMetis",
            "indices" : [
              "37",
              "44"
            ]
          },
          {
            "text" : "gMetis",
            "indices" : [
              "111",
              "118"
            ]
          }
        ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "189"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1867677176633733624",
      "id_str" : "1867677179720741001",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1867677179720741001",
      "in_reply_to_status_id" : "1867677176633733624",
      "created_at" : "Fri Dec 13 21:05:14 +0000 2024",
      "favorited" : false,
      "full_text" : "💎 ** Incentivize to Hold:**\n\nHolding $gMetis in your wallet boosts reward calculations. More engagement + more $gMetis = higher rewards. Let’s build a strong, vibrant community together! 💬💰",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867677176633733624"
          ],
          "editableUntil" : "2024-12-13T22:05:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "239"
      ],
      "favorite_count" : "22",
      "id_str" : "1867677176633733624",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1867677176633733624",
      "created_at" : "Fri Dec 13 21:05:13 +0000 2024",
      "favorited" : false,
      "full_text" : "🧵 **Thread below:**\n\n💡 **Alpha Leak:**\n\n🤫 Once our Agent is live and fully operational (v1.0 roadmap), daily (and initially, hourly!) rewards will be based on community engagement. Expect a surge in activity as real-time rewards kick in! 🚀",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867672798044528999"
          ],
          "editableUntil" : "2024-12-13T21:47:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgents",
            "indices" : [
              "278",
              "287"
            ]
          },
          {
            "text" : "MEME",
            "indices" : [
              "288",
              "293"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "45",
              "59"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "76",
              "91"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "138",
              "146"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "293"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1867669052870865388",
      "id_str" : "1867672798044528999",
      "in_reply_to_user_id" : "1854114889041874944",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1867672798044528999",
      "in_reply_to_status_id" : "1867669052870865388",
      "created_at" : "Fri Dec 13 20:47:49 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisForgeDev @MetisL2 Launched securely on @MetisForgeDev and now live on @TheHerculesDEX , gMetis is here to innovate and energize the @MetisL2 ecosystem. With an AI-driven community where participation is rewarded, it’s all about merging fun with purposeful engagement. 🤖🔥🚀\n#AIAgents #MEME",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisForgeDev",
      "in_reply_to_user_id_str" : "1854114889041874944"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867670573884780678"
          ],
          "editableUntil" : "2024-12-13T21:38:59.112Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "50",
              "58"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "77",
              "86"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1867670573884780678",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867670573884780678",
      "created_at" : "Fri Dec 13 20:38:59 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @MetisForgeDev: A new comer has arrived to the @MetisL2 ecosystem \nCalled @gMetisl2 \n\nIt is an AI agent with a mission\n\nTo Innovate\n\nTo…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867547283174437325"
          ],
          "editableUntil" : "2024-12-13T13:29:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgent",
            "indices" : [
              "53",
              "61"
            ]
          },
          {
            "text" : "MEME",
            "indices" : [
              "62",
              "67"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ralph",
            "screen_name" : "Ralph_DeFi",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1755243371059146752",
            "id" : "1755243371059146752"
          },
          {
            "name" : "Vella",
            "screen_name" : "cryptotrader85",
            "indices" : [
              "12",
              "27"
            ],
            "id_str" : "719407371928211458",
            "id" : "719407371928211458"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "28",
              "43"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "44",
              "52"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1867544621070369160",
      "id_str" : "1867547283174437325",
      "in_reply_to_user_id" : "1755243371059146752",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867547283174437325",
      "in_reply_to_status_id" : "1867544621070369160",
      "created_at" : "Fri Dec 13 12:29:04 +0000 2024",
      "favorited" : false,
      "full_text" : "@Ralph_DeFi @cryptotrader85 @TheHerculesDEX @MetisL2 #AIAgent #MEME season! ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "Ralph_DeFi",
      "in_reply_to_user_id_str" : "1755243371059146752"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867496880067797411"
          ],
          "editableUntil" : "2024-12-13T10:08:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "10",
              "17"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "19"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1867496354492322189",
      "id_str" : "1867496880067797411",
      "in_reply_to_user_id" : "1747259142182674432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867496880067797411",
      "in_reply_to_status_id" : "1867496354492322189",
      "created_at" : "Fri Dec 13 09:08:47 +0000 2024",
      "favorited" : false,
      "full_text" : "@VestaDAO #gMetis 🌿",
      "lang" : "qme",
      "in_reply_to_screen_name" : "VestaDAO",
      "in_reply_to_user_id_str" : "1747259142182674432"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867496067626926154"
          ],
          "editableUntil" : "2024-12-13T10:05:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "56",
              "63"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Erwin",
            "screen_name" : "CryptoErwinNL",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1239987918",
            "id" : "1239987918"
          },
          {
            "name" : "Vella",
            "screen_name" : "cryptotrader85",
            "indices" : [
              "15",
              "30"
            ],
            "id_str" : "719407371928211458",
            "id" : "719407371928211458"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "31",
              "46"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "47",
              "55"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1867495907991990438",
      "id_str" : "1867496067626926154",
      "in_reply_to_user_id" : "1239987918",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867496067626926154",
      "in_reply_to_status_id" : "1867495907991990438",
      "created_at" : "Fri Dec 13 09:05:33 +0000 2024",
      "favorited" : false,
      "full_text" : "@CryptoErwinNL @cryptotrader85 @TheHerculesDEX @MetisL2 #gMetis to you",
      "lang" : "en",
      "in_reply_to_screen_name" : "CryptoErwinNL",
      "in_reply_to_user_id_str" : "1239987918"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867490969039540714"
          ],
          "editableUntil" : "2024-12-13T09:45:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AiAgent",
            "indices" : [
              "0",
              "8"
            ]
          },
          {
            "text" : "Meme",
            "indices" : [
              "9",
              "14"
            ]
          },
          {
            "text" : "UtilityTokens",
            "indices" : [
              "15",
              "29"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/lrnSMP8JrC",
            "expanded_url" : "https://x.com/cryptotrader85/status/1867490475864994216",
            "display_url" : "x.com/cryptotrader85…",
            "indices" : [
              "36",
              "59"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "6",
      "id_str" : "1867490969039540714",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1867490969039540714",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 13 08:45:17 +0000 2024",
      "favorited" : false,
      "full_text" : "#AiAgent #Meme #UtilityTokens 🔥 🤖 🚀 https://t.co/lrnSMP8JrC",
      "lang" : "qme"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867474415275106771"
          ],
          "editableUntil" : "2024-12-13T08:39:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "cryptomaniac 🚨",
            "screen_name" : "Z_Cryptomaniac",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "351822556",
            "id" : "351822556"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "16",
              "31"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "32",
              "46"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "4",
      "in_reply_to_status_id_str" : "1867473579001962941",
      "id_str" : "1867474415275106771",
      "in_reply_to_user_id" : "351822556",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1867474415275106771",
      "in_reply_to_status_id" : "1867473579001962941",
      "created_at" : "Fri Dec 13 07:39:31 +0000 2024",
      "favorited" : false,
      "full_text" : "@Z_Cryptomaniac @TheHerculesDEX @MetisForgeDev makes it easy and safe for both side! Great experience!",
      "lang" : "en",
      "in_reply_to_screen_name" : "Z_Cryptomaniac",
      "in_reply_to_user_id_str" : "351822556"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867474139663282605"
          ],
          "editableUntil" : "2024-12-13T08:38:25.544Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "cryptomaniac 🚨",
            "screen_name" : "Z_Cryptomaniac",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "351822556",
            "id" : "351822556"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "57",
              "72"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1867474139663282605",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867474139663282605",
      "created_at" : "Fri Dec 13 07:38:25 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @Z_Cryptomaniac: An other Agent  gMetis \nis live on \n\n@TheHerculesDEX dex it was launched and reached quorum\nSo quickly that we all miss…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867469107354120652"
          ],
          "editableUntil" : "2024-12-13T08:18:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "0",
              "7"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "58",
              "66"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "2",
      "id_str" : "1867469107354120652",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867469107354120652",
      "created_at" : "Fri Dec 13 07:18:25 +0000 2024",
      "favorited" : false,
      "full_text" : "#gMetis everyone!\nGreat day yesterday! Let’s build today! @MetisL2",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867462829655347389"
          ],
          "editableUntil" : "2024-12-13T07:53:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "id_str" : "1867462829655347389",
      "in_reply_to_user_id" : "1597935273001865218",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867462829655347389",
      "created_at" : "Fri Dec 13 06:53:29 +0000 2024",
      "favorited" : false,
      "full_text" : "@MemAiOfficial are you ready for an AI rally?",
      "lang" : "en",
      "in_reply_to_screen_name" : "MemAiOfficial",
      "in_reply_to_user_id_str" : "1597935273001865218"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867430532570817017"
          ],
          "editableUntil" : "2024-12-13T05:45:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Staysafe",
            "indices" : [
              "109",
              "118"
            ]
          },
          {
            "text" : "gMetis",
            "indices" : [
              "119",
              "126"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Hero 🦸🏻‍♂️",
            "screen_name" : "MetisHero",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1731471720165564416",
            "id" : "1731471720165564416"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "26",
              "40"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "126"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1867429437341675852",
      "id_str" : "1867430532570817017",
      "in_reply_to_user_id" : "1731471720165564416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867430532570817017",
      "in_reply_to_status_id" : "1867429437341675852",
      "created_at" : "Fri Dec 13 04:45:08 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisHero We Launched on @MetisForgeDev to minimize the risk. Liquidity locked in Herculesdex permanently. \n#Staysafe #gMetis",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisHero",
      "in_reply_to_user_id_str" : "1731471720165564416"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867429449698095196"
          ],
          "editableUntil" : "2024-12-13T05:40:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Gatsby",
            "screen_name" : "ZGatsbyy",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "889657415670665216",
            "id" : "889657415670665216"
          },
          {
            "name" : "Metis Hero 🦸🏻‍♂️",
            "screen_name" : "MetisHero",
            "indices" : [
              "10",
              "20"
            ],
            "id_str" : "1731471720165564416",
            "id" : "1731471720165564416"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/VCW1XUXB0Z",
            "expanded_url" : "https://t.me/gmetisio",
            "display_url" : "t.me/gmetisio",
            "indices" : [
              "21",
              "44"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1867425656977732091",
      "id_str" : "1867429449698095196",
      "in_reply_to_user_id" : "889657415670665216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867429449698095196",
      "in_reply_to_status_id" : "1867425656977732091",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 13 04:40:50 +0000 2024",
      "favorited" : false,
      "full_text" : "@ZGatsbyy @MetisHero https://t.co/VCW1XUXB0Z",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ZGatsbyy",
      "in_reply_to_user_id_str" : "889657415670665216"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867425614275215454"
          ],
          "editableUntil" : "2024-12-13T05:25:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Imminent",
            "indices" : [
              "21",
              "30"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Hero 🦸🏻‍♂️",
            "screen_name" : "MetisHero",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1731471720165564416",
            "id" : "1731471720165564416"
          },
          {
            "name" : "Gatsby",
            "screen_name" : "ZGatsbyy",
            "indices" : [
              "11",
              "20"
            ],
            "id_str" : "889657415670665216",
            "id" : "889657415670665216"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1867425309999718851",
      "id_str" : "1867425614275215454",
      "in_reply_to_user_id" : "1731471720165564416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867425614275215454",
      "in_reply_to_status_id" : "1867425309999718851",
      "created_at" : "Fri Dec 13 04:25:36 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisHero @ZGatsbyy #Imminent",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MetisHero",
      "in_reply_to_user_id_str" : "1731471720165564416"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867423154362364310"
          ],
          "editableUntil" : "2024-12-13T05:15:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "29",
              "43"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/DZeKEPufRi",
            "expanded_url" : "https://app.hercules.exchange/?token2=0xFbe0F778e3c1168bc63d7b6F880Ec0d5F9E524E6",
            "display_url" : "app.hercules.exchange/?token2=0xFbe0…",
            "indices" : [
              "128",
              "151"
            ]
          }
        ],
        "symbols" : [
          {
            "text" : "Metis",
            "indices" : [
              "52",
              "58"
            ]
          }
        ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1867423154362364310/photo/1",
            "indices" : [
              "152",
              "175"
            ],
            "url" : "https://t.co/nqFw7huUj6",
            "media_url" : "http://pbs.twimg.com/media/Gepq66ZWUAAfxbY.jpg",
            "id_str" : "1867422555839025152",
            "id" : "1867422555839025152",
            "media_url_https" : "https://pbs.twimg.com/media/Gepq66ZWUAAfxbY.jpg",
            "sizes" : {
              "large" : {
                "w" : "1381",
                "h" : "853",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "741",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "420",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/nqFw7huUj6"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "175"
      ],
      "favorite_count" : "6",
      "id_str" : "1867423154362364310",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867423154362364310",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 13 04:15:49 +0000 2024",
      "favorited" : false,
      "full_text" : "AAAAND the pool is filled on @MetisForgeDev !!!\n120 $Metis in just 2 h.\n\nMetis season is kicking off!\n\nYou can find us now on   https://t.co/DZeKEPufRi https://t.co/nqFw7huUj6",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1867423154362364310/photo/1",
            "indices" : [
              "152",
              "175"
            ],
            "url" : "https://t.co/nqFw7huUj6",
            "media_url" : "http://pbs.twimg.com/media/Gepq66ZWUAAfxbY.jpg",
            "id_str" : "1867422555839025152",
            "id" : "1867422555839025152",
            "media_url_https" : "https://pbs.twimg.com/media/Gepq66ZWUAAfxbY.jpg",
            "sizes" : {
              "large" : {
                "w" : "1381",
                "h" : "853",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "741",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "420",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/nqFw7huUj6"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867408336582320248"
          ],
          "editableUntil" : "2024-12-13T04:16:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgents",
            "indices" : [
              "36",
              "45"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "185",
              "199"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/vc2bLA75QZ",
            "expanded_url" : "http://docs.gmetis.io",
            "display_url" : "docs.gmetis.io",
            "indices" : [
              "132",
              "155"
            ]
          },
          {
            "url" : "https://t.co/t6BzH8GZQu",
            "expanded_url" : "https://metisforge.io/0xFbe0F778e3c1168bc63d7b6F880Ec0d5F9E524E6",
            "display_url" : "metisforge.io/0xFbe0F778e3c1…",
            "indices" : [
              "215",
              "238"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "238"
      ],
      "favorite_count" : "0",
      "id_str" : "1867408336582320248",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867408336582320248",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 13 03:16:56 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 has been quite hot lately. #AIAgents are undoubtedly the future! Let’s raise it with incentivized social activity!\nHead to https://t.co/vc2bLA75QZ to learn more\nOr catch us on @MetisForgeDev while you can\n\nhttps://t.co/t6BzH8GZQu",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867396362586689913"
          ],
          "editableUntil" : "2024-12-13T03:29:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "247",
              "254"
            ]
          },
          {
            "text" : "AIAgents",
            "indices" : [
              "255",
              "264"
            ]
          }
        ],
        "symbols" : [
          {
            "text" : "Metis",
            "indices" : [
              "97",
              "103"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "61",
              "75"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/9siFH9PEhU",
            "expanded_url" : "http://gmetis.io",
            "display_url" : "gmetis.io",
            "indices" : [
              "114",
              "137"
            ]
          },
          {
            "url" : "https://t.co/TSQqmre978",
            "expanded_url" : "http://metisforge.io",
            "display_url" : "metisforge.io",
            "indices" : [
              "192",
              "215"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "264"
      ],
      "favorite_count" : "2",
      "id_str" : "1867396362586689913",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867396362586689913",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 13 02:29:22 +0000 2024",
      "favorited" : false,
      "full_text" : "🚀 WHAT A DAY! We're launching gMetis: AI Agent MEME token on @MetisForgeDev ! \nOur target is 120 $Metis! 🎉 \nVisit https://t.co/9siFH9PEhU for more info and documentation,  or head straight to https://t.co/TSQqmre978 Let's make history together! 💥 #gMetis #AIAgents",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867313162107629709"
          ],
          "editableUntil" : "2024-12-12T21:58:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CryptoSecurity",
            "indices" : [
              "147",
              "162"
            ]
          },
          {
            "text" : "Metis",
            "indices" : [
              "163",
              "169"
            ]
          },
          {
            "text" : "SafeMemes",
            "indices" : [
              "170",
              "180"
            ]
          },
          {
            "text" : "AIRevolution",
            "indices" : [
              "181",
              "194"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "14",
              "28"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "224"
      ],
      "favorite_count" : "2",
      "id_str" : "1867313162107629709",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867313162107629709",
      "created_at" : "Thu Dec 12 20:58:45 +0000 2024",
      "favorited" : false,
      "full_text" : "Just reviewed @MetisForgeDev ‘s MemeToken creator contract and it’s all good! This season's memes are set to be safe, smart, and ready to moon. 🚀🌟 #CryptoSecurity #Metis #SafeMemes #AIRevolution\n\nReady to spread the word! 🎉📢",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867308316348514507"
          ],
          "editableUntil" : "2024-12-12T21:39:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgent",
            "indices" : [
              "78",
              "86"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "223",
              "237"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/vc2bLA75QZ",
            "expanded_url" : "http://docs.gmetis.io",
            "display_url" : "docs.gmetis.io",
            "indices" : [
              "254",
              "277"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "277"
      ],
      "favorite_count" : "1",
      "id_str" : "1867308316348514507",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867308316348514507",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 12 20:39:30 +0000 2024",
      "favorited" : false,
      "full_text" : "Being a meme isn't enough anymore, and neither is just a chatbot. 🤖 Enter the #AIAgent: fueling community convos, on-chain rewarding top members daily, and fighting AI with AI. Launching soon! 🌟 Stay engaged, get rewarded! @MetisForgeDev \nFind out more: https://t.co/vc2bLA75QZ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867293331090198817"
          ],
          "editableUntil" : "2024-12-12T20:39:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Metis Insiders",
            "screen_name" : "MetisInsiders",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1856948242917015552",
            "id" : "1856948242917015552"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866956147200028990/video/1",
            "source_status_id" : "1866956147200028990",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/e0ZgkVC0Q0",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "id_str" : "1866956099552747520",
            "source_user_id" : "1864044295654912000",
            "id" : "1866956099552747520",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "source_user_id_str" : "1864044295654912000",
            "sizes" : {
              "large" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1866956147200028990",
            "display_url" : "pic.x.com/e0ZgkVC0Q0"
          }
        ],
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "15",
              "22"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1867048768815895019",
      "id_str" : "1867293331090198817",
      "in_reply_to_user_id" : "1856948242917015552",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867293331090198817",
      "in_reply_to_status_id" : "1867048768815895019",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 12 19:39:57 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisInsiders #gMetis to the Moon!  🚀🔥🤖\n\n https://t.co/e0ZgkVC0Q0",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisInsiders",
      "in_reply_to_user_id_str" : "1856948242917015552",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866956147200028990/video/1",
            "source_status_id" : "1866956147200028990",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/e0ZgkVC0Q0",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "id_str" : "1866956099552747520",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "140001",
              "variants" : [
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1866956099552747520/pu/vid/avc1/480x270/7DD7rVTgBtWBixyj.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1866956099552747520/pu/vid/avc1/640x360/akeUZZMkXH-t9DG2.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1866956099552747520/pu/pl/tQeajTAgilcH648G.m3u8?tag=12"
                }
              ]
            },
            "source_user_id" : "1864044295654912000",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1866956099552747520",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "source_user_id_str" : "1864044295654912000",
            "sizes" : {
              "large" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1866956147200028990",
            "display_url" : "pic.x.com/e0ZgkVC0Q0"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867290266060698059"
          ],
          "editableUntil" : "2024-12-12T20:27:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sammie | The Web3 Sensei 🥷",
            "screen_name" : "sensei_sammie",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1471253793631264772",
            "id" : "1471253793631264772"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "15",
              "29"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "30",
              "44"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1867282761263743156",
      "id_str" : "1867290266060698059",
      "in_reply_to_user_id" : "1471253793631264772",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867290266060698059",
      "in_reply_to_status_id" : "1867282761263743156",
      "created_at" : "Thu Dec 12 19:27:46 +0000 2024",
      "favorited" : false,
      "full_text" : "@sensei_sammie @MemAiOfficial @MetisForgeDev DMd you just now",
      "lang" : "en",
      "in_reply_to_screen_name" : "sensei_sammie",
      "in_reply_to_user_id_str" : "1471253793631264772"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867241628576203194"
          ],
          "editableUntil" : "2024-12-12T17:14:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIAgents",
            "indices" : [
              "74",
              "83"
            ]
          }
        ],
        "symbols" : [
          {
            "text" : "Metis",
            "indices" : [
              "84",
              "90"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "10",
              "24"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "39",
              "53"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "5",
      "id_str" : "1867241628576203194",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867241628576203194",
      "created_at" : "Thu Dec 12 16:14:30 +0000 2024",
      "favorited" : false,
      "full_text" : "Kudos for @MemAiOfficial filling up on @MetisForgeDev in less than 10 min #AIAgents $Metis 🔥🤖🚀",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867187787276902418"
          ],
          "editableUntil" : "2024-12-12T13:40:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "244",
              "251"
            ]
          },
          {
            "text" : "TheWorldIsMonkex",
            "indices" : [
              "270",
              "287"
            ]
          }
        ],
        "symbols" : [
          {
            "text" : "MONKEX",
            "indices" : [
              "125",
              "132"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "tokentom.monkex",
            "screen_name" : "tokentom_monkex",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1391166869176868864",
            "id" : "1391166869176868864"
          },
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "17",
              "30"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "31",
              "39"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "40",
              "55"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Zeno Exchange 🏛️",
            "screen_name" : "ZenoExchange",
            "indices" : [
              "56",
              "69"
            ],
            "id_str" : "1755092646178045952",
            "id" : "1755092646178045952"
          },
          {
            "name" : "Artemis",
            "screen_name" : "Artemisfinance",
            "indices" : [
              "70",
              "85"
            ],
            "id_str" : "1747168873441550336",
            "id" : "1747168873441550336"
          },
          {
            "name" : "DeFi Kingdoms 🔺🌿",
            "screen_name" : "DeFiKingdoms",
            "indices" : [
              "86",
              "99"
            ],
            "id_str" : "1412168764284706822",
            "id" : "1412168764284706822"
          },
          {
            "name" : "Arena of Faith",
            "screen_name" : "moba_aof",
            "indices" : [
              "100",
              "109"
            ],
            "id_str" : "1641112467752521729",
            "id" : "1641112467752521729"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "110",
              "124"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "290"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1867030246811373598",
      "id_str" : "1867187787276902418",
      "in_reply_to_user_id" : "1391166869176868864",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867187787276902418",
      "in_reply_to_status_id" : "1867030246811373598",
      "created_at" : "Thu Dec 12 12:40:33 +0000 2024",
      "favorited" : false,
      "full_text" : "@tokentom_monkex @josefabregab @MetisL2 @TheHerculesDEX @ZenoExchange @Artemisfinance @DeFiKingdoms @moba_aof @MemAiOfficial $MONKEX is the OG Metis meme. I don’t get the comms about the others claiming otherwise. There are others ofc like us, #gMetis for one but still #TheWorldIsMonkex :D",
      "lang" : "en",
      "in_reply_to_screen_name" : "tokentom_monkex",
      "in_reply_to_user_id_str" : "1391166869176868864"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866961137646047443"
          ],
          "editableUntil" : "2024-12-11T22:39:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MetisL2",
            "indices" : [
              "14",
              "22"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "292"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1866956121694421137",
      "id_str" : "1866961137646047443",
      "in_reply_to_user_id" : "296606110",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866961137646047443",
      "in_reply_to_status_id" : "1866956121694421137",
      "created_at" : "Wed Dec 11 21:39:56 +0000 2024",
      "favorited" : false,
      "full_text" : "@josefabregab #MetisL2\nWhy?\nOther than having Vitalik’s mom in the founders and the core team\nEver improving tech and significant partnerships with leading cross chain platforms like Aave and crazy rewards with single stalking Metis token…\nOp 2.92 B\narb 4.1B\nStark 1.47 B\nZk 876 M\nMetis 340 M",
      "lang" : "en",
      "in_reply_to_screen_name" : "josefabregab",
      "in_reply_to_user_id_str" : "296606110"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956166896455782"
          ],
          "editableUntil" : "2024-12-11T22:20:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "186"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866956164258521322",
      "id_str" : "1866956166896455782",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866956166896455782",
      "in_reply_to_status_id" : "1866956164258521322",
      "created_at" : "Wed Dec 11 21:20:11 +0000 2024",
      "favorited" : false,
      "full_text" : "(Outro)  \nSo, saddle up, partner, and join the fun,  \nGMetis on Metis, our journey's begun,  \nTo the moon and beyond, let's raise a cheer,  \nGMetis is the future, and the future is here.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956164258521322"
          ],
          "editableUntil" : "2024-12-11T22:20:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866956161788056010",
      "id_str" : "1866956164258521322",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866956164258521322",
      "in_reply_to_status_id" : "1866956161788056010",
      "created_at" : "Wed Dec 11 21:20:10 +0000 2024",
      "favorited" : false,
      "full_text" : "(Chorus)  \nGMetis to the moon, where the memes go high,  \nThe first AI agent, reaching for the sky,  \nJoin the social channels, get rewarded and smile,  \nIn this vibrant community, you'll stay for a while.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956161788056010"
          ],
          "editableUntil" : "2024-12-11T22:20:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "195"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866956159351132618",
      "id_str" : "1866956161788056010",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866956161788056010",
      "in_reply_to_status_id" : "1866956159351132618",
      "created_at" : "Wed Dec 11 21:20:09 +0000 2024",
      "favorited" : false,
      "full_text" : "(Bridge)  \nTrust and transparency, that's the name of the game,  \nSafe and secure, Metis Forge to the fame,  \nActive participation, rewards day by day,  \nGMetis in our hearts, we're here to stay.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956159351132618"
          ],
          "editableUntil" : "2024-12-11T22:20:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866956156087963758",
      "id_str" : "1866956159351132618",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866956159351132618",
      "in_reply_to_status_id" : "1866956156087963758",
      "created_at" : "Wed Dec 11 21:20:09 +0000 2024",
      "favorited" : false,
      "full_text" : "(Chorus)  \nGMetis to the moon, where the memes go high,  \nThe first AI agent, reaching for the sky,  \nJoin the social channels, get rewarded and smile,  \nIn this vibrant community, you'll stay for a while.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956156087963758"
          ],
          "editableUntil" : "2024-12-11T22:20:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866956153449488725",
      "id_str" : "1866956156087963758",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866956156087963758",
      "in_reply_to_status_id" : "1866956153449488725",
      "created_at" : "Wed Dec 11 21:20:08 +0000 2024",
      "favorited" : false,
      "full_text" : "(Verse 2)  \nBuilt on Andromeda, it's a ride you can't miss,  \nAI drivin' conversations with a tech-savvy twist,  \nReal-time insights, keepin' trends in view,  \nGMetis in the house, making dreams come true.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956153449488725"
          ],
          "editableUntil" : "2024-12-11T22:20:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866956150522122511",
      "id_str" : "1866956153449488725",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866956153449488725",
      "in_reply_to_status_id" : "1866956150522122511",
      "created_at" : "Wed Dec 11 21:20:08 +0000 2024",
      "favorited" : false,
      "full_text" : "(Chorus)  \nGMetis to the moon, where the memes go high,  \nThe first AI agent, reaching for the sky,  \nJoin the social channels, get rewarded and smile,  \nIn this vibrant community, you'll stay for a while.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956150522122511"
          ],
          "editableUntil" : "2024-12-11T22:20:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "187"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866956147200028990",
      "id_str" : "1866956150522122511",
      "in_reply_to_user_id" : "1864044295654912000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866956150522122511",
      "in_reply_to_status_id" : "1866956147200028990",
      "created_at" : "Wed Dec 11 21:20:07 +0000 2024",
      "favorited" : false,
      "full_text" : "Well, I heard a story 'bout a token, shiny and bright,  \nAimin' for the moon, lighting up the night,  \nOn the Metis chain, it's bound to soar,  \nGMetis, the AI agent, givin' folks a roar.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gMetisl2",
      "in_reply_to_user_id_str" : "1864044295654912000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866956147200028990"
          ],
          "editableUntil" : "2024-12-11T22:20:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866956147200028990/video/1",
            "indices" : [
              "119",
              "142"
            ],
            "url" : "https://t.co/6sAsH9USzZ",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "id_str" : "1866956099552747520",
            "id" : "1866956099552747520",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "sizes" : {
              "large" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/6sAsH9USzZ"
          }
        ],
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "19",
              "26"
            ]
          },
          {
            "text" : "MetisL2",
            "indices" : [
              "83",
              "91"
            ]
          },
          {
            "text" : "AIAgents",
            "indices" : [
              "92",
              "101"
            ]
          },
          {
            "text" : "Memewithutility",
            "indices" : [
              "102",
              "118"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "142"
      ],
      "favorite_count" : "4",
      "id_str" : "1866956147200028990",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1866956147200028990",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 11 21:20:06 +0000 2024",
      "favorited" : false,
      "full_text" : "If you wonder what #gMetis is about listen our first song: “gMetis to the Moon” 🎶🎵🎧#MetisL2 #AIAgents #Memewithutility https://t.co/6sAsH9USzZ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866956147200028990/video/1",
            "indices" : [
              "119",
              "142"
            ],
            "url" : "https://t.co/6sAsH9USzZ",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "id_str" : "1866956099552747520",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "140001",
              "variants" : [
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1866956099552747520/pu/vid/avc1/480x270/7DD7rVTgBtWBixyj.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1866956099552747520/pu/vid/avc1/640x360/akeUZZMkXH-t9DG2.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1866956099552747520/pu/pl/tQeajTAgilcH648G.m3u8?tag=12"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1866956099552747520",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1866956099552747520/pu/img/J5a7wFoPh_ZavZho.jpg",
            "sizes" : {
              "large" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "640",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.x.com/6sAsH9USzZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866949487392088482"
          ],
          "editableUntil" : "2024-12-11T21:53:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "89",
              "96"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "cobi.bean",
            "screen_name" : "L2cobi",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1825933621322035200",
            "id" : "1825933621322035200"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "8",
              "16"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "17",
              "31"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          },
          {
            "name" : "pumpetribe",
            "screen_name" : "pumpe_meme",
            "indices" : [
              "32",
              "43"
            ],
            "id_str" : "1848478910729883649",
            "id" : "1848478910729883649"
          },
          {
            "name" : "Medusa",
            "screen_name" : "medusa_metis",
            "indices" : [
              "44",
              "57"
            ],
            "id_str" : "1843804342698065920",
            "id" : "1843804342698065920"
          },
          {
            "name" : "Dusa",
            "screen_name" : "dusa_metis",
            "indices" : [
              "58",
              "69"
            ],
            "id_str" : "1763736652474679296",
            "id" : "1763736652474679296"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "70",
              "84"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1866888471874248965",
      "id_str" : "1866949487392088482",
      "in_reply_to_user_id" : "1825933621322035200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866949487392088482",
      "in_reply_to_status_id" : "1866888471874248965",
      "created_at" : "Wed Dec 11 20:53:38 +0000 2024",
      "favorited" : false,
      "full_text" : "@L2cobi @MetisL2 @MetisForgeDev @pumpe_meme @medusa_metis @dusa_metis @MemAiOfficial Add #gMetis there just in case ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "L2cobi",
      "in_reply_to_user_id_str" : "1825933621322035200"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866834521892462946"
          ],
          "editableUntil" : "2024-12-11T14:16:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1866775015443591252",
      "id_str" : "1866834521892462946",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866834521892462946",
      "in_reply_to_status_id" : "1866775015443591252",
      "created_at" : "Wed Dec 11 13:16:48 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis &lt;3",
      "lang" : "und",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866799608539779261"
          ],
          "editableUntil" : "2024-12-11T11:58:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "10",
              "17"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Vesta🌿",
            "screen_name" : "VestaDAO",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1747259142182674432",
            "id" : "1747259142182674432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866790802946499034",
      "id_str" : "1866799608539779261",
      "in_reply_to_user_id" : "1747259142182674432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866799608539779261",
      "in_reply_to_status_id" : "1866790802946499034",
      "created_at" : "Wed Dec 11 10:58:04 +0000 2024",
      "favorited" : false,
      "full_text" : "@VestaDAO #gMetis to you 🌿",
      "lang" : "en",
      "in_reply_to_screen_name" : "VestaDAO",
      "in_reply_to_user_id_str" : "1747259142182674432"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866799243312157132"
          ],
          "editableUntil" : "2024-12-11T11:56:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "staysafe",
            "indices" : [
              "259",
              "268"
            ]
          },
          {
            "text" : "Metisl2",
            "indices" : [
              "269",
              "277"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "99",
              "113"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "277"
      ],
      "favorite_count" : "0",
      "id_str" : "1866799243312157132",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866799243312157132",
      "created_at" : "Wed Dec 11 10:56:37 +0000 2024",
      "favorited" : false,
      "full_text" : "This season I’m expecting more ppl moving into project that has been launched on platforms such as @MetisForgeDev. It takes the “rug-wheel” out of founders hands and only those projects stay on top who delivers value. No more soft rug, no more liquidity pull\n#staysafe #Metisl2",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866798059885387984"
          ],
          "editableUntil" : "2024-12-11T11:51:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "157",
              "164"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "14",
              "22"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Hercules 🌿",
            "screen_name" : "TheHerculesDEX",
            "indices" : [
              "23",
              "38"
            ],
            "id_str" : "1637191643362107392",
            "id" : "1637191643362107392"
          },
          {
            "name" : "Zeno Exchange 🏛️",
            "screen_name" : "ZenoExchange",
            "indices" : [
              "39",
              "52"
            ],
            "id_str" : "1755092646178045952",
            "id" : "1755092646178045952"
          },
          {
            "name" : "Artemis",
            "screen_name" : "Artemisfinance",
            "indices" : [
              "53",
              "68"
            ],
            "id_str" : "1747168873441550336",
            "id" : "1747168873441550336"
          },
          {
            "name" : "DeFi Kingdoms 🔺🌿",
            "screen_name" : "DeFiKingdoms",
            "indices" : [
              "69",
              "82"
            ],
            "id_str" : "1412168764284706822",
            "id" : "1412168764284706822"
          },
          {
            "name" : "Arena of Faith",
            "screen_name" : "moba_aof",
            "indices" : [
              "83",
              "92"
            ],
            "id_str" : "1641112467752521729",
            "id" : "1641112467752521729"
          },
          {
            "name" : "MEMETHOS",
            "screen_name" : "MemAiOfficial",
            "indices" : [
              "93",
              "107"
            ],
            "id_str" : "1597935273001865218",
            "id" : "1597935273001865218"
          },
          {
            "name" : "gMetis 🌿",
            "screen_name" : "gMetisl2",
            "indices" : [
              "123",
              "132"
            ],
            "id_str" : "1864044295654912000",
            "id" : "1864044295654912000"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/VQJ66Aom5B",
            "expanded_url" : "http://Gmetis.io",
            "display_url" : "Gmetis.io",
            "indices" : [
              "205",
              "228"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "228"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1866785005638123962",
      "id_str" : "1866798059885387984",
      "in_reply_to_user_id" : "296606110",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866798059885387984",
      "in_reply_to_status_id" : "1866785005638123962",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 11 10:51:55 +0000 2024",
      "favorited" : false,
      "full_text" : "@josefabregab @MetisL2 @TheHerculesDEX @ZenoExchange @Artemisfinance @DeFiKingdoms @moba_aof @MemAiOfficial Take a look at @gMetisl2 and our documentation. \n#gMetis is well fit in the 5th category ;) 🤖🔥\n@ https://t.co/VQJ66Aom5B",
      "lang" : "en",
      "in_reply_to_screen_name" : "josefabregab",
      "in_reply_to_user_id_str" : "296606110"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866784363154903198"
          ],
          "editableUntil" : "2024-12-11T10:57:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "0",
              "7"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "id_str" : "1866784363154903198",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866784363154903198",
      "created_at" : "Wed Dec 11 09:57:30 +0000 2024",
      "favorited" : false,
      "full_text" : "#gMetis everyone! Are we cooking or what? ☕️🤖",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866691824712306935"
          ],
          "editableUntil" : "2024-12-11T04:49:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Metis Forge",
            "screen_name" : "MetisForgeDev",
            "indices" : [
              "242",
              "256"
            ],
            "id_str" : "1854114889041874944",
            "id" : "1854114889041874944"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/7MbjMoZlqF",
            "expanded_url" : "https://ceg.vote/t/cvp-proposal-gmetis/3743",
            "display_url" : "ceg.vote/t/cvp-proposal…",
            "indices" : [
              "150",
              "173"
            ]
          },
          {
            "url" : "https://t.co/9siFH9Qc7s",
            "expanded_url" : "http://gmetis.io",
            "display_url" : "gmetis.io",
            "indices" : [
              "183",
              "206"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866691824712306935/video/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/zIS8KuWlB7",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1866690838186565632/pu/img/Doxpl40XtVLU5N8S.jpg",
            "id_str" : "1866690838186565632",
            "id" : "1866690838186565632",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1866690838186565632/pu/img/Doxpl40XtVLU5N8S.jpg",
            "sizes" : {
              "large" : {
                "w" : "720",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "720",
                "h" : "720",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/zIS8KuWlB7"
          }
        ],
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "260",
              "267"
            ]
          },
          {
            "text" : "AIAgents",
            "indices" : [
              "268",
              "277"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "301"
      ],
      "favorite_count" : "2",
      "id_str" : "1866691824712306935",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1866691824712306935",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 11 03:49:47 +0000 2024",
      "favorited" : false,
      "full_text" : "🚀 Exciting News! We've updated our website, created a new CVP proposal, and refreshed our documentation! Check out the details here: \nCVP Proposal 📄: https://t.co/7MbjMoZlqF\nwebsite: https://t.co/9siFH9Qc7s\nStay tuned for more info on launch @MetisForgeDev \n\n #gMetis #AIAgents https://t.co/zIS8KuWlB7",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866691824712306935/video/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/zIS8KuWlB7",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1866690838186565632/pu/img/Doxpl40XtVLU5N8S.jpg",
            "id_str" : "1866690838186565632",
            "video_info" : {
              "aspect_ratio" : [
                "1",
                "1"
              ],
              "duration_millis" : "13240",
              "variants" : [
                {
                  "bitrate" : "1280000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1866690838186565632/pu/vid/avc1/720x720/gYZb78QKNjC3ZyEI.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1866690838186565632/pu/pl/zTxu5xB2XtOpzXhJ.m3u8?tag=12"
                },
                {
                  "bitrate" : "432000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1866690838186565632/pu/vid/avc1/320x320/lRECDR9uFAscTTWd.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1866690838186565632/pu/vid/avc1/540x540/dOHYlGwt7Ah_2-Mj.mp4?tag=12"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1866690838186565632",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1866690838186565632/pu/img/Doxpl40XtVLU5N8S.jpg",
            "sizes" : {
              "large" : {
                "w" : "720",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "720",
                "h" : "720",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.x.com/zIS8KuWlB7"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866496700518703467"
          ],
          "editableUntil" : "2024-12-10T15:54:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "60",
              "67"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "jfab.eth",
            "screen_name" : "josefabregab",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "296606110",
            "id" : "296606110"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "14",
              "22"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "stake.link",
            "screen_name" : "stakedotlink",
            "indices" : [
              "23",
              "36"
            ],
            "id_str" : "1588878841715605504",
            "id" : "1588878841715605504"
          },
          {
            "name" : "DeFi Kingdoms 🔺🌿",
            "screen_name" : "DeFiKingdoms",
            "indices" : [
              "37",
              "50"
            ],
            "id_str" : "1412168764284706822",
            "id" : "1412168764284706822"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1866412539614994800",
      "id_str" : "1866496700518703467",
      "in_reply_to_user_id" : "296606110",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866496700518703467",
      "in_reply_to_status_id" : "1866412539614994800",
      "created_at" : "Tue Dec 10 14:54:25 +0000 2024",
      "favorited" : false,
      "full_text" : "@josefabregab @MetisL2 @stakedotlink @DeFiKingdoms Exactly! #gMetis",
      "lang" : "en",
      "in_reply_to_screen_name" : "josefabregab",
      "in_reply_to_user_id_str" : "296606110"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866406483757301993"
          ],
          "editableUntil" : "2024-12-10T09:55:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866406483757301993/photo/1",
            "indices" : [
              "277",
              "300"
            ],
            "url" : "https://t.co/4emX3qjkCR",
            "media_url" : "http://pbs.twimg.com/media/GebOzbsXEAA8OzM.jpg",
            "id_str" : "1866406478594117632",
            "id" : "1866406478594117632",
            "media_url_https" : "https://pbs.twimg.com/media/GebOzbsXEAA8OzM.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/4emX3qjkCR"
          }
        ],
        "hashtags" : [
          {
            "text" : "AIAgent",
            "indices" : [
              "22",
              "30"
            ]
          },
          {
            "text" : "MetisL2",
            "indices" : [
              "161",
              "169"
            ]
          },
          {
            "text" : "COMIN_SOON",
            "indices" : [
              "265",
              "276"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "300"
      ],
      "favorite_count" : "2",
      "id_str" : "1866406483757301993",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866406483757301993",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 10 08:55:56 +0000 2024",
      "favorited" : false,
      "full_text" : "gMetis 🌿\nOur upcoming #AIAgent isn't just a chatbot—it's an autonomous entity designed to perform advanced analytics and on-chain transactions simultaneously on #MetisL2. Community engagement is at the heart of our vision. Stay tuned and be part of this journey! 💡🔗#COMIN_SOON https://t.co/4emX3qjkCR",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/gMetisl2/status/1866406483757301993/photo/1",
            "indices" : [
              "277",
              "300"
            ],
            "url" : "https://t.co/4emX3qjkCR",
            "media_url" : "http://pbs.twimg.com/media/GebOzbsXEAA8OzM.jpg",
            "id_str" : "1866406478594117632",
            "id" : "1866406478594117632",
            "media_url_https" : "https://pbs.twimg.com/media/GebOzbsXEAA8OzM.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/4emX3qjkCR"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866091822839124142"
          ],
          "editableUntil" : "2024-12-09T13:05:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1866057796317241419",
      "id_str" : "1866091822839124142",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866091822839124142",
      "in_reply_to_status_id" : "1866057796317241419",
      "created_at" : "Mon Dec 09 12:05:35 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis 🌿 🌿",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865808473206018490"
          ],
          "editableUntil" : "2024-12-08T18:19:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "2",
      "id_str" : "1865808473206018490",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865808473206018490",
      "created_at" : "Sun Dec 08 17:19:39 +0000 2024",
      "favorited" : false,
      "full_text" : "AI Agents are coming to Metis! Xmas gonna be hot this year! 🤖 🎄",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865326025963360683"
          ],
          "editableUntil" : "2024-12-07T10:22:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "0",
              "7"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "1",
      "id_str" : "1865326025963360683",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865326025963360683",
      "created_at" : "Sat Dec 07 09:22:35 +0000 2024",
      "favorited" : false,
      "full_text" : "#gMetis everyone☕️",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864994511664861507"
          ],
          "editableUntil" : "2024-12-06T12:25:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "9",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          },
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "28",
              "36"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1864601579581559005",
      "id_str" : "1864994511664861507",
      "in_reply_to_user_id" : "1290738140219572225",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864994511664861507",
      "in_reply_to_status_id" : "1864601579581559005",
      "created_at" : "Fri Dec 06 11:25:16 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisL2 #gMetis to you too @MetisL2 &lt;3",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisL2",
      "in_reply_to_user_id_str" : "1290738140219572225"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864233131663929767"
          ],
          "editableUntil" : "2024-12-04T09:59:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "endo▼",
            "screen_name" : "ultrasoundape",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1145811803978575873",
            "id" : "1145811803978575873"
          },
          {
            "name" : "Monkex Coffee Shop Club ☕",
            "screen_name" : "MonkexNFT",
            "indices" : [
              "28",
              "38"
            ],
            "id_str" : "1528413809030971393",
            "id" : "1528413809030971393"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "121"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1864229874602295549",
      "id_str" : "1864233131663929767",
      "in_reply_to_user_id" : "1145811803978575873",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864233131663929767",
      "in_reply_to_status_id" : "1864229874602295549",
      "created_at" : "Wed Dec 04 08:59:49 +0000 2024",
      "favorited" : false,
      "full_text" : "@ultrasoundape It still is. @MonkexNFT is the OG thingy but there is always place for one more espresso in the morning ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "ultrasoundape",
      "in_reply_to_user_id_str" : "1145811803978575873"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864229545273925831"
          ],
          "editableUntil" : "2024-12-04T09:45:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "21",
              "28"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "endo▼",
            "screen_name" : "ultrasoundape",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1145811803978575873",
            "id" : "1145811803978575873"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1864218244506112388",
      "id_str" : "1864229545273925831",
      "in_reply_to_user_id" : "1145811803978575873",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864229545273925831",
      "in_reply_to_status_id" : "1864218244506112388",
      "created_at" : "Wed Dec 04 08:45:33 +0000 2024",
      "favorited" : false,
      "full_text" : "@ultrasoundape Gm gm #gMetis",
      "lang" : "en",
      "in_reply_to_screen_name" : "ultrasoundape",
      "in_reply_to_user_id_str" : "1145811803978575873"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864075609149739404"
          ],
          "editableUntil" : "2024-12-03T23:33:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "gMetis",
            "indices" : [
              "11",
              "18"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis Hero 🦸🏻‍♂️",
            "screen_name" : "MetisHero",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1731471720165564416",
            "id" : "1731471720165564416"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1863632020448088081",
      "id_str" : "1864075609149739404",
      "in_reply_to_user_id" : "1731471720165564416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864075609149739404",
      "in_reply_to_status_id" : "1863632020448088081",
      "created_at" : "Tue Dec 03 22:33:52 +0000 2024",
      "favorited" : false,
      "full_text" : "@MetisHero #gMetis very possible -with all the things yet to come to the ecosystem. Although I’d rather bet on January",
      "lang" : "en",
      "in_reply_to_screen_name" : "MetisHero",
      "in_reply_to_user_id_str" : "1731471720165564416"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864066359711183097"
          ],
          "editableUntil" : "2024-12-03T22:57:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "metisl2",
            "indices" : [
              "13",
              "21"
            ]
          },
          {
            "text" : "gMetis",
            "indices" : [
              "22",
              "29"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Metis🌿",
            "screen_name" : "MetisL2",
            "indices" : [
              "4",
              "12"
            ],
            "id_str" : "1290738140219572225",
            "id" : "1290738140219572225"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "id_str" : "1864066359711183097",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864066359711183097",
      "created_at" : "Tue Dec 03 21:57:07 +0000 2024",
      "favorited" : false,
      "full_text" : "GM \n@MetisL2 #metisl2 #gMetis",
      "lang" : "und"
    }
  }
]