window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "1864044295654912000",
      "emailChange" : {
        "changedAt" : "2024-12-03T20:29:38.000Z",
        "changedTo" : "gmetisl2.ai@gmail.com"
      }
    }
  },
  {
    "emailAddressChange" : {
      "accountId" : "1864044295654912000",
      "emailChange" : {
        "changedAt" : "2024-12-12T07:43:44.000Z",
        "changedTo" : "x@gmetis.io"
      }
    }
  }
]