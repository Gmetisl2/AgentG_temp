window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1864044295654912000",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
            "registrationToken" : "33092ebe25000484316f6a748b978dd6",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAExKKZidHUvFrmgeNGHowPcf5TG5JNuf4Fe9N31Qqs+zoZkGl0gHAsqMHyR4d6klj88RpZiGnqrHiMFMc6gPX8SQ==",
            "createdAt" : "2024-12-11T01:18:15.477Z",
            "deviceId" : "1a81bad7-369f-4ab6-9aa9-7c14a838495b"
          },
          {
            "userAgent" : "Twitter-iPhone/10.70 iOS/17.7.2 (Apple;iPhone12,8;;;;;0;2019)",
            "registrationToken" : "5658acad283b2974b9f150705253dfac",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE/tdo6Wz/L1WrECp4sWyuW9Y+4ThMw/eoCk4IM27zc1wnfx4xZJyIY07NlPRvrAJU3c/DuzdknyIzihOGMz0SUQ==",
            "createdAt" : "2024-12-03T20:52:48.736Z",
            "deviceId" : "F1ACA15C-2E78-4E02-AA8A-615328FA02BF"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 17_7_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.8.1 Mobile/15E148 Safari/604.1",
            "registrationToken" : "c295af36a18e72a0cbe8feffb7b40482",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEyCpEoXwwAGgl/BUxQir7uFhKPVFefjOYfaMdV0cX2FptwkC7luGKzujMSpxJnuG2/ZbOEaOmPHfByxJtf8Jxcg==",
            "createdAt" : "2024-12-03T20:32:00.339Z",
            "deviceId" : "a4228ec2-d9fd-40e1-a84c-3fc982a8b9f3"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]