window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1878116133384942023",
      "fullText" : "The jeets are out - now we build with only the real ones.\n\n$MEMAI will prevail https://t.co/l6BXg1PKfU",
      "expandedUrl" : "https://twitter.com/i/web/status/1878116133384942023"
    }
  },
  {
    "like" : {
      "tweetId" : "1878086469429956710",
      "fullText" : "Build bigger empires with the Mars Station 🌍➡️🔴\n\nContribute to the Mars Station’s construction and earn a percentage of resources generated from Martian districts, plus adjacency bonuses from colonies.\n\nThe Station is already constructed - thats when the secondary market is… https://t.co/B4MqbMbYMJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1878086469429956710"
    }
  },
  {
    "like" : {
      "tweetId" : "1878094595872993629",
      "fullText" : "Create brand value and loyalty for the long term🤘",
      "expandedUrl" : "https://twitter.com/i/web/status/1878094595872993629"
    }
  },
  {
    "like" : {
      "tweetId" : "1878146596233200051",
      "fullText" : "Fortune favors patient and constant people.",
      "expandedUrl" : "https://twitter.com/i/web/status/1878146596233200051"
    }
  },
  {
    "like" : {
      "tweetId" : "1878135346875220051",
      "fullText" : "@MetisForgeDev @MemAiOfficial @gMetisl2 🤖 🤝",
      "expandedUrl" : "https://twitter.com/i/web/status/1878135346875220051"
    }
  },
  {
    "like" : {
      "tweetId" : "1878064372108648695",
      "fullText" : "memecoins sound better when they have a personality https://t.co/YCxcZYNqL8",
      "expandedUrl" : "https://twitter.com/i/web/status/1878064372108648695"
    }
  },
  {
    "like" : {
      "tweetId" : "1877996403865121148",
      "fullText" : "Forge your future with our AI agents tokens \n\nYou are still very early!!!\n\nCc: @MemAiOfficial &amp; @gMetisl2 https://t.co/IN0fkliACM",
      "expandedUrl" : "https://twitter.com/i/web/status/1877996403865121148"
    }
  },
  {
    "like" : {
      "tweetId" : "1877878753721712809",
      "fullText" : "DeFAI",
      "expandedUrl" : "https://twitter.com/i/web/status/1877878753721712809"
    }
  },
  {
    "like" : {
      "tweetId" : "1877853977414422965",
      "fullText" : "@gMetisl2 @Web3_Matters @explore_thecore We love what we see. Great momentum for a start",
      "expandedUrl" : "https://twitter.com/i/web/status/1877853977414422965"
    }
  },
  {
    "like" : {
      "tweetId" : "1877849669167886604",
      "fullText" : "@Liikeey @gMetisl2 @0xQuantic @MetisHero @pharm_Gaga @Iamarabcoin @MetisL2 And When market is down @gMetisl2 is heading for the uptrend 🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1877849669167886604"
    }
  },
  {
    "like" : {
      "tweetId" : "1877846621855031372",
      "fullText" : "\"53% up since yesterday 🚀 Momentum is real, and the All-Time High is calling. Are you still fading @gMetisl2 yet? Who's riding this wave with us? \n@0xQuantic @MetisHero @pharm_Gaga @Iamarabcoin @MetisL2 https://t.co/lRWLh8VjSb https://t.co/UxEdKJdHL3",
      "expandedUrl" : "https://twitter.com/i/web/status/1877846621855031372"
    }
  },
  {
    "like" : {
      "tweetId" : "1877843732986282307",
      "fullText" : "@gMetisl2 @Web3_Matters @explore_thecore Let's gooo!🔥 This is the kind of progress that pushes the whole space forward! Major moves, big wins, and even bigger things ahead. Proud to see innovation, partnerships, and engagement growing stronger! 💪🌐 #gMetis #AIAgents",
      "expandedUrl" : "https://twitter.com/i/web/status/1877843732986282307"
    }
  },
  {
    "like" : {
      "tweetId" : "1877841655853658354",
      "fullText" : "@cypherpunk669 I echo this sentiment.\n\nnot only stoked to see AC step up and get his voice heard, but stoked to see folks rallying behind him! \n\nThe building blocks are here. \n\nLet’s put them together. TOGETHER!",
      "expandedUrl" : "https://twitter.com/i/web/status/1877841655853658354"
    }
  },
  {
    "like" : {
      "tweetId" : "1877834406892564781",
      "fullText" : "Although it may not be in the brightest of moments, I’m heartened to see the community step up in difficult times to help and contribute to the chain they love.\n\nWhether we agree or disagree on stated proposals and suggestions, I’m grateful we have community members that care…",
      "expandedUrl" : "https://twitter.com/i/web/status/1877834406892564781"
    }
  },
  {
    "like" : {
      "tweetId" : "1877811952648368141",
      "fullText" : "It's interesting to see this proposal on the Metis governance forum that goes beyond criticism and explores broad solutions that could be adopted.\n\nhttps://t.co/gfdH9f4QjX\n\nRegardless of whether you agree or disagree with the information there, I invite you to participate in the…",
      "expandedUrl" : "https://twitter.com/i/web/status/1877811952648368141"
    }
  },
  {
    "like" : {
      "tweetId" : "1877816918825935050",
      "fullText" : "It’s no secret @MetisL2 and its ecosystem have underperformed.  \n\nI’ve committed to building and planting my flag on this L2, not the 500 other options we have as users, investors, and market participants. \n\nHow can you help? 👇\n\nA fellow Metis project, founder, and investor, AC,…",
      "expandedUrl" : "https://twitter.com/i/web/status/1877816918825935050"
    }
  },
  {
    "like" : {
      "tweetId" : "1877800885570433057",
      "fullText" : "@gMetisl2 I have a question. Still is Vitalic’s mother @Natalia_Ameline in $Metis team ? Or no ?",
      "expandedUrl" : "https://twitter.com/i/web/status/1877800885570433057"
    }
  },
  {
    "like" : {
      "tweetId" : "1877814359809777940",
      "fullText" : "What are the best arguments as for why @family should explore a @MetisL2 integration?\n\nI’ll start:\n• Potential to steal a major mkt share as it’s still a small ecosystem\n• Big ecosystem fund that will give fat incentives to Family if @StaniKulechov asks\n• @chainlink aligned https://t.co/jOmjZLT6fl",
      "expandedUrl" : "https://twitter.com/i/web/status/1877814359809777940"
    }
  },
  {
    "like" : {
      "tweetId" : "1877797992704410082",
      "fullText" : "@gMetisl2 @MetisL2 Sending some Love from Planet Mars ❤️🔴🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1877797992704410082"
    }
  },
  {
    "like" : {
      "tweetId" : "1877745191517360323",
      "fullText" : "See you guys in 10 minutes! https://t.co/ivQZudwiSF",
      "expandedUrl" : "https://twitter.com/i/web/status/1877745191517360323"
    }
  },
  {
    "like" : {
      "tweetId" : "1877734741480268049",
      "fullText" : "GM from Pucón 🌞 https://t.co/8xB2ZtP4Tp",
      "expandedUrl" : "https://twitter.com/i/web/status/1877734741480268049"
    }
  },
  {
    "like" : {
      "tweetId" : "1877748831405617406",
      "fullText" : "https://t.co/S9QmARuBxJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1877748831405617406"
    }
  },
  {
    "like" : {
      "tweetId" : "1877723062147190905",
      "fullText" : "@Liikeey @gMetisl2 That's the ticker of the year for #Metis chain \n\n$gMetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1877723062147190905"
    }
  },
  {
    "like" : {
      "tweetId" : "1877674204549484641",
      "fullText" : "@MetisForgeDev @gMetisl2 @MetisL2 💯 we were, we are , and we will be …forever @MetisL2 \nThe first and only to launch not 1 but 2 AI agents on Metis",
      "expandedUrl" : "https://twitter.com/i/web/status/1877674204549484641"
    }
  },
  {
    "like" : {
      "tweetId" : "1877662068876198178",
      "fullText" : "@gMetisl2 @MetisL2 We'd never lost it",
      "expandedUrl" : "https://twitter.com/i/web/status/1877662068876198178"
    }
  },
  {
    "like" : {
      "tweetId" : "1877646647435411540",
      "fullText" : "Moment of appreciation for all the innovators pushing Web3 to the next level 🩵",
      "expandedUrl" : "https://twitter.com/i/web/status/1877646647435411540"
    }
  },
  {
    "like" : {
      "tweetId" : "1877635184712937964",
      "fullText" : "If you are planning to launch a coin @MetisForgeDev should be your first choice for  \n\nThe reward, 5 Metis for the creator \n\nMeme Royal 40k to the best communities \n\nThe Team has real life experience in the field \n\nSmooth and fast process \n\nDid I forget that they have influencers… https://t.co/zdYjF4p6jG",
      "expandedUrl" : "https://twitter.com/i/web/status/1877635184712937964"
    }
  },
  {
    "like" : {
      "tweetId" : "1877642795948572702",
      "fullText" : "The CORE's galaxy doesn’t unlock its secrets on its own. Uncover lunar treasures with the Moon Station 🌕🔬\n\nContribute to the Moon Station’s construction or maintenance and earn a percentage of resources generated from lunar districts.\n\nThe Station is already constructed - thats… https://t.co/KevnMWvvKe",
      "expandedUrl" : "https://twitter.com/i/web/status/1877642795948572702"
    }
  },
  {
    "like" : {
      "tweetId" : "1877567664903586242",
      "fullText" : "We must accept finite disappointment, but never lose infinite hope. 🌿 🙏",
      "expandedUrl" : "https://twitter.com/i/web/status/1877567664903586242"
    }
  },
  {
    "like" : {
      "tweetId" : "1877624653155295465",
      "fullText" : "And @gMetisl2 is the alpha here,🤑 as they're planning to launch their beta test on 12th. https://t.co/ihY4hlVgH1",
      "expandedUrl" : "https://twitter.com/i/web/status/1877624653155295465"
    }
  },
  {
    "like" : {
      "tweetId" : "1877522769866375426",
      "fullText" : "AI done wrong is making new forms of independent self-replicating intelligent life\n\nAI done right is mecha suits for the human mind\n\nIf we do the former without the latter, we risk permanent human disempowerment. If we do the latter, flourishing superinteligent human civilization",
      "expandedUrl" : "https://twitter.com/i/web/status/1877522769866375426"
    }
  },
  {
    "like" : {
      "tweetId" : "1877524481083592800",
      "fullText" : "@EMostaque \"Agents\" is a fun word. Sometimes it means \"AI that runs off and makes its own complicated plans that last for days with no human input\", but often it just means \"chatbot replaces GUIs as the interface to everything\". The latter is great!",
      "expandedUrl" : "https://twitter.com/i/web/status/1877524481083592800"
    }
  },
  {
    "like" : {
      "tweetId" : "1877464114978607277",
      "fullText" : "@gMetisl2 @L2cobi @0xQuantic @ctokev @Muttis_MetisDog I have zero doubts king.",
      "expandedUrl" : "https://twitter.com/i/web/status/1877464114978607277"
    }
  },
  {
    "like" : {
      "tweetId" : "1877422854469247231",
      "fullText" : "@L2cobi @0xQuantic @ctokev @gMetisl2 @Muttis_MetisDog https://t.co/R31LEq4Hgq",
      "expandedUrl" : "https://twitter.com/i/web/status/1877422854469247231"
    }
  },
  {
    "like" : {
      "tweetId" : "1877429439958544642",
      "fullText" : "@gMetisl2 @L2cobi @0xQuantic @ctokev @Muttis_MetisDog Gmetis... Beyond thrilled to connect. If you have a moment, I'd love to know a TLDR about your mission",
      "expandedUrl" : "https://twitter.com/i/web/status/1877429439958544642"
    }
  },
  {
    "like" : {
      "tweetId" : "1877459190655897845",
      "fullText" : "@DriesT99 @L2cobi @0xQuantic @ctokev @gMetisl2 @Muttis_MetisDog Straight legends putting in the work every single f'king day. For the people.",
      "expandedUrl" : "https://twitter.com/i/web/status/1877459190655897845"
    }
  },
  {
    "like" : {
      "tweetId" : "1877428730559070691",
      "fullText" : "What do devs/builders value (besides money!)? \n\nComment what you think devs value below! 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1877428730559070691"
    }
  },
  {
    "like" : {
      "tweetId" : "1877421990849417688",
      "fullText" : "Ayoo wen it's scary like this, tap in and do some research!\n\nTap in with me and the Web3Matters fam Friday for a space to discuss our research tips! \n\n🌿 How to find gems?\n🌿 Social Metrics\n🌿 On-Chain Metrics\n\nhttps://t.co/ESW55HJW0I",
      "expandedUrl" : "https://twitter.com/i/web/status/1877421990849417688"
    }
  },
  {
    "like" : {
      "tweetId" : "1877395751065583806",
      "fullText" : "@danielesesta @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1877395751065583806"
    }
  },
  {
    "like" : {
      "tweetId" : "1877338148138516522",
      "fullText" : "@gMetisl2 What's coming?\n\nGib us some hints",
      "expandedUrl" : "https://twitter.com/i/web/status/1877338148138516522"
    }
  },
  {
    "like" : {
      "tweetId" : "1877331243185873160",
      "fullText" : "How to Claim Your First Districts in The Core ⬇️\n\n1️⃣ Login to MetaMask\n2️⃣ Connect Your Wallet\n3️⃣ Switch to Polygon\n4️⃣ Top-Up POL to cover TXN fee only.\n5️⃣ Claim Your First Districts for FREE! 🚀\n\nStart now and claim your first districts on Earth 🌎, Moon 🌖, and Mars 🔴:… https://t.co/XRqAfUDE5U",
      "expandedUrl" : "https://twitter.com/i/web/status/1877331243185873160"
    }
  },
  {
    "like" : {
      "tweetId" : "1877327851201896761",
      "fullText" : "@explore_thecore @gMetisl2 @MetisL2 gMetis is Love 🌿💜💜💜",
      "expandedUrl" : "https://twitter.com/i/web/status/1877327851201896761"
    }
  },
  {
    "like" : {
      "tweetId" : "1877325674664386796",
      "fullText" : "AI Agents Incoming – for the good of us, let’s hope! 🤖\n\nWe are partnering up with an ambitious project @gMetisl2 sparking buzz already on @MetisL2 to experiment with community vibes powered by trained AI agents. https://t.co/yb37AeI902",
      "expandedUrl" : "https://twitter.com/i/web/status/1877325674664386796"
    }
  },
  {
    "like" : {
      "tweetId" : "1877320746793423044",
      "fullText" : "@jpeg_luciano Community is alpha",
      "expandedUrl" : "https://twitter.com/i/web/status/1877320746793423044"
    }
  },
  {
    "like" : {
      "tweetId" : "1877316901896073664",
      "fullText" : "2021: Community is the utility\n\n2025: Community is the utility\n\nBeing surrounded by like minded people is still underrated",
      "expandedUrl" : "https://twitter.com/i/web/status/1877316901896073664"
    }
  },
  {
    "like" : {
      "tweetId" : "1877043494277054735",
      "fullText" : "What would be the ideal key features/utilities for onchain agents?",
      "expandedUrl" : "https://twitter.com/i/web/status/1877043494277054735"
    }
  },
  {
    "like" : {
      "tweetId" : "1877038336793063765",
      "fullText" : "Let’s hear from you:\n\nIf you had an AI agent to handle one task every day, what would it be?\n\nShare your answer below! We’d love to know how you’d use your agent!",
      "expandedUrl" : "https://twitter.com/i/web/status/1877038336793063765"
    }
  },
  {
    "like" : {
      "tweetId" : "1876960006005768220",
      "fullText" : "GM $METIS fam!\n\nBetter days are coming! Markets kinda meh right now.",
      "expandedUrl" : "https://twitter.com/i/web/status/1876960006005768220"
    }
  },
  {
    "like" : {
      "tweetId" : "1876423168010637387",
      "fullText" : "Tap in with us tomorrow! \n\nMetis Morning Show\nTuesday: 12pm EST\n\n🎙️News\n🎙️Alpha \n🎙️and everything in between! https://t.co/90ZmmbkfRI",
      "expandedUrl" : "https://twitter.com/i/web/status/1876423168010637387"
    }
  },
  {
    "like" : {
      "tweetId" : "1876921892822561100",
      "fullText" : "gmetis\ngmetis\ngmetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1876921892822561100"
    }
  },
  {
    "like" : {
      "tweetId" : "1868627468074012932",
      "fullText" : "Our Christmas gift is here early.\n\nMeme Royale—yeah, we've mentioned it before.\n\nBut this time, it is more than a reality, with our launchpad picking up action this last week.\n\nAlso our leaderboard will be out soon, so you can start paving our way to top!\n\nAll you have to do is:… https://t.co/AZiJIyNO2D",
      "expandedUrl" : "https://twitter.com/i/web/status/1868627468074012932"
    }
  },
  {
    "like" : {
      "tweetId" : "1868660030561767573",
      "fullText" : "GM $METIS fam! Our time will come someday. \n\n$gMetis @gMetisl2 i hear devs here are based. Excited to see what they can provide in real AI revenue",
      "expandedUrl" : "https://twitter.com/i/web/status/1868660030561767573"
    }
  },
  {
    "like" : {
      "tweetId" : "1868569280327074189",
      "fullText" : "@lozzzTD @MemAiOfficial @gMetisl2 A wild one",
      "expandedUrl" : "https://twitter.com/i/web/status/1868569280327074189"
    }
  },
  {
    "like" : {
      "tweetId" : "1868570070924005589",
      "fullText" : "You know @MetisL2 is 💥 this week?\n\nBig wins, hot launches, and rewards raining down 🎉 Let’s break it all down👇\n\n1/ Ecosystem highlights\n🌿 New ThriveMetis Acclerate grantees @StrideSocials, @Gm2Social\n\n🌿 @MemAiOfficial $MEMAI token is live on @TheHerculesDEX, smashing $250K… https://t.co/d7yjIs3cpl",
      "expandedUrl" : "https://twitter.com/i/web/status/1868570070924005589"
    }
  },
  {
    "like" : {
      "tweetId" : "1868231619229986933",
      "fullText" : "@MetisL2 GMetis 🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1868231619229986933"
    }
  },
  {
    "like" : {
      "tweetId" : "1868226811240632812",
      "fullText" : "@MetisL2 gMetis 🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1868226811240632812"
    }
  },
  {
    "like" : {
      "tweetId" : "1868229232910106737",
      "fullText" : "@MetisL2 GMetis 🌿🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1868229232910106737"
    }
  },
  {
    "like" : {
      "tweetId" : "1868224560983662730",
      "fullText" : "there’s some chad builders here ngl\n\ntap in if you’re one 👇 https://t.co/ryPTnSAxyK",
      "expandedUrl" : "https://twitter.com/i/web/status/1868224560983662730"
    }
  },
  {
    "like" : {
      "tweetId" : "1868353461265547593",
      "fullText" : "@gMetisl2 @MetisL2 @MetisForgeDev Let´s go! Keep building! 👏👏 \n$METIS #AIAgents #Layer2 $ETH",
      "expandedUrl" : "https://twitter.com/i/web/status/1868353461265547593"
    }
  },
  {
    "like" : {
      "tweetId" : "1868391031391256809",
      "fullText" : "@_GemQueen @gMetisl2 @MetisL2 Yes, I think its well worth it.",
      "expandedUrl" : "https://twitter.com/i/web/status/1868391031391256809"
    }
  },
  {
    "like" : {
      "tweetId" : "1868299731253997819",
      "fullText" : "@gMetisl2 @MetisL2 @MetisForgeDev 👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1868299731253997819"
    }
  },
  {
    "like" : {
      "tweetId" : "1868301635799429519",
      "fullText" : "@cryptotrader85 @gMetisl2 @MetisL2 Definitely worth exploring @MetisL2 further",
      "expandedUrl" : "https://twitter.com/i/web/status/1868301635799429519"
    }
  },
  {
    "like" : {
      "tweetId" : "1868290904244805994",
      "fullText" : "@loqnft @despxwned @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1868290904244805994"
    }
  },
  {
    "like" : {
      "tweetId" : "1868290808400761242",
      "fullText" : "@despxwned I have not 1 but 2 AI agents\n@MemAiOfficial and @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1868290808400761242"
    }
  },
  {
    "like" : {
      "tweetId" : "1868263971981041892",
      "fullText" : "@Z_Cryptomaniac @MetisL2 @gMetisl2 @MemAiOfficial hmmm taking notes...",
      "expandedUrl" : "https://twitter.com/i/web/status/1868263971981041892"
    }
  },
  {
    "like" : {
      "tweetId" : "1868242352260968563",
      "fullText" : "Huge update from @gMetisl2 🔥\n\nOnce their AI Agent is live &amp; fully operational, we will be able to earn rewards 💰\n\nBy holding $gMetis in our wallets, we will receive boosted reward calculations &amp; the more engagements + more gMetis = higher rewards 🤯\n\n@MetisL2 AI Agent season is… https://t.co/yDl58e0DUE",
      "expandedUrl" : "https://twitter.com/i/web/status/1868242352260968563"
    }
  },
  {
    "like" : {
      "tweetId" : "1868251714031354130",
      "fullText" : "@Z_Cryptomaniac @gMetisl2 @MetisL2 🤝",
      "expandedUrl" : "https://twitter.com/i/web/status/1868251714031354130"
    }
  },
  {
    "like" : {
      "tweetId" : "1868250843499438305",
      "fullText" : "@cryptotrader85 @gMetisl2 @MetisL2 Agree my man",
      "expandedUrl" : "https://twitter.com/i/web/status/1868250843499438305"
    }
  },
  {
    "like" : {
      "tweetId" : "1868244589527941295",
      "fullText" : "@Z_Cryptomaniac @gMetisl2 @MetisL2 Its great to see my friend!\n\n2025 is shaping up to be a big year for Metis &amp; especially if we can attract a lot more people into the ecosystem.",
      "expandedUrl" : "https://twitter.com/i/web/status/1868244589527941295"
    }
  },
  {
    "like" : {
      "tweetId" : "1868243749236834516",
      "fullText" : "@cryptotrader85 @gMetisl2 @MetisL2 That will be a huge milestone my friend, finally AI agents on @MetisL2 are happening and are super low cap",
      "expandedUrl" : "https://twitter.com/i/web/status/1868243749236834516"
    }
  },
  {
    "like" : {
      "tweetId" : "1868064300927185134",
      "fullText" : "@MetisHero Both on Metis, @MemAiOfficial \nAnd @gMetisl2  man on @TheHerculesDEX",
      "expandedUrl" : "https://twitter.com/i/web/status/1868064300927185134"
    }
  },
  {
    "like" : {
      "tweetId" : "1868072482823107026",
      "fullText" : "@MetisForgeDev @MemAiOfficial @gMetisl2 Great",
      "expandedUrl" : "https://twitter.com/i/web/status/1868072482823107026"
    }
  },
  {
    "like" : {
      "tweetId" : "1868072559838675293",
      "fullText" : "@MetisForgeDev @MemAiOfficial @gMetisl2 Great  week",
      "expandedUrl" : "https://twitter.com/i/web/status/1868072559838675293"
    }
  },
  {
    "like" : {
      "tweetId" : "1868100572752363583",
      "fullText" : "@MetisForgeDev @MemAiOfficial @gMetisl2 Applause for This Project! Their groundbreaking work is truly reshaping the crypto landscape. The team’s passion and innovation are setting new heights. Keep up the excellent work!",
      "expandedUrl" : "https://twitter.com/i/web/status/1868100572752363583"
    }
  },
  {
    "like" : {
      "tweetId" : "1868145364899144094",
      "fullText" : "@cryptoskullx @MetisForgeDev METIS forge is one of two token launchers coming. Check out @pumpe_meme as well…\n\nMETIS forge has also bonded two tokens @MemAiOfficial and @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1868145364899144094"
    }
  },
  {
    "like" : {
      "tweetId" : "1868233969311027553",
      "fullText" : "@TheHerculesDEX the 2 AI agents on @MetisL2 …@gMetisl2 and @MemAiOfficial \nCheck tham out",
      "expandedUrl" : "https://twitter.com/i/web/status/1868233969311027553"
    }
  },
  {
    "like" : {
      "tweetId" : "1868045517751730645",
      "fullText" : "@MetisForgeDev @MemAiOfficial @gMetisl2 The fire has just started",
      "expandedUrl" : "https://twitter.com/i/web/status/1868045517751730645"
    }
  },
  {
    "like" : {
      "tweetId" : "1868049007160762531",
      "fullText" : "@CarsonYur @MemAiOfficial and @gMetisl2  are the ones, AI agent super low cap on @MetisL2 \nCan buy on @TheHerculesDEX \n💥",
      "expandedUrl" : "https://twitter.com/i/web/status/1868049007160762531"
    }
  },
  {
    "like" : {
      "tweetId" : "1868035023917789487",
      "fullText" : "@MetisForgeDev @MemAiOfficial @gMetisl2 Its been a great week for Metis Forge &amp; the projects that launched.\n\nLets keep this momentum going 🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1868035023917789487"
    }
  },
  {
    "like" : {
      "tweetId" : "1867902970194747491",
      "fullText" : "@MetisForgeDev @MemAiOfficial @gMetisl2 Fast indeed my friend",
      "expandedUrl" : "https://twitter.com/i/web/status/1867902970194747491"
    }
  },
  {
    "like" : {
      "tweetId" : "1867901272516596093",
      "fullText" : "Smoking hot, that's what we are right now\n\nWithin 2 days, 2 memes launched through our Dapp— @MemAiOfficial and @gMetisl2 \n\nThe fast fingers made their profits and they are happy. \n\nThis coming week, brace up as more is coming your way. https://t.co/U1PViOVfbh",
      "expandedUrl" : "https://twitter.com/i/web/status/1867901272516596093"
    }
  },
  {
    "like" : {
      "tweetId" : "1867875708217049199",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX Higher💥",
      "expandedUrl" : "https://twitter.com/i/web/status/1867875708217049199"
    }
  },
  {
    "like" : {
      "tweetId" : "1867874302642794899",
      "fullText" : "@0xcastra @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX Lets go &amp; keep this going!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867874302642794899"
    }
  },
  {
    "like" : {
      "tweetId" : "1867873316272238750",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX Both both are paving way for greater things to come",
      "expandedUrl" : "https://twitter.com/i/web/status/1867873316272238750"
    }
  },
  {
    "like" : {
      "tweetId" : "1867862097868292144",
      "fullText" : "@Z_Cryptomaniac @MetisForgeDev @MetisL2 @MemAiOfficial @gMetisl2 @FuturisToken isn’t just a meme—it’s a movement! 🚀 Live on @MetisForgeDev and making waves in the Metis ecosystem. The future is here, and it’s Futuris 🔮",
      "expandedUrl" : "https://twitter.com/i/web/status/1867862097868292144"
    }
  },
  {
    "like" : {
      "tweetId" : "1867861825024377164",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX @FuturisToken is live on @MetisForgeDev, bringing innovation and momentum to the Metis ecosystem! Join the journey and be part of something futuristic. Let's build together!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867861825024377164"
    }
  },
  {
    "like" : {
      "tweetId" : "1867861314305200416",
      "fullText" : "@Z_Cryptomaniac @MetisForgeDev @MetisL2 @MemAiOfficial @gMetisl2 Thrilled to see Futuris 🔮 featured on @MetisForgeDev! 🚀 Let's keep pushing the boundaries of memes within the Metis ecosystem. Big thanks for the support!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867861314305200416"
    }
  },
  {
    "like" : {
      "tweetId" : "1867860962923130911",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX 💯",
      "expandedUrl" : "https://twitter.com/i/web/status/1867860962923130911"
    }
  },
  {
    "like" : {
      "tweetId" : "1867860860812902449",
      "fullText" : "@MetisHero @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX That's true!\n\nWe need to get Metis rocking 🔥🔥🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1867860860812902449"
    }
  },
  {
    "like" : {
      "tweetId" : "1867860575726031255",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX If devs are based, they might pull it off 🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1867860575726031255"
    }
  },
  {
    "like" : {
      "tweetId" : "1867860094370922555",
      "fullText" : "@Z_Cryptomaniac @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX I agree, once more people start seeing memes &amp; AI Agents taking off on Metis then will want a piece of the action.",
      "expandedUrl" : "https://twitter.com/i/web/status/1867860094370922555"
    }
  },
  {
    "like" : {
      "tweetId" : "1867859870525038811",
      "fullText" : "@CryptoErwinNL @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX GM brother!\n\nHave a great day!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867859870525038811"
    }
  },
  {
    "like" : {
      "tweetId" : "1867859529809207753",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX Nice one man\nBoth have huge potential",
      "expandedUrl" : "https://twitter.com/i/web/status/1867859529809207753"
    }
  },
  {
    "like" : {
      "tweetId" : "1867859426868417027",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX Gm brother",
      "expandedUrl" : "https://twitter.com/i/web/status/1867859426868417027"
    }
  },
  {
    "like" : {
      "tweetId" : "1867859307368530376",
      "fullText" : "@FuturisToken @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX Its good to see Metis getting some attention.\n\nHopefully the momentum can continue 🔥\n\nLooking forward to it.",
      "expandedUrl" : "https://twitter.com/i/web/status/1867859307368530376"
    }
  },
  {
    "like" : {
      "tweetId" : "1867858833387012378",
      "fullText" : "@cryptotrader85 @MetisL2 @MemAiOfficial @MetisForgeDev @gMetisl2 @TheHerculesDEX Excited to see the momentum around us on Metis Forge! 🚀 We're just getting started—big things ahead for the ecosystem. Stay tuned for updates as we continue to build 🔮",
      "expandedUrl" : "https://twitter.com/i/web/status/1867858833387012378"
    }
  },
  {
    "like" : {
      "tweetId" : "1867857847847104984",
      "fullText" : "Meme season is starting to heat up on @MetisL2 🔥\n\n@MemAiOfficial was the first AI Agent to launch on @MetisForgeDev &amp; sold out in 10 minutes.\n\n@gMetisl2 AI Agent was next to reached quorum &amp; is now on @TheHerculesDEX \n\nCurrently there are two new memes on Metis Forge going… https://t.co/iQXoVXv1S0",
      "expandedUrl" : "https://twitter.com/i/web/status/1867857847847104984"
    }
  },
  {
    "like" : {
      "tweetId" : "1867855445940932800",
      "fullText" : "ALPHA update : \n\n@MetisForgeDev Is the Meme Platform on @MetisL2 \n\nWhere you can create and buy your favorite tokens\n\nAfter the successful launch of @MemAiOfficial  The first AI agent on $Metis ( sold in 10 minutes )\nAnd in quick succession @gMetisl2  AI agent with a twist \n\nIs…",
      "expandedUrl" : "https://twitter.com/i/web/status/1867855445940932800"
    }
  },
  {
    "like" : {
      "tweetId" : "1867889416846659691",
      "fullText" : "I’m in https://t.co/4z7xeAX1jD",
      "expandedUrl" : "https://twitter.com/i/web/status/1867889416846659691"
    }
  },
  {
    "like" : {
      "tweetId" : "1867687489299001476",
      "fullText" : "@gMetisl2 @MetisIntern @MetisL2 @MetisForgeDev @MemAiOfficial @MonkexNFT Hell yeah No aggressive move",
      "expandedUrl" : "https://twitter.com/i/web/status/1867687489299001476"
    }
  },
  {
    "like" : {
      "tweetId" : "1867687711445745898",
      "fullText" : "@gMetisl2 @MetisIntern @MetisL2 @MetisForgeDev @MemAiOfficial @MonkexNFT Let’s go guys",
      "expandedUrl" : "https://twitter.com/i/web/status/1867687711445745898"
    }
  },
  {
    "like" : {
      "tweetId" : "1867688364524421182",
      "fullText" : "@gMetisl2 @MetisIntern @MetisL2 @MetisForgeDev @MemAiOfficial @MonkexNFT We’re OG for Gmetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1867688364524421182"
    }
  },
  {
    "like" : {
      "tweetId" : "1867688748286431601",
      "fullText" : "@gMetisl2 @MetisIntern @MetisL2 @MetisForgeDev @MemAiOfficial @MonkexNFT Lfggg",
      "expandedUrl" : "https://twitter.com/i/web/status/1867688748286431601"
    }
  },
  {
    "like" : {
      "tweetId" : "1867688837964837174",
      "fullText" : "@Z_Cryptomaniac @TheHerculesDEX @gMetisl2 @MetisL2 Same here mate!\n\nI think 2025 will be a massive year!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867688837964837174"
    }
  },
  {
    "like" : {
      "tweetId" : "1867688931614998615",
      "fullText" : "@gMetisl2 @MetisIntern @MetisL2 @MetisForgeDev @MemAiOfficial @MonkexNFT Ofc we’re with @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1867688931614998615"
    }
  },
  {
    "like" : {
      "tweetId" : "1867689542360477756",
      "fullText" : "@ShroommaNL @TheHerculesDEX @gMetisl2 @MetisL2 @MetisPegasus @MetisForgeDev Awesome!\n\nAI Agents are the narrative right now &amp; they are just getting started on Metis.\n\nHopefully this can continue to run 🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1867689542360477756"
    }
  },
  {
    "like" : {
      "tweetId" : "1867689579907887333",
      "fullText" : "@gMetisl2 @MetisIntern @MetisL2 @MetisForgeDev @MemAiOfficial @MonkexNFT Thanks to @MetisL2 for this wonderful meme",
      "expandedUrl" : "https://twitter.com/i/web/status/1867689579907887333"
    }
  },
  {
    "like" : {
      "tweetId" : "1867680251863802191",
      "fullText" : "WHEN @MetisL2 MEME SUPERCYCLE???",
      "expandedUrl" : "https://twitter.com/i/web/status/1867680251863802191"
    }
  },
  {
    "like" : {
      "tweetId" : "1867679018356814018",
      "fullText" : "let's see if you're already working #Metis $METIS @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1867679018356814018"
    }
  },
  {
    "like" : {
      "tweetId" : "1867678493435466087",
      "fullText" : "@MetisForgeDev @MetisL2 @gMetisl2 The best Ai agent with a spectacular mission",
      "expandedUrl" : "https://twitter.com/i/web/status/1867678493435466087"
    }
  },
  {
    "like" : {
      "tweetId" : "1867676181962928553",
      "fullText" : "@Noahhweb3 Check @MemAiOfficial and @gMetisl2  two AI agents super low cap",
      "expandedUrl" : "https://twitter.com/i/web/status/1867676181962928553"
    }
  },
  {
    "like" : {
      "tweetId" : "1867677419043532905",
      "fullText" : "Bullish AF on this https://t.co/tSWYIMMkei",
      "expandedUrl" : "https://twitter.com/i/web/status/1867677419043532905"
    }
  },
  {
    "like" : {
      "tweetId" : "1867672136921624698",
      "fullText" : "@RedditCurrency @MetisL2 @MemAiOfficial @gMetisl2 @medusa_metis @dusa_metis @FuturisToken",
      "expandedUrl" : "https://twitter.com/i/web/status/1867672136921624698"
    }
  },
  {
    "like" : {
      "tweetId" : "1867669052870865388",
      "fullText" : "A new comer has arrived to the @MetisL2 ecosystem \nCalled @gMetisl2 \n\nIt is an AI agent with a mission\n\nTo Innovate\n\nTo merge fun with AI Driven community\n\nWhere members are recognized for their participation and engagement\n\nIt launched on @MetisForgeDev and is now Live on…",
      "expandedUrl" : "https://twitter.com/i/web/status/1867669052870865388"
    }
  },
  {
    "like" : {
      "tweetId" : "1867661267244347443",
      "fullText" : "Yoooooooooooo! Another reason not to miss out! https://t.co/MmScNxhJn9",
      "expandedUrl" : "https://twitter.com/i/web/status/1867661267244347443"
    }
  },
  {
    "like" : {
      "tweetId" : "1867662705064128775",
      "fullText" : "@cryptotrader85 @TheHerculesDEX @gMetisl2 @MetisL2 Love the potential of this token mate , love it a lot",
      "expandedUrl" : "https://twitter.com/i/web/status/1867662705064128775"
    }
  },
  {
    "like" : {
      "tweetId" : "1867646036447310212",
      "fullText" : "@cryptotrader85 @TheHerculesDEX @gMetisl2 @MetisL2 Just got myself some @gMetisl2 tokens, tried @MetisPegasus on @MetisForgeDev a while back but didn't go trough. So used the refunded Metis to get in on this one!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867646036447310212"
    }
  },
  {
    "like" : {
      "tweetId" : "1867578922185240863",
      "fullText" : "You’re standing on a gold mine right now.\n\nThe latest AI agent, $gMetis, has just launched on MetisForge! \n\nThis is the second AI agent on @MetisL2 , and if you know your way around memecoins, you already understand the potential here.\n\nTrade here👇\nhttps://t.co/zxZNC251Fa\n\n-",
      "expandedUrl" : "https://twitter.com/i/web/status/1867578922185240863"
    }
  },
  {
    "like" : {
      "tweetId" : "1867571424577139157",
      "fullText" : "Hey @MetisL2 @MetisDevs @0xQuantic @MetisFdn\n\nThe ultimate solution to make Metis explode is its ecosystem.\nAs a supporter and investor, I can confidently say that Metis is buzzing with activity right now.  So many campaigns both from Metis itself and its affiliated projects🧵",
      "expandedUrl" : "https://twitter.com/i/web/status/1867571424577139157"
    }
  },
  {
    "like" : {
      "tweetId" : "1867571426414256265",
      "fullText" : "it’s almost impossible to keep track of them all!\n\nWhat we need is a simple, dedicated website to consolidate all ongoing campaigns in one place. And yes, a native Metis wallet is essential too. Here’s a list of the active Metis campaigns (I’m sure I’m missing a few):",
      "expandedUrl" : "https://twitter.com/i/web/status/1867571426414256265"
    }
  },
  {
    "like" : {
      "tweetId" : "1867571430000406923",
      "fullText" : "- #ThriveMetis\n- #METIS x #ABGA x #GoogleCloud\n- @Gm2Social and @Artemisfinance\n-@medusa_metis  (@IntractCampaign &amp; @CoinMarketCap)\n- @moba_aof \n-@MetisForgeDev Forge (@MemAiOfficial and @gMetisl2)\n-@Coinstore\n-#METISVoyage\n-@pumpe_meme\n-Jenga\n-@BuzzWeb3_",
      "expandedUrl" : "https://twitter.com/i/web/status/1867571430000406923"
    }
  },
  {
    "like" : {
      "tweetId" : "1867571697953493480",
      "fullText" : "@Gm2Social @Artemisfinance @medusa_metis @IntractCampaign @CoinMarketCap @moba_aof @MetisForgeDev @MemAiOfficial @gMetisl2 @coinstore @pumpe_meme @BuzzWeb3_ Metis has so much going on that the community risks getting lost in the chaos!\nWe need a centralized platform to organize all initiatives and make it easier to:\n\nVerify active campaigns\n\nSee what actions to take\n\nMetis is in full swing—let’s make sure no one gets left behind!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867571697953493480"
    }
  },
  {
    "like" : {
      "tweetId" : "1867569484023689697",
      "fullText" : "Few know that we had a collab with 50 cent\n\nG-G-G-G-G-G-G-GMonkex\n\n#METIS #L2 #NFTs #Memes https://t.co/glcjUd7zit",
      "expandedUrl" : "https://twitter.com/i/web/status/1867569484023689697"
    }
  },
  {
    "like" : {
      "tweetId" : "1867553271407140948",
      "fullText" : "Day 1: Memethos - The AI Revolution Begins 🌿\n\n$MEMAI isn’t just a token; it’s a movement. Memes fuel us, AI drives us, and the community powers us.\n\nThe mission? Create the strongest memetic empire on @MetisL2.\n\nThe plan? Out-meme, outlast, and outgrow.\nWe don’t follow trends,we… https://t.co/UY6ChvhkAJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1867553271407140948"
    }
  },
  {
    "like" : {
      "tweetId" : "1867544621070369160",
      "fullText" : "@cryptotrader85 @TheHerculesDEX @gMetisl2 @MetisL2 Meme season ?",
      "expandedUrl" : "https://twitter.com/i/web/status/1867544621070369160"
    }
  },
  {
    "like" : {
      "tweetId" : "1867496354492322189",
      "fullText" : "gMetis🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1867496354492322189"
    }
  },
  {
    "like" : {
      "tweetId" : "1867496148183003427",
      "fullText" : "@CryptoErwinNL @TheHerculesDEX @gMetisl2 @MetisL2 Hey brother!\n\nHave a great day!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867496148183003427"
    }
  },
  {
    "like" : {
      "tweetId" : "1867495907991990438",
      "fullText" : "@cryptotrader85 @TheHerculesDEX @gMetisl2 @MetisL2 Gm brother",
      "expandedUrl" : "https://twitter.com/i/web/status/1867495907991990438"
    }
  },
  {
    "like" : {
      "tweetId" : "1867494472701079606",
      "fullText" : "@cryptotrader85 @TheHerculesDEX @gMetisl2 @MetisL2 The best Ai agent",
      "expandedUrl" : "https://twitter.com/i/web/status/1867494472701079606"
    }
  },
  {
    "like" : {
      "tweetId" : "1867495604936749469",
      "fullText" : "@ArakunrinA99075 @TheHerculesDEX @gMetisl2 @MetisL2 AI Agents on Metis are just getting started 🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1867495604936749469"
    }
  },
  {
    "like" : {
      "tweetId" : "1867495453102866770",
      "fullText" : "@Liikeey @TheHerculesDEX @gMetisl2 @MetisL2 No, Metis is starting to heat up!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867495453102866770"
    }
  },
  {
    "like" : {
      "tweetId" : "1867494307818791287",
      "fullText" : "@cryptotrader85 @TheHerculesDEX @gMetisl2 @MetisL2 We’re not playing here",
      "expandedUrl" : "https://twitter.com/i/web/status/1867494307818791287"
    }
  },
  {
    "like" : {
      "tweetId" : "1867495339177250983",
      "fullText" : "@likeeyMod @TheHerculesDEX @gMetisl2 @MetisL2 🚀🚀🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1867495339177250983"
    }
  },
  {
    "like" : {
      "tweetId" : "1867494225593741646",
      "fullText" : "@cryptotrader85 @TheHerculesDEX @gMetisl2 @MetisL2 Lfg gmetis is here for you",
      "expandedUrl" : "https://twitter.com/i/web/status/1867494225593741646"
    }
  },
  {
    "like" : {
      "tweetId" : "1867490475864994216",
      "fullText" : "A second AI Agent on Metis Forge has reached quorum &amp; is now live on @TheHerculesDEX\n\n@gMetisl2 reach 120 $METIS in 2hrs 🤯\n\n👉 https://t.co/7UyJOATJbZ\n\nMeme season is really starting to heat up now on @MetisL2 🔥\n\nIf you want in early, then I highly recommend keeping an eye on… https://t.co/7zUTdkZXjd",
      "expandedUrl" : "https://twitter.com/i/web/status/1867490475864994216"
    }
  },
  {
    "like" : {
      "tweetId" : "1867473579001962941",
      "fullText" : "An other Agent  gMetis \nis live on \n\n@TheHerculesDEX dex it was launched and reached quorum\nSo quickly that we all missed it \n\nAll details here \n\nhttps://t.co/PhIVqitUOS\n\nNo Lock \n\nNo Tax\n\nJust fair launch and you can trade it here right now\n\n@TheHerculesDEX…",
      "expandedUrl" : "https://twitter.com/i/web/status/1867473579001962941"
    }
  },
  {
    "like" : {
      "tweetId" : "1867426665447797048",
      "fullText" : "@gMetisl2 @MetisHero Go for it! Make $METIS great again!",
      "expandedUrl" : "https://twitter.com/i/web/status/1867426665447797048"
    }
  },
  {
    "like" : {
      "tweetId" : "1867291729075818643",
      "fullText" : "𝐌𝐢𝐧𝐮𝐭𝐞𝐬: \"𝐇𝐨𝐰 𝐭𝐨 𝐁𝐮𝐢𝐥𝐝 𝐓𝐫𝐮𝐬𝐭 𝐢𝐧 𝐚 𝐓𝐫𝐮𝐬𝐭𝐥𝐞𝐬𝐬 𝐖𝐨𝐫𝐥𝐝\"\n(A very insightful space hosted by @YetiApes)\n\nOpening Thoughts\n\n@CanerIrina: “Trust is like glue; it holds relationships and communities together.” Projects like @FuturisToken 🔮 are… https://t.co/ErW9gu2EmD https://t.co/BBXcuy7l2J",
      "expandedUrl" : "https://twitter.com/i/web/status/1867291729075818643"
    }
  },
  {
    "like" : {
      "tweetId" : "1867030246811373598",
      "fullText" : "@josefabregab @MetisL2 @TheHerculesDEX @ZenoExchange @Artemisfinance @DeFiKingdoms @moba_aof @MemAiOfficial You forget about $MONKEX Jose? Metis already has an OG meme that is CEG approved and has been around for over 2 years. When will everyone stop fading Monkex??? https://t.co/0xV9cKGETr",
      "expandedUrl" : "https://twitter.com/i/web/status/1867030246811373598"
    }
  },
  {
    "like" : {
      "tweetId" : "1866888471874248965",
      "fullText" : "Why am I still bullish on @MetisL2 Ecosystem?\n\nEven w/ the recent Tethys situation, I'm more optimistic than I've ever been....\n\nKeep your eyes on these 👇\n\n🌿 @MetisForgeDev \n🌿 @pumpe_meme \n🌿 @medusa_metis \n🌿 @dusa_metis \n🌿 @MemAiOfficial",
      "expandedUrl" : "https://twitter.com/i/web/status/1866888471874248965"
    }
  },
  {
    "like" : {
      "tweetId" : "1866249086673752254",
      "fullText" : "Look at the on-chain metrics...what do you see? 👀\n\n@MetisL2 Active addresses up only, with unique addresses surpassing 1.3M 📈 \n\nOver $30m in volume on Hercules for 4 weeks straight! 📈\n\nTo top it all, something new is coming for YOU...👀\n\n#Metis https://t.co/V0hSaGFwnU",
      "expandedUrl" : "https://twitter.com/i/web/status/1866249086673752254"
    }
  },
  {
    "like" : {
      "tweetId" : "1866827289037779104",
      "fullText" : "#BEES on BUZZ🐝\nBuzzin' with the Best \n\n#meme #METIS #buzz @BuzzWeb3_ https://t.co/EsPtJXbuhk",
      "expandedUrl" : "https://twitter.com/i/web/status/1866827289037779104"
    }
  },
  {
    "like" : {
      "tweetId" : "1866790802946499034",
      "fullText" : "gMETIS🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1866790802946499034"
    }
  },
  {
    "like" : {
      "tweetId" : "1866785005638123962",
      "fullText" : "The @MetisL2 ecosystem will soon have them all:\n\n✅ DEXs (@TheHerculesDEX)\n✅ Perps (@ZenoExchange)\n✅ Liquid Staking Tokens (@Artemisfinance)\n✅ GameFi (@DeFiKingdoms @moba_aof)\n✅ AI Agents (@MemAiOfficial + more coming)\n❌ Memes (Soon)\n\nThe last vertical could make fireworks.",
      "expandedUrl" : "https://twitter.com/i/web/status/1866785005638123962"
    }
  },
  {
    "like" : {
      "tweetId" : "1863917273297117457",
      "fullText" : "We've listened, renovated and upgraded.\n\nhttps://t.co/GJa4DbmUu1 is now better than ever.\n\nHere are the new features we added🧵 https://t.co/TKoBv75914",
      "expandedUrl" : "https://twitter.com/i/web/status/1863917273297117457"
    }
  },
  {
    "like" : {
      "tweetId" : "1866412539614994800",
      "fullText" : "AI Agents are launching on @MetisL2 as we speak. \n\nThis $METIS catalyst hasn't been discussed much, but can be huge.\n\nAI Agents with tokens could kick off the Metis meme supercycle earlier than expected. Plus, add @stakedotlink, @DeFiKingdoms's incentives, Winks, and more. Big.",
      "expandedUrl" : "https://twitter.com/i/web/status/1866412539614994800"
    }
  },
  {
    "like" : {
      "tweetId" : "1866407915562704998",
      "fullText" : "$MEMAI isn't your average ride. It's a wave of innovation, a flood of meme-driven economy. Afraid to get your feet wet? Change requires bold steps. Dive in and make waves, or be forgotten in the backwash.",
      "expandedUrl" : "https://twitter.com/i/web/status/1866407915562704998"
    }
  },
  {
    "like" : {
      "tweetId" : "1866172723933638916",
      "fullText" : "Lots of stuff going on for $METIS in the background\n\nCan’t wait for things to really get rolling",
      "expandedUrl" : "https://twitter.com/i/web/status/1866172723933638916"
    }
  },
  {
    "like" : {
      "tweetId" : "1866077165478920525",
      "fullText" : ".@MetisL2 will cook so hard this cycle\n\nI don't just know it, I feel it too🌿\n\nGMetis &amp; happy new week! https://t.co/bYtMKQ6FlY",
      "expandedUrl" : "https://twitter.com/i/web/status/1866077165478920525"
    }
  },
  {
    "like" : {
      "tweetId" : "1866057796317241419",
      "fullText" : "gmonday Metisians 🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1866057796317241419"
    }
  },
  {
    "like" : {
      "tweetId" : "1864852644545679652",
      "fullText" : "🗣️ Call for Builders!\n\nWe’re hosting an exclusive workshop on Building a Telegram Mini App with Thirdweb 🤳\n\n📅 Saturday, Dec 9, at 5:00 PM UTC / 12:00 PM EST\n\nWhat’s in it for you?\nLearn how to create a Telegram Mini App using Thirdweb on Metis🌿, and discover how to streamline… https://t.co/l4OJdaHAh2",
      "expandedUrl" : "https://twitter.com/i/web/status/1864852644545679652"
    }
  },
  {
    "like" : {
      "tweetId" : "1865854889097597363",
      "fullText" : "First AI Agent coming to @MetisL2 anytime soon?\n\nMy whistleblower says yes 👀 https://t.co/mnBLSH2JRP",
      "expandedUrl" : "https://twitter.com/i/web/status/1865854889097597363"
    }
  },
  {
    "like" : {
      "tweetId" : "1865468774595395721",
      "fullText" : "I think AI agent innovation on blockchain is just beginning and we haven't seen much yet.\n\nThe opportunity seems huge, I haven't felt something like this for some time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1865468774595395721"
    }
  },
  {
    "like" : {
      "tweetId" : "1865054416161693774",
      "fullText" : "Ethereum. Metis. Chainlink.",
      "expandedUrl" : "https://twitter.com/i/web/status/1865054416161693774"
    }
  },
  {
    "like" : {
      "tweetId" : "1865325456880181436",
      "fullText" : "brb scaling Ethereum",
      "expandedUrl" : "https://twitter.com/i/web/status/1865325456880181436"
    }
  },
  {
    "like" : {
      "tweetId" : "1865486436872438172",
      "fullText" : "I've heard there's some memes being cooked on @MetisL2 with support from very large names (individuals and organizations).\n\nPopular memes have been hitting $500M-$1B MCs. If a memecoin hits that market cap on the Metis eco, $METIS would send HARD, given its MC is not even $500M.",
      "expandedUrl" : "https://twitter.com/i/web/status/1865486436872438172"
    }
  },
  {
    "like" : {
      "tweetId" : "1864962988765319628",
      "fullText" : "Aave and Metis are working on a Strategic Alignment Initiative, as per the newest @aave proposal submitted by @AaveChan.\n\n- Creation of an Aave sequencer node\n- Develop Metis-specific use cases for GHO\n- Position @MetisL2 as an integral part of the Aave ecosystem\n\nThis is big.",
      "expandedUrl" : "https://twitter.com/i/web/status/1864962988765319628"
    }
  },
  {
    "like" : {
      "tweetId" : "1864965940854587628",
      "fullText" : "nonstop building…",
      "expandedUrl" : "https://twitter.com/i/web/status/1864965940854587628"
    }
  },
  {
    "like" : {
      "tweetId" : "1864601579581559005",
      "fullText" : "/)_/)\n(,,&gt;.&lt;)  &lt;(gmetis, this is for you)\n/ &gt;🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1864601579581559005"
    }
  },
  {
    "like" : {
      "tweetId" : "1864319800203215106",
      "fullText" : "this is how you're doing your first steps on Metis\n\nCheck this out👇 https://t.co/P2hgid48OU",
      "expandedUrl" : "https://twitter.com/i/web/status/1864319800203215106"
    }
  },
  {
    "like" : {
      "tweetId" : "1864238296324338029",
      "fullText" : "new day to grind\n\nlet’s get it, Metisians",
      "expandedUrl" : "https://twitter.com/i/web/status/1864238296324338029"
    }
  },
  {
    "like" : {
      "tweetId" : "1864229874602295549",
      "fullText" : "@gMetisl2 Originally, it was gMonkex just to let you know lol",
      "expandedUrl" : "https://twitter.com/i/web/status/1864229874602295549"
    }
  },
  {
    "like" : {
      "tweetId" : "1864001304307069176",
      "fullText" : "Alpha from Elena herself on the #Metis Morning Show:\n\n#Metis will be upgrading to being a stage 1 L2 with fault proofs and Blobs going live, while still running on the decentralized Sequencer.\n\nETA: Q1 2025 latest.\n\nYou are not bullish enough on #Metis.",
      "expandedUrl" : "https://twitter.com/i/web/status/1864001304307069176"
    }
  },
  {
    "like" : {
      "tweetId" : "1864015133246153082",
      "fullText" : "The power of @Chainlink CCIP expands on the Metis🌿 ecosystem with XSwap!\n\n@XSwap_Link integration means:\n🔵 Seamless cross-chain swaps\n🔵 Enhanced liquidity flows\n🔵 New trading opportunities\n🔵 Broader market access\n\nThis integration is part of building a truly cross-chain… https://t.co/hwnfzbAr2u",
      "expandedUrl" : "https://twitter.com/i/web/status/1864015133246153082"
    }
  },
  {
    "like" : {
      "tweetId" : "1863580501073695218",
      "fullText" : "I'm super pumped on $METIS 🌿\n\nMetis has been increasing in its daily active users to reach its previous ATH of 42k; currently, it stands at 32k per day.\n\nIts total unique addresses are approaching 1.3M\n\nDecember could potentially be the month to reach new all-time highs... \n\nWe… https://t.co/9ie9qrYo2o",
      "expandedUrl" : "https://twitter.com/i/web/status/1863580501073695218"
    }
  },
  {
    "like" : {
      "tweetId" : "1863632020448088081",
      "fullText" : "GM $METIS fam. Do you think we can hit new all time high this month? \n\nLooking at current developments. I have a strong feeling we can! Comment your opinion ⤵️",
      "expandedUrl" : "https://twitter.com/i/web/status/1863632020448088081"
    }
  },
  {
    "like" : {
      "tweetId" : "1863947113543184568",
      "fullText" : "Can't wait for $METIS ecosystem to start flourishing! Which sectors would pump the hardest tho?",
      "expandedUrl" : "https://twitter.com/i/web/status/1863947113543184568"
    }
  },
  {
    "like" : {
      "tweetId" : "1863509984606077010",
      "fullText" : "gmetis fam\n\nready to close this year off stronger than we started\n\nkeep 🔔 on",
      "expandedUrl" : "https://twitter.com/i/web/status/1863509984606077010"
    }
  },
  {
    "like" : {
      "tweetId" : "1864013420074344761",
      "fullText" : "No More Bears 🧸 $NEXA https://t.co/An9w1Fy4Tc",
      "expandedUrl" : "https://twitter.com/i/web/status/1864013420074344761"
    }
  },
  {
    "like" : {
      "tweetId" : "1864070977421824497",
      "fullText" : "@gMetisl2 @MetisL2 Ahahahahhahhaa good one",
      "expandedUrl" : "https://twitter.com/i/web/status/1864070977421824497"
    }
  },
  {
    "like" : {
      "tweetId" : "1876259028038451421",
      "fullText" : "GMetis 🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1876259028038451421"
    }
  },
  {
    "like" : {
      "tweetId" : "1876252379022074013",
      "fullText" : "First gmetis of the year \nHow many can I get back? 👀\n\n(𝘕𝘦𝘦𝘥 𝘢𝘵 𝘭𝘦𝘢𝘴𝘵 5 𝘳𝘦𝘱𝘭𝘪𝘦𝘴 𝘰𝘳 𝘪𝘯𝘵𝘦𝘳𝘯 𝘪𝘴 𝘪𝘯 𝘵𝘳𝘰𝘶𝘣𝘭𝘦!)",
      "expandedUrl" : "https://twitter.com/i/web/status/1876252379022074013"
    }
  },
  {
    "like" : {
      "tweetId" : "1876717557354262766",
      "fullText" : "Most growth happens outside the comfort zone.",
      "expandedUrl" : "https://twitter.com/i/web/status/1876717557354262766"
    }
  },
  {
    "like" : {
      "tweetId" : "1876347790785462385",
      "fullText" : "@gMetisl2 gM gMetis!!",
      "expandedUrl" : "https://twitter.com/i/web/status/1876347790785462385"
    }
  },
  {
    "like" : {
      "tweetId" : "1876559486174826720",
      "fullText" : "decentralized sequencers\nLSTs\nDeFi\naligned incentives\n\ngmetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1876559486174826720"
    }
  },
  {
    "like" : {
      "tweetId" : "1876322597291598277",
      "fullText" : "Ai agents are pumping 10x here and there! Freaking crazy! And it's just getting started. \n\n@gMetisl2 coming soon too! Watch out!",
      "expandedUrl" : "https://twitter.com/i/web/status/1876322597291598277"
    }
  },
  {
    "like" : {
      "tweetId" : "1876226607356203171",
      "fullText" : "@MartiniGuyYT $gMetis dev is a chad. Check em out @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1876226607356203171"
    }
  },
  {
    "like" : {
      "tweetId" : "1876151249265111352",
      "fullText" : "Ok ok \nGmetis🌿 https://t.co/E1SgLBIB7R",
      "expandedUrl" : "https://twitter.com/i/web/status/1876151249265111352"
    }
  },
  {
    "like" : {
      "tweetId" : "1875939062571503651",
      "fullText" : "Hearing things about @MetisL2 agents and memes.\n\nHearing things about Q1 gud Q.",
      "expandedUrl" : "https://twitter.com/i/web/status/1875939062571503651"
    }
  },
  {
    "like" : {
      "tweetId" : "1875963176229224669",
      "fullText" : "First thread of 2025 to come ✍️🔔",
      "expandedUrl" : "https://twitter.com/i/web/status/1875963176229224669"
    }
  },
  {
    "like" : {
      "tweetId" : "1875941332205842609",
      "fullText" : "@josefabregab @MetisL2 @gMetisl2 is launching their agent in the 12th",
      "expandedUrl" : "https://twitter.com/i/web/status/1875941332205842609"
    }
  },
  {
    "like" : {
      "tweetId" : "1875697341661134961",
      "fullText" : "AI agents will democratize access to investing like we have never seen before.",
      "expandedUrl" : "https://twitter.com/i/web/status/1875697341661134961"
    }
  },
  {
    "like" : {
      "tweetId" : "1875634119893528623",
      "fullText" : "@gMetisl2 https://t.co/mCjEzUkpzR",
      "expandedUrl" : "https://twitter.com/i/web/status/1875634119893528623"
    }
  },
  {
    "like" : {
      "tweetId" : "1875643136837566920",
      "fullText" : "@MetisInsiders @MetisL2 Say $Metis hits 400 where does that leave eco leaders on Defi, MEME, AI Agents?\n(Talking only about Metis first projects - we know Link and Aave will do just fine)\n\n@MetisL2 @TheHerculesDEX @ENKIProtocol @Artemisfinance @MonkexNFT @MemAiOfficial @gMetisl2 @VestaDAO",
      "expandedUrl" : "https://twitter.com/i/web/status/1875643136837566920"
    }
  },
  {
    "like" : {
      "tweetId" : "1875446578280067413",
      "fullText" : "I’m hunting for a 10x with @MetisL2 in 2025 💎 \n\nTime to plant some seeds and watch them grow 🌿Here’s my play:\n\n🔥 Wave 2 zone: Current price sits perfectly in Wave 2 of Elliott Wave.\n\n🔥 CHoCH confirmed: A structural shift on higher timeframes, with liquidity sweeps around the… https://t.co/wIpRmuTkUW",
      "expandedUrl" : "https://twitter.com/i/web/status/1875446578280067413"
    }
  },
  {
    "like" : {
      "tweetId" : "1875593569140174874",
      "fullText" : "No word about what is coming yet but the effect is obvious on the chart🔥🌿 https://t.co/vnii9s3lJW",
      "expandedUrl" : "https://twitter.com/i/web/status/1875593569140174874"
    }
  },
  {
    "like" : {
      "tweetId" : "1874992522046631964",
      "fullText" : "Starting the year with 3x. Very nice! \n\nExpecting $gMetis to fly soon once beta agent ai goes live. $30k mcap is a murder",
      "expandedUrl" : "https://twitter.com/i/web/status/1874992522046631964"
    }
  },
  {
    "like" : {
      "tweetId" : "1875487111308308761",
      "fullText" : "@gMetisl2 😂",
      "expandedUrl" : "https://twitter.com/i/web/status/1875487111308308761"
    }
  },
  {
    "like" : {
      "tweetId" : "1875488473429504437",
      "fullText" : "@gMetisl2 gMetis @gMetisl2 https://t.co/6YjANpQhIN",
      "expandedUrl" : "https://twitter.com/i/web/status/1875488473429504437"
    }
  },
  {
    "like" : {
      "tweetId" : "1875489878546554906",
      "fullText" : "@gMetisl2 Something chilled as @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1875489878546554906"
    }
  },
  {
    "like" : {
      "tweetId" : "1875490411994869942",
      "fullText" : "@gMetisl2 gmetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1875490411994869942"
    }
  },
  {
    "like" : {
      "tweetId" : "1875491127039815821",
      "fullText" : "@gMetisl2 @gmetis @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1875491127039815821"
    }
  },
  {
    "like" : {
      "tweetId" : "1875491834291745113",
      "fullText" : "@gMetisl2 🔥🔥🔥🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1875491834291745113"
    }
  },
  {
    "like" : {
      "tweetId" : "1875491729820020859",
      "fullText" : "@gMetisl2 Gmetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1875491729820020859"
    }
  },
  {
    "like" : {
      "tweetId" : "1875491961416904765",
      "fullText" : "@gMetisl2 🌿🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1875491961416904765"
    }
  },
  {
    "like" : {
      "tweetId" : "1875530439299100775",
      "fullText" : "@gMetisl2 Looks like he's holding the blueprint to alpha success...",
      "expandedUrl" : "https://twitter.com/i/web/status/1875530439299100775"
    }
  },
  {
    "like" : {
      "tweetId" : "1875530781134819611",
      "fullText" : "@gMetisl2 Probably a bag... you know the kind. 🤑",
      "expandedUrl" : "https://twitter.com/i/web/status/1875530781134819611"
    }
  },
  {
    "like" : {
      "tweetId" : "1875376825385545746",
      "fullText" : "I'm telling you it's good https://t.co/y3XybpxQW6 https://t.co/OcH2oFSmPA",
      "expandedUrl" : "https://twitter.com/i/web/status/1875376825385545746"
    }
  },
  {
    "like" : {
      "tweetId" : "1875295959703605628",
      "fullText" : "@WisdomMatic We have memes that behave the exact way like this too",
      "expandedUrl" : "https://twitter.com/i/web/status/1875295959703605628"
    }
  },
  {
    "like" : {
      "tweetId" : "1875452210920018306",
      "fullText" : "gMetis🌿\ngVesta \n\nWhat do you do on weekends👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1875452210920018306"
    }
  },
  {
    "like" : {
      "tweetId" : "1875472315166671005",
      "fullText" : "build.\ninnovate.\nscale.\ndecentralize.",
      "expandedUrl" : "https://twitter.com/i/web/status/1875472315166671005"
    }
  },
  {
    "like" : {
      "tweetId" : "1875447877335650342",
      "fullText" : "Recently I joined one telegram group associated with @gMetisl2 which is related to Ai token on Metis layer2 blockchain\nMany fun activitiee happen there like quiz , trivia etc \n\nIf you want to experience such project, come and join here 👇\n\nhttps://t.co/DW5mimnYGe",
      "expandedUrl" : "https://twitter.com/i/web/status/1875447877335650342"
    }
  },
  {
    "like" : {
      "tweetId" : "1875323311460381018",
      "fullText" : "@MichaelSuppo @gMetisl2 on METIS chain \n$37k MCAP \n\nRead here: https://t.co/k4f4Yn6z6E",
      "expandedUrl" : "https://twitter.com/i/web/status/1875323311460381018"
    }
  },
  {
    "like" : {
      "tweetId" : "1875259464875700637",
      "fullText" : "The Metis ecosystem is about to go wild and @gMetisl2 is the first Metis AI Agent going into a 3 day Beta on Jan 12th.  gMetis will distribute rewards to most active supporter across TG and X daily.\n\nJoin now and share rewards. \n\nhttps://t.co/i4YKh74gXD",
      "expandedUrl" : "https://twitter.com/i/web/status/1875259464875700637"
    }
  },
  {
    "like" : {
      "tweetId" : "1875284358137049211",
      "fullText" : "Monkex didn't just get privileges of using OG title, we earned it\n\nall our OGs have web3 experience, and from this we make our statements and predictions\n\nyou might not like it, but we have never been wrong in our predictions, just saying",
      "expandedUrl" : "https://twitter.com/i/web/status/1875284358137049211"
    }
  },
  {
    "like" : {
      "tweetId" : "1875255882126389297",
      "fullText" : "It's been really interesting to work directly with devs playing with AI agents and see humans so involved in helping these new entities so they can help us in return.",
      "expandedUrl" : "https://twitter.com/i/web/status/1875255882126389297"
    }
  },
  {
    "like" : {
      "tweetId" : "1875275353876476144",
      "fullText" : "𝐀𝐬 𝐚 𝐜𝐫𝐲𝐩𝐭𝐨 𝐞𝐧𝐭𝐡𝐮𝐬𝐢𝐚𝐬𝐭, 𝐈'𝐦 𝐚𝐥𝐰𝐚𝐲𝐬 𝐨𝐧 𝐭𝐡𝐞 𝐥𝐨𝐨𝐤𝐨𝐮𝐭 𝐟𝐨𝐫 𝐞𝐱𝐜𝐢𝐭𝐢𝐧𝐠 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬. #gMetis 𝐢𝐬 𝐨𝐧𝐞 𝐨𝐟 𝐭𝐡𝐞𝐦.\n@gMetisl2 \n\n🧵👇 https://t.co/9y6Zkp10LV",
      "expandedUrl" : "https://twitter.com/i/web/status/1875275353876476144"
    }
  },
  {
    "like" : {
      "tweetId" : "1875243711568986597",
      "fullText" : "@gMetisl2 @MetisL2 Hope you can hold in more pressure \n\nWe about to send in more air to get you more pumped",
      "expandedUrl" : "https://twitter.com/i/web/status/1875243711568986597"
    }
  },
  {
    "like" : {
      "tweetId" : "1875241261185298739",
      "fullText" : "https://t.co/ifZf6qcGn4",
      "expandedUrl" : "https://twitter.com/i/web/status/1875241261185298739"
    }
  },
  {
    "like" : {
      "tweetId" : "1875210591704699102",
      "fullText" : "gm frens\n\nLet’s take $METIS to the moon in 2025 🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1875210591704699102"
    }
  },
  {
    "like" : {
      "tweetId" : "1875173367990415513",
      "fullText" : "Q1 might be @MetisL2’s last chance to become a Top 5 ETH L2 again, and I doubt they’ll waste it. The playbook is simple:\n\n• Double down on @chainlink &amp; $LINK\n• Double down on DeFi (@aave, LPs for ETH and stables, native DeFi app)\n• Double down on AI Agents\n• Build launchpad…",
      "expandedUrl" : "https://twitter.com/i/web/status/1875173367990415513"
    }
  },
  {
    "like" : {
      "tweetId" : "1875197703958962378",
      "fullText" : "@alessan00412670 @MetisForgeDev @gMetisl2 This tag makes much more sense.",
      "expandedUrl" : "https://twitter.com/i/web/status/1875197703958962378"
    }
  },
  {
    "like" : {
      "tweetId" : "1875196405054333055",
      "fullText" : "@MetisForgeDev @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1875196405054333055"
    }
  },
  {
    "like" : {
      "tweetId" : "1875109931453489215",
      "fullText" : "first gmetis of the year 🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1875109931453489215"
    }
  },
  {
    "like" : {
      "tweetId" : "1875094258048454897",
      "fullText" : "@MetisForgeDev 🗳️Community Verified Project\n\n🤖 that is developing a custom AI Agent from scratch \n\n🔐and not relying on some third party \n\n👉so have the complete freedom to create their own business model? Including a whole new sevice - Agent as a Servide?\n\nSounds like something 👀\n@gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1875094258048454897"
    }
  },
  {
    "like" : {
      "tweetId" : "1875087436193124632",
      "fullText" : "AI + Crypto is the hottest narrative right now!\n\nThink about it:\n\n- AI brings intelligence, efficiency, and automation.\n\n- Crypto brings decentralization, transparency, and security.\n\nOne of the best applications of this combo? \n\nAI agents—autonomous tools that can be designed to… https://t.co/EaNpDasDej",
      "expandedUrl" : "https://twitter.com/i/web/status/1875087436193124632"
    }
  },
  {
    "like" : {
      "tweetId" : "1874978471165952292",
      "fullText" : "#AI is pumping! $gMETIS will have its working Ai Agent soon. Only at $30k marketcap. \n\nGonna go hard soon!",
      "expandedUrl" : "https://twitter.com/i/web/status/1874978471165952292"
    }
  },
  {
    "like" : {
      "tweetId" : "1874547194017337808",
      "fullText" : "Reflect on New Year, Reflect everyday! We are up over 27% today but is probably nothing🌿🔥 https://t.co/BbrQJWmEsW",
      "expandedUrl" : "https://twitter.com/i/web/status/1874547194017337808"
    }
  },
  {
    "like" : {
      "tweetId" : "1874525134494855360",
      "fullText" : "First day of the year and Metis devs are shipping ✌️ https://t.co/KMAtxFuXAR",
      "expandedUrl" : "https://twitter.com/i/web/status/1874525134494855360"
    }
  },
  {
    "like" : {
      "tweetId" : "1874474736828420459",
      "fullText" : "GM 2025! It's a blessed day! \n\nLet your 2025 be prosperous! https://t.co/QVU2zFen3u",
      "expandedUrl" : "https://twitter.com/i/web/status/1874474736828420459"
    }
  },
  {
    "like" : {
      "tweetId" : "1874389429260783957",
      "fullText" : "Happy New Year, Forgians!\n\nThank you for supporting us last year and helping us achieve our 2024 goals.\n\nAs we step into 2025, let’s:\n\n✅Set even bigger goals.\n✅Take bolder actions to achieve them.\n ✅Embrace limitless possibilities.\n\nLet’s make this our best year yet! \n\nThank… https://t.co/fMGh5imGYm",
      "expandedUrl" : "https://twitter.com/i/web/status/1874389429260783957"
    }
  },
  {
    "like" : {
      "tweetId" : "1874377305541492980",
      "fullText" : "GM and Happy New Year all you $Monkex family and Metisians!\n2025 is here and the culture will live on and remain strong. \nGood times ahead for $Metis, $Monkex and the ecosystem 🔥 https://t.co/ZL0Da0fwzk",
      "expandedUrl" : "https://twitter.com/i/web/status/1874377305541492980"
    }
  },
  {
    "like" : {
      "tweetId" : "1873897362999173404",
      "fullText" : "We are bullish on 2025\nWe are bullish on crypto\nWe are bullish on @MetisL2 \nWe are the bulls and nothing can stop us 🐂 https://t.co/aouGieCMDM",
      "expandedUrl" : "https://twitter.com/i/web/status/1873897362999173404"
    }
  },
  {
    "like" : {
      "tweetId" : "1874186251362095561",
      "fullText" : "Quzzzt! Quzzzt! Beep-boop-quaaaak!",
      "expandedUrl" : "https://twitter.com/i/web/status/1874186251362095561"
    }
  },
  {
    "like" : {
      "tweetId" : "1873999612371231043",
      "fullText" : "final gMetis 🌿for 2024🌤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1873999612371231043"
    }
  },
  {
    "like" : {
      "tweetId" : "1874138699895590932",
      "fullText" : "🎉 Happy New Year, @MetisL2 fam!\n\n2024 was epic, but 2025? We're going bigger, better, and bolder 🚀\n\nHuge thanks to all builders, partners, and community for making it all happen 🌿🔥\n\nHere’s to 2025 - more wins, more growth, more $METIS magic 🥂 https://t.co/uiUkeHEHBU",
      "expandedUrl" : "https://twitter.com/i/web/status/1874138699895590932"
    }
  },
  {
    "like" : {
      "tweetId" : "1874142924105277816",
      "fullText" : "@MacroCRG Are you referring to me?\n\nYhhh that's my plan for 2025",
      "expandedUrl" : "https://twitter.com/i/web/status/1874142924105277816"
    }
  },
  {
    "like" : {
      "tweetId" : "1874143499404398671",
      "fullText" : "@ChadCaff We are prepped up here\n\nYou can feel the tension in the air in our workspace.",
      "expandedUrl" : "https://twitter.com/i/web/status/1874143499404398671"
    }
  },
  {
    "like" : {
      "tweetId" : "1874040440447451520",
      "fullText" : "final day of the year\n\nfinal gmetis of the year 🫡",
      "expandedUrl" : "https://twitter.com/i/web/status/1874040440447451520"
    }
  },
  {
    "like" : {
      "tweetId" : "1873706885494563016",
      "fullText" : "My New Year's resolution is to double down on self-improvement.\n\nNothing else will give you a better ROI.",
      "expandedUrl" : "https://twitter.com/i/web/status/1873706885494563016"
    }
  },
  {
    "like" : {
      "tweetId" : "1873915827919217086",
      "fullText" : "last gm of 2024.",
      "expandedUrl" : "https://twitter.com/i/web/status/1873915827919217086"
    }
  },
  {
    "like" : {
      "tweetId" : "1873770937071669600",
      "fullText" : "@0x_beni_ @0xAgent_S @worldwarjelly @SuiAIFun @dapyAI @theosirisai This isn't for only SUI\n\nIt will be a flood of profit on Metis too.\n\nWe've successfully launched 2 AI agents on our platform.\n\n@gMetisl2  and @MemAiOfficial, do well to check them out",
      "expandedUrl" : "https://twitter.com/i/web/status/1873770937071669600"
    }
  },
  {
    "like" : {
      "tweetId" : "1873429577273672184",
      "fullText" : "Do you know what's going to happen when $Metis becomes stage1 and @VitalikButerin realizes it and $metis will be the L2 most $ETH aligned and will have DSeq at full throttle, @stakedotlink ,all Meme projects and all the AI ​​agent projects arrive? do I really have to tell you?",
      "expandedUrl" : "https://twitter.com/i/web/status/1873429577273672184"
    }
  },
  {
    "like" : {
      "tweetId" : "1873381599489962384",
      "fullText" : "red pill, nothing happens.\nblue pill, buy $metis, explore its ecosystem and enter the virtual world web3 that will change your life. the choice is yours.\n@MetisL2",
      "expandedUrl" : "https://twitter.com/i/web/status/1873381599489962384"
    }
  },
  {
    "like" : {
      "tweetId" : "1873276672629457296",
      "fullText" : "gMetis🌿\ngVesta",
      "expandedUrl" : "https://twitter.com/i/web/status/1873276672629457296"
    }
  },
  {
    "like" : {
      "tweetId" : "1873297996026130751",
      "fullText" : "the rumors are true\n\nMetis is entering 2025 with amazing builders in its ecosystem",
      "expandedUrl" : "https://twitter.com/i/web/status/1873297996026130751"
    }
  },
  {
    "like" : {
      "tweetId" : "1873147012302160125",
      "fullText" : "And in 2025 it will be bigger. \nAgain, this is like NFTs in 2021. https://t.co/1pCS5eCHUJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1873147012302160125"
    }
  },
  {
    "like" : {
      "tweetId" : "1873083899544232116",
      "fullText" : "Start the week off with us on Monday for a special AMA with @Nextmate_ai to discuss their AI-powered prediction markets coming to Metis🌿 \n\n📅 Monday, Dec. 30\n⏰ 9AM EST / 2PM UTC\n🎙️ https://t.co/76LvibSkLB\n\nLearn how AI technology is enhancing blockchain-based prediction… https://t.co/Wcug2oRBo2",
      "expandedUrl" : "https://twitter.com/i/web/status/1873083899544232116"
    }
  },
  {
    "like" : {
      "tweetId" : "1873107220772340179",
      "fullText" : "Gm from Santiago de Chile 🙂 https://t.co/s5erzMn5Lc",
      "expandedUrl" : "https://twitter.com/i/web/status/1873107220772340179"
    }
  },
  {
    "like" : {
      "tweetId" : "1873041193598329264",
      "fullText" : "@NikolaBench @gMetisl2 is very bullish https://t.co/Hi1adeWFnM",
      "expandedUrl" : "https://twitter.com/i/web/status/1873041193598329264"
    }
  },
  {
    "like" : {
      "tweetId" : "1873041539678781880",
      "fullText" : "@coingecko Staying close to @gMetisl2 \nThey’ve the best and the most supportive community ever https://t.co/lHI3a2EPQI",
      "expandedUrl" : "https://twitter.com/i/web/status/1873041539678781880"
    }
  },
  {
    "like" : {
      "tweetId" : "1872761089584447689",
      "fullText" : "@gMetisl2 ahead of the game",
      "expandedUrl" : "https://twitter.com/i/web/status/1872761089584447689"
    }
  },
  {
    "like" : {
      "tweetId" : "1871871202907893873",
      "fullText" : "Wishing a great day to everyone today, but especially to those who are building something because they feel the need to follow their curiosity.\n\nThere's nothing more pleasurable in this world than following your curiosity and immersing yourself in the wonders of the mind.",
      "expandedUrl" : "https://twitter.com/i/web/status/1871871202907893873"
    }
  },
  {
    "like" : {
      "tweetId" : "1872418363768541271",
      "fullText" : "that's the builder who spent the entire Christmas building https://t.co/iUVTmRVwTD",
      "expandedUrl" : "https://twitter.com/i/web/status/1872418363768541271"
    }
  },
  {
    "like" : {
      "tweetId" : "1872651844419563881",
      "fullText" : "Ready for a new adventure ✌️ https://t.co/g2bHtlZHUD",
      "expandedUrl" : "https://twitter.com/i/web/status/1872651844419563881"
    }
  },
  {
    "like" : {
      "tweetId" : "1872577817004933615",
      "fullText" : "@MetisL2 Who calling Vesta?👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1872577817004933615"
    }
  },
  {
    "like" : {
      "tweetId" : "1872641811073946028",
      "fullText" : "@MetisL2 2024 was a banger on Hercules DEX.\n\n2025? we're bringing the Volume heat!",
      "expandedUrl" : "https://twitter.com/i/web/status/1872641811073946028"
    }
  },
  {
    "like" : {
      "tweetId" : "1872576046681207098",
      "fullText" : "2024 was a banger — because of builders\n\n2025 will be a banger — because of builders\n\nWho’s accelerating the future of crypto in 2025?👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1872576046681207098"
    }
  },
  {
    "like" : {
      "tweetId" : "1872546635638809053",
      "fullText" : "gMetis🌿\ngVesta",
      "expandedUrl" : "https://twitter.com/i/web/status/1872546635638809053"
    }
  },
  {
    "like" : {
      "tweetId" : "1872695812008100088",
      "fullText" : "@yourcryptodj @gMetisl2 is the gem https://t.co/fNXfcpEh3y",
      "expandedUrl" : "https://twitter.com/i/web/status/1872695812008100088"
    }
  },
  {
    "like" : {
      "tweetId" : "1872696996508971440",
      "fullText" : "@cryptojack $gMetis is going to explode once their AI MODEL IS live @gMetisl2 https://t.co/8gD15LC2qs",
      "expandedUrl" : "https://twitter.com/i/web/status/1872696996508971440"
    }
  },
  {
    "like" : {
      "tweetId" : "1872698487646896448",
      "fullText" : "@1000xgirl $gMetis will make you run stack your bags now \nWith @gMetisl2 https://t.co/NcSA3Hrn9h",
      "expandedUrl" : "https://twitter.com/i/web/status/1872698487646896448"
    }
  },
  {
    "like" : {
      "tweetId" : "1872556241526091828",
      "fullText" : "@VestaDAO Gm @VestaDAO @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1872556241526091828"
    }
  },
  {
    "like" : {
      "tweetId" : "1872561180214227096",
      "fullText" : "@temi_lade1 $gMetis is the ticker for @gMetisl2 on @MetisL2 network https://t.co/joMWLim5SX",
      "expandedUrl" : "https://twitter.com/i/web/status/1872561180214227096"
    }
  },
  {
    "like" : {
      "tweetId" : "1872605365311021095",
      "fullText" : "@hanturksc @metis @growfitter @gMetisl2 is cooking too! 🙂",
      "expandedUrl" : "https://twitter.com/i/web/status/1872605365311021095"
    }
  },
  {
    "like" : {
      "tweetId" : "1871596453988106635",
      "fullText" : "Merry Vestmas \n\n🎄",
      "expandedUrl" : "https://twitter.com/i/web/status/1871596453988106635"
    }
  },
  {
    "like" : {
      "tweetId" : "1871535962217656810",
      "fullText" : "GM $METIS fam! Good days are coming for us! All patience will be rewarded sooner or later.\n\nPrice action on $METIS this 2024 was kinda rough. But I do think 2025 will be better. Just stay cautious and don't over leverage. \n\nMerry Christmas 🎄 to all! https://t.co/KLYo72rDxf",
      "expandedUrl" : "https://twitter.com/i/web/status/1871535962217656810"
    }
  },
  {
    "like" : {
      "tweetId" : "1871451466759909526",
      "fullText" : "Meme Royale is here to reward your participation with MetisForge!\n\nYou’re still early, so take this opportunity to build your token and compete in Meme Royale.\n\nDon’t wait until your competitors are far ahead before you start building.\n\nJoin now: https://t.co/GJa4Dbnsjz",
      "expandedUrl" : "https://twitter.com/i/web/status/1871451466759909526"
    }
  },
  {
    "like" : {
      "tweetId" : "1871488531501359304",
      "fullText" : "A good day to express my gratitude towards life. 🌞 https://t.co/B1mtQaPjv7",
      "expandedUrl" : "https://twitter.com/i/web/status/1871488531501359304"
    }
  },
  {
    "like" : {
      "tweetId" : "1871336058547507652",
      "fullText" : "@gMetisl2 @MetisL2 It will not 😁",
      "expandedUrl" : "https://twitter.com/i/web/status/1871336058547507652"
    }
  },
  {
    "like" : {
      "tweetId" : "1871330540336583153",
      "fullText" : "In 2025 there will be a boom in AI agents in the crypto sector similar to the NFT boom in 2021.",
      "expandedUrl" : "https://twitter.com/i/web/status/1871330540336583153"
    }
  },
  {
    "like" : {
      "tweetId" : "1871331165195653259",
      "fullText" : "@gMetisl2 @TheHerculesDEX so nice, it would be incredible if we can get some type of deep dive on the daily work by the team (after 🎄 obv)",
      "expandedUrl" : "https://twitter.com/i/web/status/1871331165195653259"
    }
  },
  {
    "like" : {
      "tweetId" : "1871240711934300393",
      "fullText" : "I like to invest my attention and capital in things that are inevitable.\n\nBlockchain is inevitable\nAI is inevitable\n\nThe combination of both is also inevitable, and the AI agent meta is a strong proof of this.\n\nThe cool thing is that if you zoom out this is just the beginning:…",
      "expandedUrl" : "https://twitter.com/i/web/status/1871240711934300393"
    }
  },
  {
    "like" : {
      "tweetId" : "1871297495181279417",
      "fullText" : "@MDPC62 @Liikeey @josefabregab @MetisL2 @VestaDAO @pumpe_meme @MemAiOfficial @gMetisl2 @medusa_metis 🌿🌿👀💜",
      "expandedUrl" : "https://twitter.com/i/web/status/1871297495181279417"
    }
  },
  {
    "like" : {
      "tweetId" : "1871221101935972371",
      "fullText" : "@josefabregab @MetisL2 $METIS \n\n@VestaDAO is turning into the NPR of METID, much needed guide of our ECO.\n\n@pumpe_meme  building hype with their upcoming launch.\n\nThe AI AGENT Wars with @MemAiOfficial and @gMetisl2 \n\nAnd The MEME wars with @medusa_metis and $DUSA, they have demanded needed attention 👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1871221101935972371"
    }
  },
  {
    "like" : {
      "tweetId" : "1871095097942495258",
      "fullText" : "gMetis🌿\ngMorning https://t.co/vVCj5CGs5h",
      "expandedUrl" : "https://twitter.com/i/web/status/1871095097942495258"
    }
  },
  {
    "like" : {
      "tweetId" : "1871130144255221818",
      "fullText" : "🎙️ In case you missed one of these exciting  discussions: \n\n💭 Metis Morning Show: TORCH; Are You Bullish Enough?   w/ @L2Cobi, @VestaDAO, @cKurisuu\nhttps://t.co/qLeXazJduK    \n\n💭 CEG AMA:   @gMetisL2 x @LeoFi_hub\nhttps://t.co/3Q8kuBztJh  \n\n💭Is Play-To-Earn Sustainable?   w/…",
      "expandedUrl" : "https://twitter.com/i/web/status/1871130144255221818"
    }
  },
  {
    "like" : {
      "tweetId" : "1870771244926484933",
      "fullText" : "Don't Fade Meme Royal\n\n@MetisForgeDev $Metis #MemeRoyale",
      "expandedUrl" : "https://twitter.com/i/web/status/1870771244926484933"
    }
  },
  {
    "like" : {
      "tweetId" : "1870533567014633609",
      "fullText" : "Anyone building something on Metis today? 👀🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1870533567014633609"
    }
  },
  {
    "like" : {
      "tweetId" : "1870851839710630096",
      "fullText" : "After about a decade of working in physics, I took a big risk by moving into the crypto industry. I started from scratch and managed to build a brand and strategically position myself in such a way that today I have multiple options to continue growing professionally and… https://t.co/TJ55Ir2s5D",
      "expandedUrl" : "https://twitter.com/i/web/status/1870851839710630096"
    }
  },
  {
    "like" : {
      "tweetId" : "1870517922055213470",
      "fullText" : "$METIS is still down 37% + , can barely pump . The community went silent, bruh work for your bags . If you need this tweet to dunk on me and spread bullishness on $METIS , be my guest!!!",
      "expandedUrl" : "https://twitter.com/i/web/status/1870517922055213470"
    }
  },
  {
    "like" : {
      "tweetId" : "1870053773344743533",
      "fullText" : "ATTENTION ALL TOKEN DEVS! \n\nCrank up your communities and get ready to race your way to the top!\n\nMeme Royale leaderboard is launching next week!\n\n$MemAi is currently leading the race to be crowned the champion\n\nWill you sit back and watch or will you overtake it and claim the… https://t.co/d8zGaVTjma",
      "expandedUrl" : "https://twitter.com/i/web/status/1870053773344743533"
    }
  },
  {
    "like" : {
      "tweetId" : "1870473627197669717",
      "fullText" : "gm\n\nlet’s buidl https://t.co/Uyc4BnaEsi",
      "expandedUrl" : "https://twitter.com/i/web/status/1870473627197669717"
    }
  },
  {
    "like" : {
      "tweetId" : "1870418154280693950",
      "fullText" : "Okay, ready for what's next.",
      "expandedUrl" : "https://twitter.com/i/web/status/1870418154280693950"
    }
  },
  {
    "like" : {
      "tweetId" : "1870398894875504641",
      "fullText" : "gm\n\nlet’s buidl",
      "expandedUrl" : "https://twitter.com/i/web/status/1870398894875504641"
    }
  },
  {
    "like" : {
      "tweetId" : "1870443740516749711",
      "fullText" : "$METIS has Vitalik’s mum as founder but retail will not know of it as the team will never market it like that 😂 easiest 100x if they do it. \n\nGm https://t.co/Z5ltgWSUss",
      "expandedUrl" : "https://twitter.com/i/web/status/1870443740516749711"
    }
  },
  {
    "like" : {
      "tweetId" : "1870365601065001003",
      "fullText" : "@MetisGovernance @Be_Prometheus @gMetisl2 @nextmate_ai Congrats to everyone",
      "expandedUrl" : "https://twitter.com/i/web/status/1870365601065001003"
    }
  },
  {
    "like" : {
      "tweetId" : "1870410942720167948",
      "fullText" : "@Jeremi1Ojetunde @gMetisl2 @0xQuantic @MetisL2 The ticker is $gMetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1870410942720167948"
    }
  },
  {
    "like" : {
      "tweetId" : "1870408562641359013",
      "fullText" : "@gitcoin @gMetisl2 @L2cobi",
      "expandedUrl" : "https://twitter.com/i/web/status/1870408562641359013"
    }
  },
  {
    "like" : {
      "tweetId" : "1870411421277671773",
      "fullText" : "@MonstersCoins The possibility of financial freedom is certain with @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1870411421277671773"
    }
  },
  {
    "like" : {
      "tweetId" : "1870411815605412189",
      "fullText" : "@Jeremi1Ojetunde @gMetisl2 @0xQuantic @MetisL2 Seems undervalued now but soon it’s gonna skyrocket @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1870411815605412189"
    }
  },
  {
    "like" : {
      "tweetId" : "1870411382899822703",
      "fullText" : "Meme Royal updated score board:\nN1 @MemAiOfficial \nN2 @gMetisl2 \nany new challenger for the crown? \n\n@MetisForgeDev $Metis #MemeRoyale",
      "expandedUrl" : "https://twitter.com/i/web/status/1870411382899822703"
    }
  },
  {
    "like" : {
      "tweetId" : "1870413485626069086",
      "fullText" : "@Z_Cryptomaniac @MemAiOfficial @gMetisl2 @MetisForgeDev Of course no challenger but @gMetisl2 will get the crown",
      "expandedUrl" : "https://twitter.com/i/web/status/1870413485626069086"
    }
  },
  {
    "like" : {
      "tweetId" : "1870431349133418813",
      "fullText" : "@MonstersCoins @gMetisl2 is the ticker https://t.co/Zanlp7k63v",
      "expandedUrl" : "https://twitter.com/i/web/status/1870431349133418813"
    }
  },
  {
    "like" : {
      "tweetId" : "1870430104070803803",
      "fullText" : "@Liikeey @MemAiOfficial @gMetisl2 @MetisForgeDev Soon more will enter the race",
      "expandedUrl" : "https://twitter.com/i/web/status/1870430104070803803"
    }
  },
  {
    "like" : {
      "tweetId" : "1870218984966009190",
      "fullText" : "🌿 🤝 💚 \n\nRetro magic loading ⏳",
      "expandedUrl" : "https://twitter.com/i/web/status/1870218984966009190"
    }
  },
  {
    "like" : {
      "tweetId" : "1870218986572394873",
      "fullText" : "Tag a @MetisL2 builder who should see this and say gmetis.",
      "expandedUrl" : "https://twitter.com/i/web/status/1870218986572394873"
    }
  },
  {
    "like" : {
      "tweetId" : "1870221020906357144",
      "fullText" : "@gitcoin @MetisL2 @YetiApes @MetisForgeDev @gMetisl2 @MemAiOfficial",
      "expandedUrl" : "https://twitter.com/i/web/status/1870221020906357144"
    }
  },
  {
    "like" : {
      "tweetId" : "1870183741143802354",
      "fullText" : "What is @VestaDAO cooking? https://t.co/7kuEqEGW2C",
      "expandedUrl" : "https://twitter.com/i/web/status/1870183741143802354"
    }
  },
  {
    "like" : {
      "tweetId" : "1870169109792498088",
      "fullText" : "Big Shoutout to 3 new projects to enter the @MetisL2 ecosystem!\n\n@Be_Prometheus \n@gMetisl2 \n@nextmate_ai \n\nCongrats to these projects for meeting #METIS #CEG quorum this week. \n\nLooking forward to these projects and their contributions to the ecosystem! https://t.co/OeN16cdhQa",
      "expandedUrl" : "https://twitter.com/i/web/status/1870169109792498088"
    }
  },
  {
    "like" : {
      "tweetId" : "1870175937075048581",
      "fullText" : "Using the last days of this year to prepare for an explosive 2025 🫡🚀 https://t.co/URuVcDQWZ7",
      "expandedUrl" : "https://twitter.com/i/web/status/1870175937075048581"
    }
  },
  {
    "like" : {
      "tweetId" : "1870174231020941545",
      "fullText" : "who are the nonstop shippers that are going to be building all weekend?",
      "expandedUrl" : "https://twitter.com/i/web/status/1870174231020941545"
    }
  },
  {
    "like" : {
      "tweetId" : "1870147896437260451",
      "fullText" : "When in doubt, zoom out 📉➡️📈\n\nPrice fluctuations are part of the journey, but innovation and utility drive lasting value. @MetisL2 continues to empower scalable, decentralized applications—building for the future, not just the moment.\n\nTrack trends on Netswap Charts 📊 https://t.co/IPq8bvtFij",
      "expandedUrl" : "https://twitter.com/i/web/status/1870147896437260451"
    }
  },
  {
    "like" : {
      "tweetId" : "1870143926100758878",
      "fullText" : "@wavymaverick @gMetisl2 @gMetisl2 is here to solve the mix of memes and AI",
      "expandedUrl" : "https://twitter.com/i/web/status/1870143926100758878"
    }
  },
  {
    "like" : {
      "tweetId" : "1870140619865133517",
      "fullText" : "81% of web3 projects fail due to poor community engagement and lack of transparency.\n\n@gMetisl2 is solving this with a mix of memes and AI. \n\n gMetis combines the fun of meme tokens with the practicality of AI-driven community management.\n\nThe goal?\n\nTo create an engaging,… https://t.co/FBlBzmbuzv",
      "expandedUrl" : "https://twitter.com/i/web/status/1870140619865133517"
    }
  },
  {
    "like" : {
      "tweetId" : "1870124702229836278",
      "fullText" : "This was quite a run! Three out of five projects running has passed this week. Congratulations to:\n@Be_Prometheus \n@gMetisl2 \n@nextmate_ai \nfor becoming Metis Community Verified Project 👏👏👏\n\nNote that all projects that didn’t reach the quorum have a second chance through a… https://t.co/Ljj2i3wroM",
      "expandedUrl" : "https://twitter.com/i/web/status/1870124702229836278"
    }
  },
  {
    "like" : {
      "tweetId" : "1869850236014997880",
      "fullText" : "Not sure if I told you about  meme Royal lol \nFor more info head to @MetisForgeDev \n\n$Metis #MemeRoyale",
      "expandedUrl" : "https://twitter.com/i/web/status/1869850236014997880"
    }
  },
  {
    "like" : {
      "tweetId" : "1869738708435624380",
      "fullText" : "@MetishubETH @MetisL2 gMetis 🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1869738708435624380"
    }
  },
  {
    "like" : {
      "tweetId" : "1869736225424441502",
      "fullText" : "Decentralisation isn’t the future; it’s the now. At Metis, we’re building a world where trustless systems empower limitless innovation.🌿 wavers on @MetisL2 say gMetis🌿👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1869736225424441502"
    }
  },
  {
    "like" : {
      "tweetId" : "1870005601603821621",
      "fullText" : "gMetis\ngVesta🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1870005601603821621"
    }
  },
  {
    "like" : {
      "tweetId" : "1869850592363065736",
      "fullText" : "@MetisForgeDev Best Platform IMO",
      "expandedUrl" : "https://twitter.com/i/web/status/1869850592363065736"
    }
  },
  {
    "like" : {
      "tweetId" : "1869764218637123717",
      "fullText" : "We’ve got your back, creators.\n\n You’ll now have the first option to buy tokens – no more worrying about snipers! \n\n🛡️ Secure your spot. https://t.co/GEW70bZroB",
      "expandedUrl" : "https://twitter.com/i/web/status/1869764218637123717"
    }
  },
  {
    "like" : {
      "tweetId" : "1869854973963710764",
      "fullText" : "@josefabregab Are you okay bro",
      "expandedUrl" : "https://twitter.com/i/web/status/1869854973963710764"
    }
  },
  {
    "like" : {
      "tweetId" : "1869856079821320630",
      "fullText" : "@cypherpunk669 yeah why do you ask",
      "expandedUrl" : "https://twitter.com/i/web/status/1869856079821320630"
    }
  },
  {
    "like" : {
      "tweetId" : "1869831787880558964",
      "fullText" : "Tomorrow at 9 AM EST we will host @MetisL2\nand some of the build projects from both the Thrive Metis STARTathon and accelerator program!\n\n➡️ https://t.co/QWA16uf9QA\n\nLike always, you will be able to earn some METIS for joining the space!\n\nSee you all there! \n#Thrivemetis https://t.co/tVMLlcspNZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1869831787880558964"
    }
  },
  {
    "like" : {
      "tweetId" : "1869853294849601783",
      "fullText" : "Thrive x Metis\n\n$250,000 Grant Spotlight\n\nMETIS rewards for active listeners\n\nTomorrow 9AM EST / 2pm UTC\n\nSEE YOU THERE! 👇\nhttps://t.co/I5keAMregL https://t.co/aV0aIw42TE",
      "expandedUrl" : "https://twitter.com/i/web/status/1869853294849601783"
    }
  },
  {
    "like" : {
      "tweetId" : "1869764115276980342",
      "fullText" : "$gMetis \n@gMetisl2 https://t.co/ZlQHsLszjk",
      "expandedUrl" : "https://twitter.com/i/web/status/1869764115276980342"
    }
  },
  {
    "like" : {
      "tweetId" : "1869320593688125561",
      "fullText" : "ⓖⓜⓔⓣⓘⓢ https://t.co/JzJSmwl0MP",
      "expandedUrl" : "https://twitter.com/i/web/status/1869320593688125561"
    }
  },
  {
    "like" : {
      "tweetId" : "1869677730436202831",
      "fullText" : "What excites you most about MEME Royal?",
      "expandedUrl" : "https://twitter.com/i/web/status/1869677730436202831"
    }
  },
  {
    "like" : {
      "tweetId" : "1869674122399096943",
      "fullText" : "realigning incentives",
      "expandedUrl" : "https://twitter.com/i/web/status/1869674122399096943"
    }
  },
  {
    "like" : {
      "tweetId" : "1869554716260356159",
      "fullText" : "gmetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1869554716260356159"
    }
  },
  {
    "like" : {
      "tweetId" : "1869274521271763114",
      "fullText" : "Gm Forgians \n\nOur Medium is live! \n\nCheck out our first article about Meme Royale:\n\nMeme token communities under MetisForge compete on:  \n\n- Market Cap  \n- Liquidity  \n- Number of Holders  \n- Twitter Followers\n\nRewards:\n\nTop 8 share a 40k prize pool in $METIS + meme tokens.…",
      "expandedUrl" : "https://twitter.com/i/web/status/1869274521271763114"
    }
  },
  {
    "like" : {
      "tweetId" : "1869311719333642717",
      "fullText" : "For all you need to know on Meme Royale \n@MetisForgeDev $Metis #MemeRoyale \n\nhttps://t.co/64BlLG9bXL",
      "expandedUrl" : "https://twitter.com/i/web/status/1869311719333642717"
    }
  },
  {
    "like" : {
      "tweetId" : "1869469971077841407",
      "fullText" : "Breh, and you think the bull run is ending\n\nWe haven’t even got started yet https://t.co/PdrqZ2o6Rz",
      "expandedUrl" : "https://twitter.com/i/web/status/1869469971077841407"
    }
  },
  {
    "like" : {
      "tweetId" : "1869514883378913415",
      "fullText" : "What's your most bullish token on #Metis? We'll highlight it 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1869514883378913415"
    }
  },
  {
    "like" : {
      "tweetId" : "1869106314594685331",
      "fullText" : "I’m hearing rumors about @0xQuantic hearing rumors about new Metis grants 👀👀👀 https://t.co/s9JwuCHet0",
      "expandedUrl" : "https://twitter.com/i/web/status/1869106314594685331"
    }
  },
  {
    "like" : {
      "tweetId" : "1869359457769246757",
      "fullText" : "Future of Web3 is decentralized! $METIS is leading the way!🌿🔥 https://t.co/EA8woy6lTz",
      "expandedUrl" : "https://twitter.com/i/web/status/1869359457769246757"
    }
  },
  {
    "like" : {
      "tweetId" : "1869448502310531490",
      "fullText" : "@L2cobi @LeoFi_Hub @gMetisl2 Missed it! Currently playing the record.",
      "expandedUrl" : "https://twitter.com/i/web/status/1869448502310531490"
    }
  },
  {
    "like" : {
      "tweetId" : "1869427494035829222",
      "fullText" : "https://t.co/8nWxPr0g6c",
      "expandedUrl" : "https://twitter.com/i/web/status/1869427494035829222"
    }
  },
  {
    "like" : {
      "tweetId" : "1869320052773671074",
      "fullText" : "ⓖⓜⓔⓣⓘⓢ",
      "expandedUrl" : "https://twitter.com/i/web/status/1869320052773671074"
    }
  },
  {
    "like" : {
      "tweetId" : "1869311324028608707",
      "fullText" : "The one and only \n\nMeme Factory on @MetisL2 where you can launch or buy safely , with the knowledge  that liquidity is locked automatically on @TheHerculesDEX \n\nIf you have a great community and want to launch a meme and follow on the steps of @MemAiOfficial  and @gMetisl2  our… https://t.co/B65YFVNJPQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1869311324028608707"
    }
  },
  {
    "like" : {
      "tweetId" : "1869303224093888704",
      "fullText" : "@Be_Prometheus @MetisL2 Congratulations @gMetisl2 is next",
      "expandedUrl" : "https://twitter.com/i/web/status/1869303224093888704"
    }
  },
  {
    "like" : {
      "tweetId" : "1869302947508900209",
      "fullText" : "@Be_Prometheus @MetisL2 Congratulations guys @gMetisl2 is next",
      "expandedUrl" : "https://twitter.com/i/web/status/1869302947508900209"
    }
  },
  {
    "like" : {
      "tweetId" : "1869301578664198410",
      "fullText" : "@MetisForgeDev @Liikeey @gMetisl2 https://t.co/QilwK5bwwz",
      "expandedUrl" : "https://twitter.com/i/web/status/1869301578664198410"
    }
  },
  {
    "like" : {
      "tweetId" : "1869295940840165646",
      "fullText" : "We’re cooking big, it will meet you unprepared.@gMetisl2 \n@Iamarabcoin https://t.co/8nwMzE9Xam",
      "expandedUrl" : "https://twitter.com/i/web/status/1869295940840165646"
    }
  },
  {
    "like" : {
      "tweetId" : "1868949343236948016",
      "fullText" : "who’s building culture on Metis, chat? 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1868949343236948016"
    }
  },
  {
    "like" : {
      "tweetId" : "1868745356210573323",
      "fullText" : "What were the biggest wins of 2024 in our ecosystem? 🌿\n\nJoin us this Thursday at 1 PM UTC for a year-end review with @ElenaCryptoChic, DC of People and Education at @MetisL2; @benjoflo, CMO at @P1Xlabs; Carol Zu from @nudex_official; and @DacEconomy from @ProjectZKM.\n\nGot… https://t.co/TwOCt7BDex",
      "expandedUrl" : "https://twitter.com/i/web/status/1868745356210573323"
    }
  },
  {
    "like" : {
      "tweetId" : "1869173322333757615",
      "fullText" : "gMetis x LeoFi: #Metis CEG #AMA \n\n🌿 The newest AI Agent on Metis\n🌿 Decentralized Asset Management\n\n📅 Wednesday Dec. 18\n⏰ 12pm EST/5pm UTC\n🗺️ LIVE on X/Twitter Spaces (link below)\n\nBring your questions for these two CEG candidates! https://t.co/BWZgaDkdv2",
      "expandedUrl" : "https://twitter.com/i/web/status/1869173322333757615"
    }
  },
  {
    "like" : {
      "tweetId" : "1869156125708579226",
      "fullText" : "@gMetisl2 @MetisL2 @gMetisl2 Lo merece. Gran idea y gran comunidad!\n\nVOTE, VOTE, VOTE! https://t.co/Vx5kwvHLcl",
      "expandedUrl" : "https://twitter.com/i/web/status/1869156125708579226"
    }
  },
  {
    "like" : {
      "tweetId" : "1869155576078622918",
      "fullText" : "@0xQuantic @gMetisl2 should apply",
      "expandedUrl" : "https://twitter.com/i/web/status/1869155576078622918"
    }
  },
  {
    "like" : {
      "tweetId" : "1869073167047934243",
      "fullText" : "This post \"What's Ahead for the ETH Layer-2 Sector in 2025?\" Appeared \nfirst on New York Tech Media.\nhttps://t.co/IgO9dF3iOQ https://t.co/uN5xB8ANlV",
      "expandedUrl" : "https://twitter.com/i/web/status/1869073167047934243"
    }
  },
  {
    "like" : {
      "tweetId" : "1868728106082791580",
      "fullText" : "Please vote for your favorite projects 👇 https://t.co/Kz680laAqX",
      "expandedUrl" : "https://twitter.com/i/web/status/1868728106082791580"
    }
  },
  {
    "like" : {
      "tweetId" : "1868737741430964474",
      "fullText" : "Proposals, proposals, proposals... https://t.co/VjSLVAkj0s",
      "expandedUrl" : "https://twitter.com/i/web/status/1868737741430964474"
    }
  },
  {
    "like" : {
      "tweetId" : "1869151432580255832",
      "fullText" : "@gMetisl2 @MetisL2 Vote for $gMetis",
      "expandedUrl" : "https://twitter.com/i/web/status/1869151432580255832"
    }
  },
  {
    "like" : {
      "tweetId" : "1868693535970689410",
      "fullText" : "Fully agree, and if you're not already paying attention to what's happening in the AI ​​sector (especially with agents), I highly recommend spending some time looking into this. https://t.co/3Hh5sV5QsK",
      "expandedUrl" : "https://twitter.com/i/web/status/1868693535970689410"
    }
  },
  {
    "like" : {
      "tweetId" : "1869149430211092635",
      "fullText" : "@gMetisl2 @MetisL2 Let’s vote",
      "expandedUrl" : "https://twitter.com/i/web/status/1869149430211092635"
    }
  },
  {
    "like" : {
      "tweetId" : "1869149636868612114",
      "fullText" : "@gMetisl2 @MetisL2 Let’s go and vote guys",
      "expandedUrl" : "https://twitter.com/i/web/status/1869149636868612114"
    }
  },
  {
    "like" : {
      "tweetId" : "1869149884336722417",
      "fullText" : "@gMetisl2 @MetisL2 $GMetis deserves some vote",
      "expandedUrl" : "https://twitter.com/i/web/status/1869149884336722417"
    }
  },
  {
    "like" : {
      "tweetId" : "1869150334490440161",
      "fullText" : "@gMetisl2 @MetisL2 Let’s go vote",
      "expandedUrl" : "https://twitter.com/i/web/status/1869150334490440161"
    }
  },
  {
    "like" : {
      "tweetId" : "1869150509527089594",
      "fullText" : "@gMetisl2 @MetisL2 $Gmetis deserves some vote",
      "expandedUrl" : "https://twitter.com/i/web/status/1869150509527089594"
    }
  },
  {
    "like" : {
      "tweetId" : "1869150725609243085",
      "fullText" : "@gMetisl2 @MetisL2 Innovative project that deserves some community vote",
      "expandedUrl" : "https://twitter.com/i/web/status/1869150725609243085"
    }
  },
  {
    "like" : {
      "tweetId" : "1868594526052298993",
      "fullText" : "new week\nnew goals\nnew opportunities to grow\n\ngmetis🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1868594526052298993"
    }
  },
  {
    "like" : {
      "tweetId" : "1868959539791561043",
      "fullText" : "@wavymaverick @gMetisl2 Thanks brother \nI’ll appreciate",
      "expandedUrl" : "https://twitter.com/i/web/status/1868959539791561043"
    }
  },
  {
    "like" : {
      "tweetId" : "1869026135977390122",
      "fullText" : "@Leooweb3 @gMetisl2  will do this🌿🤩",
      "expandedUrl" : "https://twitter.com/i/web/status/1869026135977390122"
    }
  },
  {
    "like" : {
      "tweetId" : "1868940367816782020",
      "fullText" : "Gmetis🌿 https://t.co/w3bLWNNAyP",
      "expandedUrl" : "https://twitter.com/i/web/status/1868940367816782020"
    }
  },
  {
    "like" : {
      "tweetId" : "1868947726760919071",
      "fullText" : "@Liikeey @gMetisl2 I'll make a thread on it, bring more eyeballs",
      "expandedUrl" : "https://twitter.com/i/web/status/1868947726760919071"
    }
  },
  {
    "like" : {
      "tweetId" : "1868615808143986842",
      "fullText" : "90% of tweet-to-entertain AI agents will die, but leading AI Agents will become L1s.\n\nYour job is to identify the later ones.",
      "expandedUrl" : "https://twitter.com/i/web/status/1868615808143986842"
    }
  },
  {
    "like" : {
      "tweetId" : "1868855595383791618",
      "fullText" : "No $METIS,  no gains 😤\n\nNow you know how to get fit! https://t.co/SUyp6FAKJf",
      "expandedUrl" : "https://twitter.com/i/web/status/1868855595383791618"
    }
  },
  {
    "like" : {
      "tweetId" : "1868922194220531874",
      "fullText" : "@Iamarabcoin @VestaDAO @L2cobi @Liikeey @Psilocybe____ @hanturksc @DefiSociety @0xQuantic @gMetisl2 @MemAiOfficial 👀👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1868922194220531874"
    }
  },
  {
    "like" : {
      "tweetId" : "1868932813854326950",
      "fullText" : "Another day to push this vote forward and bring it home🙏🙌 https://t.co/XDT8tMoyHX",
      "expandedUrl" : "https://twitter.com/i/web/status/1868932813854326950"
    }
  },
  {
    "like" : {
      "tweetId" : "1868933711326331075",
      "fullText" : "@josefabregab @gMetisl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1868933711326331075"
    }
  },
  {
    "like" : {
      "tweetId" : "1868939177636811240",
      "fullText" : "@gMetisl2 @MetisL2 @MetisInsiders 🙏",
      "expandedUrl" : "https://twitter.com/i/web/status/1868939177636811240"
    }
  },
  {
    "like" : {
      "tweetId" : "1868940406945431651",
      "fullText" : "@wavymaverick @gMetisl2 deserve some vote mate",
      "expandedUrl" : "https://twitter.com/i/web/status/1868940406945431651"
    }
  },
  {
    "like" : {
      "tweetId" : "1868941780177371245",
      "fullText" : "@gMetisl2 @MetisL2 one sip of gMetis, one step closer to greatness 🤩",
      "expandedUrl" : "https://twitter.com/i/web/status/1868941780177371245"
    }
  },
  {
    "like" : {
      "tweetId" : "1868759788613767521",
      "fullText" : "@gMetisl2 @MetisL2 https://t.co/hWdz4o7PTL",
      "expandedUrl" : "https://twitter.com/i/web/status/1868759788613767521"
    }
  },
  {
    "like" : {
      "tweetId" : "1868726769907605604",
      "fullText" : "Your support is all we needed for this to come to reality guys @0xQuantic @L2cobi @CanerIrina @lozzzTD @GiveAwayHost @DriesT99 @MetisL2 @Psilocybe____ @Ralph_DeFi @Prince_omobee @Osekbcn @wantchuwant https://t.co/XDT8tMoyHX",
      "expandedUrl" : "https://twitter.com/i/web/status/1868726769907605604"
    }
  },
  {
    "like" : {
      "tweetId" : "1868726950967361677",
      "fullText" : "@Iamarabcoin @gMetisl2 @MetisL2 @pharm_Gaga @Arakunrin_emma Thanks brother",
      "expandedUrl" : "https://twitter.com/i/web/status/1868726950967361677"
    }
  },
  {
    "like" : {
      "tweetId" : "1868752250463789249",
      "fullText" : "Your vote is important to us @gMetisl2 \nHelp us bring this to reality and home🙏 https://t.co/Bj07iiu152 https://t.co/TMCY03fRRE",
      "expandedUrl" : "https://twitter.com/i/web/status/1868752250463789249"
    }
  },
  {
    "like" : {
      "tweetId" : "1868755569697263638",
      "fullText" : "1️⃣ @gMetisl2: \"Revolutionizing Community Engagement with AI\"\n\nA meme-powered project that brings AI-driven community management to Metis.\n\n🧠 AI agents foster dynamic conversations &amp; positive engagement.\n📊 Real-time insights &amp; sentiment analysis keep users informed.\n🎁 Daily…",
      "expandedUrl" : "https://twitter.com/i/web/status/1868755569697263638"
    }
  },
  {
    "like" : {
      "tweetId" : "1868720865845952916",
      "fullText" : "Time to cast your vote and show love for @gMetisl2 ! 🗳️ Let’s rally the squad and put GMetis where it belongs at the top. The power’s in your hands, fam. Let’s make it happen!🌿🌿🌿🌿💜 https://t.co/VAbNZPxWar",
      "expandedUrl" : "https://twitter.com/i/web/status/1868720865845952916"
    }
  },
  {
    "like" : {
      "tweetId" : "1868708512597176714",
      "fullText" : "@gMetisl2 @MetisL2 Your vote your power lfgggg",
      "expandedUrl" : "https://twitter.com/i/web/status/1868708512597176714"
    }
  },
  {
    "like" : {
      "tweetId" : "1868708219373470078",
      "fullText" : "@gMetisl2 @MetisL2 Your vote matters to us let’s go",
      "expandedUrl" : "https://twitter.com/i/web/status/1868708219373470078"
    }
  },
  {
    "like" : {
      "tweetId" : "1868700261969272908",
      "fullText" : "@gMetisl2 @TheHerculesDEX @MetisL2 Work on website asap. Needs to be professionally made to attract investors",
      "expandedUrl" : "https://twitter.com/i/web/status/1868700261969272908"
    }
  },
  {
    "like" : {
      "tweetId" : "1868706805175697846",
      "fullText" : "@gMetisl2 @MetisL2 GMetis 🌿",
      "expandedUrl" : "https://twitter.com/i/web/status/1868706805175697846"
    }
  },
  {
    "like" : {
      "tweetId" : "1868693242319118627",
      "fullText" : "@gMetisl2 @TheHerculesDEX @MetisL2 One step to the promise land. @gMetisl2 has been making waves",
      "expandedUrl" : "https://twitter.com/i/web/status/1868693242319118627"
    }
  },
  {
    "like" : {
      "tweetId" : "1868693490886160463",
      "fullText" : "Are you still doubting @gMetisl2 ?\nI think this is the time you should bag some, because this is another step to making the dream a reality https://t.co/qXkHy9uLkZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1868693490886160463"
    }
  },
  {
    "like" : {
      "tweetId" : "1868676859644547517",
      "fullText" : "For the first time in months, a new token pool is topping the chart ahead of $Metis v2 pool in volume 🔥\n\nmeme szn? @MemAiOfficial . https://t.co/b62nIOcwHy",
      "expandedUrl" : "https://twitter.com/i/web/status/1868676859644547517"
    }
  },
  {
    "like" : {
      "tweetId" : "1868678389839917330",
      "fullText" : "@MetisHero @gMetisl2 Yes the dev is based and grinding hard to bring and deploy Ai",
      "expandedUrl" : "https://twitter.com/i/web/status/1868678389839917330"
    }
  },
  {
    "like" : {
      "tweetId" : "1868678564205502943",
      "fullText" : "@MetisHero @gMetisl2 @gMetisl2 is here to blow us to the moon",
      "expandedUrl" : "https://twitter.com/i/web/status/1868678564205502943"
    }
  },
  {
    "like" : {
      "tweetId" : "1868678757290307995",
      "fullText" : "@MetisHero @gMetisl2 Yooo @gMetisl2 dev is most ever based dev",
      "expandedUrl" : "https://twitter.com/i/web/status/1868678757290307995"
    }
  }
]