window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "English (United Kingdom)",
            "isDisabled" : false
          },
          {
            "language" : "art (Private-Use: emoji)",
            "isDisabled" : false
          },
          {
            "language" : "No linguistic content",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "#HappyFriday",
            "isDisabled" : false
          },
          {
            "name" : "$BTC",
            "isDisabled" : false
          },
          {
            "name" : "$DOGE",
            "isDisabled" : false
          },
          {
            "name" : "$ETH",
            "isDisabled" : false
          },
          {
            "name" : "$USDT",
            "isDisabled" : false
          },
          {
            "name" : "$XRP",
            "isDisabled" : false
          },
          {
            "name" : "Action games",
            "isDisabled" : false
          },
          {
            "name" : "Ada cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Algorand cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Allstate",
            "isDisabled" : false
          },
          {
            "name" : "American football",
            "isDisabled" : false
          },
          {
            "name" : "Ameriprise Financial",
            "isDisabled" : false
          },
          {
            "name" : "Aposto!",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "At home",
            "isDisabled" : false
          },
          {
            "name" : "Automobile Brands",
            "isDisabled" : false
          },
          {
            "name" : "Automotive",
            "isDisabled" : false
          },
          {
            "name" : "Avalanche cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "AvalonBay Communities",
            "isDisabled" : false
          },
          {
            "name" : "BMX",
            "isDisabled" : false
          },
          {
            "name" : "BTS",
            "isDisabled" : false
          },
          {
            "name" : "Bicycle motocross",
            "isDisabled" : false
          },
          {
            "name" : "Binance",
            "isDisabled" : false
          },
          {
            "name" : "Binance Coin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Bitcoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "BlackRock",
            "isDisabled" : false
          },
          {
            "name" : "Brown & Brown",
            "isDisabled" : false
          },
          {
            "name" : "Bubble tea",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "Call of Duty",
            "isDisabled" : false
          },
          {
            "name" : "Call of Duty League",
            "isDisabled" : false
          },
          {
            "name" : "Carrier Global",
            "isDisabled" : false
          },
          {
            "name" : "Central Banks",
            "isDisabled" : false
          },
          {
            "name" : "Chainlink cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Changpeng Zhao",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "Coinbase",
            "isDisabled" : false
          },
          {
            "name" : "Combat sports",
            "isDisabled" : false
          },
          {
            "name" : "Competitive games",
            "isDisabled" : false
          },
          {
            "name" : "Computer hardware",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Concept art",
            "isDisabled" : false
          },
          {
            "name" : "Crime in the United States",
            "isDisabled" : false
          },
          {
            "name" : "Cristiano Ronaldo",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocoins",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrency exchanges",
            "isDisabled" : false
          },
          {
            "name" : "Cryptomining",
            "isDisabled" : false
          },
          {
            "name" : "Cryptotokens",
            "isDisabled" : false
          },
          {
            "name" : "Cultural events",
            "isDisabled" : false
          },
          {
            "name" : "Customer service",
            "isDisabled" : false
          },
          {
            "name" : "Cycling",
            "isDisabled" : false
          },
          {
            "name" : "DAOs",
            "isDisabled" : false
          },
          {
            "name" : "Dark drama",
            "isDisabled" : false
          },
          {
            "name" : "Decentralized finance",
            "isDisabled" : false
          },
          {
            "name" : "Denzel Washington",
            "isDisabled" : false
          },
          {
            "name" : "Digital asset industry",
            "isDisabled" : false
          },
          {
            "name" : "Digital assets & cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Digital goods & currency",
            "isDisabled" : false
          },
          {
            "name" : "Discord",
            "isDisabled" : false
          },
          {
            "name" : "Dogecoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Drama TV",
            "isDisabled" : false
          },
          {
            "name" : "Drama films",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "Early access games",
            "isDisabled" : false
          },
          {
            "name" : "Education",
            "isDisabled" : false
          },
          {
            "name" : "Educational Technology podcast",
            "isDisabled" : false
          },
          {
            "name" : "Educational podcast",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Eric Trump",
            "isDisabled" : false
          },
          {
            "name" : "Esports",
            "isDisabled" : false
          },
          {
            "name" : "Esports leagues",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Extreme sports",
            "isDisabled" : false
          },
          {
            "name" : "Facebook",
            "isDisabled" : false
          },
          {
            "name" : "Family & nostalgic",
            "isDisabled" : false
          },
          {
            "name" : "Family films",
            "isDisabled" : false
          },
          {
            "name" : "Fiat",
            "isDisabled" : false
          },
          {
            "name" : "Financial advisory",
            "isDisabled" : false
          },
          {
            "name" : "Financial services",
            "isDisabled" : false
          },
          {
            "name" : "Fintech",
            "isDisabled" : false
          },
          {
            "name" : "Fitness",
            "isDisabled" : false
          },
          {
            "name" : "Free-to-play games",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Gardening",
            "isDisabled" : false
          },
          {
            "name" : "Germany political figures",
            "isDisabled" : false
          },
          {
            "name" : "Germany politics",
            "isDisabled" : false
          },
          {
            "name" : "Gladiator 2",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "GooglePay",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Grok Ai",
            "isDisabled" : false
          },
          {
            "name" : "Hip hop",
            "isDisabled" : false
          },
          {
            "name" : "Horse racing & equestrian",
            "isDisabled" : false
          },
          {
            "name" : "IBM",
            "isDisabled" : false
          },
          {
            "name" : "IOTA cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "IPOs",
            "isDisabled" : false
          },
          {
            "name" : "Industries",
            "isDisabled" : false
          },
          {
            "name" : "Inflation",
            "isDisabled" : false
          },
          {
            "name" : "Inflation in the United States",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Instagram",
            "isDisabled" : false
          },
          {
            "name" : "Investing",
            "isDisabled" : false
          },
          {
            "name" : "Jay Z",
            "isDisabled" : false
          },
          {
            "name" : "Jeff Bezos",
            "isDisabled" : false
          },
          {
            "name" : "Juventus FC",
            "isDisabled" : false
          },
          {
            "name" : "K-pop",
            "isDisabled" : false
          },
          {
            "name" : "Katy Perry",
            "isDisabled" : false
          },
          {
            "name" : "Korean series",
            "isDisabled" : false
          },
          {
            "name" : "Kraken",
            "isDisabled" : false
          },
          {
            "name" : "Loans",
            "isDisabled" : false
          },
          {
            "name" : "Luna cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Machine Gun Kelly",
            "isDisabled" : false
          },
          {
            "name" : "Manchester City",
            "isDisabled" : false
          },
          {
            "name" : "Manchester United",
            "isDisabled" : false
          },
          {
            "name" : "Medtronic",
            "isDisabled" : false
          },
          {
            "name" : "Megan Fox",
            "isDisabled" : false
          },
          {
            "name" : "Memes",
            "isDisabled" : false
          },
          {
            "name" : "Meta",
            "isDisabled" : false
          },
          {
            "name" : "Metals trading",
            "isDisabled" : false
          },
          {
            "name" : "Metaverse",
            "isDisabled" : false
          },
          {
            "name" : "Michael Jackson",
            "isDisabled" : false
          },
          {
            "name" : "Microcontrollers",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft Windows",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music industry",
            "isDisabled" : false
          },
          {
            "name" : "Music streaming service",
            "isDisabled" : false
          },
          {
            "name" : "Musical instruments",
            "isDisabled" : false
          },
          {
            "name" : "NFL players",
            "isDisabled" : false
          },
          {
            "name" : "NFT collections",
            "isDisabled" : false
          },
          {
            "name" : "NFT gaming",
            "isDisabled" : false
          },
          {
            "name" : "NFTs",
            "isDisabled" : false
          },
          {
            "name" : "NPR",
            "isDisabled" : false
          },
          {
            "name" : "New Years Resolutions",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Nicki Minaj",
            "isDisabled" : false
          },
          {
            "name" : "Nigerian Influencers",
            "isDisabled" : false
          },
          {
            "name" : "OKX",
            "isDisabled" : false
          },
          {
            "name" : "Olympic BMX",
            "isDisabled" : false
          },
          {
            "name" : "Ongoing news stories",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "Path of Exile",
            "isDisabled" : false
          },
          {
            "name" : "Pens & stationery",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Polygon",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Popcorn",
            "isDisabled" : false
          },
          {
            "name" : "Projeto Intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Pub games",
            "isDisabled" : false
          },
          {
            "name" : "Quiz games",
            "isDisabled" : false
          },
          {
            "name" : "ROG (Republic of Gamers, ASUS)",
            "isDisabled" : false
          },
          {
            "name" : "Rap",
            "isDisabled" : false
          },
          {
            "name" : "Raspberry Pi",
            "isDisabled" : false
          },
          {
            "name" : "Reign",
            "isDisabled" : false
          },
          {
            "name" : "Reign",
            "isDisabled" : false
          },
          {
            "name" : "Resident Evil",
            "isDisabled" : false
          },
          {
            "name" : "Retail industry",
            "isDisabled" : false
          },
          {
            "name" : "Retirement planning",
            "isDisabled" : false
          },
          {
            "name" : "Ripple (XRP)",
            "isDisabled" : false
          },
          {
            "name" : "Roleplaying games",
            "isDisabled" : false
          },
          {
            "name" : "S&P 500",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Seasonal cooking",
            "isDisabled" : false
          },
          {
            "name" : "Shiba Inu",
            "isDisabled" : false
          },
          {
            "name" : "Shooting games",
            "isDisabled" : false
          },
          {
            "name" : "Sky News",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Solana cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Sonic the Hedgehog",
            "isDisabled" : false
          },
          {
            "name" : "SpaceX",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports events",
            "isDisabled" : false
          },
          {
            "name" : "Squid Game",
            "isDisabled" : false
          },
          {
            "name" : "Squid Game",
            "isDisabled" : false
          },
          {
            "name" : "Starlink",
            "isDisabled" : false
          },
          {
            "name" : "Startups",
            "isDisabled" : false
          },
          {
            "name" : "Stocks & indices",
            "isDisabled" : false
          },
          {
            "name" : "Sustainability",
            "isDisabled" : false
          },
          {
            "name" : "TE Connectivity",
            "isDisabled" : false
          },
          {
            "name" : "Taxes",
            "isDisabled" : false
          },
          {
            "name" : "Tea",
            "isDisabled" : false
          },
          {
            "name" : "Tech events",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "Tesla",
            "isDisabled" : false
          },
          {
            "name" : "Tether cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Threads (Meta)",
            "isDisabled" : false
          },
          {
            "name" : "Tokyo Olympics - Cycling BMX Racing",
            "isDisabled" : false
          },
          {
            "name" : "Tom Brady",
            "isDisabled" : false
          },
          {
            "name" : "UEFA Europa League",
            "isDisabled" : false
          },
          {
            "name" : "US national news",
            "isDisabled" : false
          },
          {
            "name" : "USD Coin",
            "isDisabled" : false
          },
          {
            "name" : "United States political issues",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "UnitedHealthcare",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Violin",
            "isDisabled" : false
          },
          {
            "name" : "Visual arts",
            "isDisabled" : false
          },
          {
            "name" : "Vitalik Buterin",
            "isDisabled" : false
          },
          {
            "name" : "WWE",
            "isDisabled" : false
          },
          {
            "name" : "Web3",
            "isDisabled" : false
          },
          {
            "name" : "Work life balance",
            "isDisabled" : false
          },
          {
            "name" : "World LibertyFi",
            "isDisabled" : false
          },
          {
            "name" : "World news",
            "isDisabled" : false
          },
          {
            "name" : "Wrestling",
            "isDisabled" : false
          },
          {
            "name" : "X",
            "isDisabled" : false
          },
          {
            "name" : "X - the everything app",
            "isDisabled" : false
          },
          {
            "name" : "Yahoo!",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          },
          {
            "name" : "Zcash cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "dApps",
            "isDisabled" : false
          },
          {
            "name" : "developers",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "60 Minutes",
          "College Football",
          "Gladiator 2",
          "MLB Baseball",
          "NFL Football",
          "NHL Hockey",
          "Premier League",
          "Swarm",
          "The Invisible Thread",
          "WWE Friday Night SmackDown",
          "WWE Monday Night RAW"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]