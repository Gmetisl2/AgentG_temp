window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "149784964-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello",
            "mediaUrls" : [ ],
            "senderId" : "149784964",
            "id" : "1864923396590473662",
            "createdAt" : "2024-12-06T06:42:41.042Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1949097170-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hows your trade going?",
            "mediaUrls" : [ ],
            "senderId" : "1949097170",
            "id" : "1867937388116467952",
            "createdAt" : "2024-12-14T14:19:12.620Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello 👋",
            "mediaUrls" : [ ],
            "senderId" : "1949097170",
            "id" : "1867937365060427869",
            "createdAt" : "2024-12-14T14:19:07.126Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1704856991364206593-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi",
            "mediaUrls" : [ ],
            "senderId" : "1704856991364206593",
            "id" : "1873614796098273598",
            "createdAt" : "2024-12-30T06:19:12.155Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1731471720165564416-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "No his name is jack",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875674333181608062",
            "createdAt" : "2025-01-04T22:43:04.070Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Waaait is he Gatsby?",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875630777561706915",
            "createdAt" : "2025-01-04T19:49:59.611Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [
              {
                "senderId" : "1731471720165564416",
                "reactionKey" : "excited",
                "eventId" : "1875563077778993158",
                "createdAt" : "2025-01-04T15:20:58.696Z"
              }
            ],
            "urls" : [ ],
            "text" : "same with Daryl  from Metis - governance",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875562779295232350",
            "createdAt" : "2025-01-04T15:19:47.547Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yeah I'm pretty much weekly 1-1 contact with him",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875562725138710712",
            "createdAt" : "2025-01-04T15:19:34.656Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "He is official metis team so that's a biggie",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875562373760839742",
            "createdAt" : "2025-01-04T15:18:10.865Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "If you get quantic to promote its a big",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875562318299546011",
            "createdAt" : "2025-01-04T15:17:57.635Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think market is going to be hot that time.",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875562281725247817",
            "createdAt" : "2025-01-04T15:17:48.923Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [
              {
                "senderId" : "1731471720165564416",
                "reactionKey" : "excited",
                "eventId" : "1875562235541778436",
                "createdAt" : "2025-01-04T15:17:37.880Z"
              }
            ],
            "urls" : [ ],
            "text" : "12.01 i beta testing with some users and a week later public release",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875562055266181315",
            "createdAt" : "2025-01-04T15:16:54.931Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "but not the most active space. hoping for the best that it grows with us i guess",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561955571777562",
            "createdAt" : "2025-01-04T15:16:31.156Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "i know good stuff happy for them. Luckily there is a bit difference so we can share whatever is there to share on metis",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561881882259928",
            "createdAt" : "2025-01-04T15:16:13.601Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks. Good luck to us both 😅",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561809777979635",
            "createdAt" : "2025-01-04T15:15:56.400Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Memai is up",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561744904679633",
            "createdAt" : "2025-01-04T15:15:40.934Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "thanks again and well, good luck",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561730610200855",
            "createdAt" : "2025-01-04T15:15:37.526Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "When will the product go live?",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561722372874372",
            "createdAt" : "2025-01-04T15:15:35.555Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "will do",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561696099504491",
            "createdAt" : "2025-01-04T15:15:29.300Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "wtf",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561573244400092",
            "createdAt" : "2025-01-04T15:15:00.003Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Try him. I already vouched for you guys",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561546203722019",
            "createdAt" : "2025-01-04T15:14:53.557Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ask your friend to reach out i cannot message him",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561542340546736",
            "createdAt" : "2025-01-04T15:14:52.638Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "But nothing for him i guess",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561503321157992",
            "createdAt" : "2025-01-04T15:14:43.333Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jack got liquidated $7m on that crash too",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561479296184382",
            "createdAt" : "2025-01-04T15:14:37.602Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "well fingers crossed",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561476884144636",
            "createdAt" : "2025-01-04T15:14:37.037Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "This is why I am hoping your project thrives. To make something back. I am a small fish now too",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561385100447768",
            "createdAt" : "2025-01-04T15:14:15.326Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "not because of the platform but because of going leverage",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561362921025732",
            "createdAt" : "2025-01-04T15:14:09.860Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "lost a ton on tethys before as well",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561299087601996",
            "createdAt" : "2025-01-04T15:13:54.640Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yeah",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561205206528120",
            "createdAt" : "2025-01-04T15:13:32.255Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "They liquidated everything",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561197464072265",
            "createdAt" : "2025-01-04T15:13:30.406Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Granary is brutal",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561175393665204",
            "createdAt" : "2025-01-04T15:13:25.158Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I mean $50",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561133261910114",
            "createdAt" : "2025-01-04T15:13:15.108Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "aave liquidates slower so i have something left",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561131743343068",
            "createdAt" : "2025-01-04T15:13:14.740Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I never thought metis would go below $40",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561113397744007",
            "createdAt" : "2025-01-04T15:13:10.438Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "sorry to hear man",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561095374762459",
            "createdAt" : "2025-01-04T15:13:06.066Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It is what it is",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561074344579231",
            "createdAt" : "2025-01-04T15:13:01.062Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I over borrowed",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561053918261748",
            "createdAt" : "2025-01-04T15:12:56.186Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I got greedy",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875561024369389855",
            "createdAt" : "2025-01-04T15:12:49.139Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "fuck!",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875561012226937018",
            "createdAt" : "2025-01-04T15:12:46.241Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "under 100",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875560977929777195",
            "createdAt" : "2025-01-04T15:12:38.065Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "well I'm a small fish",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875560969713193390",
            "createdAt" : "2025-01-04T15:12:36.107Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I am ashamed to tell you but I lost 90% of my bags",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875560958694982091",
            "createdAt" : "2025-01-04T15:12:33.482Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yeah",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875560915292021197",
            "createdAt" : "2025-01-04T15:12:23.144Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How many METIS you have lost?",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875560890130718838",
            "createdAt" : "2025-01-04T15:12:17.144Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I feel you bro",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875560859185078550",
            "createdAt" : "2025-01-04T15:12:09.761Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "aave",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875560827392057409",
            "createdAt" : "2025-01-04T15:12:02.186Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I use granary",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875560788842443162",
            "createdAt" : "2025-01-04T15:11:52.985Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Shit",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875560776171450673",
            "createdAt" : "2025-01-04T15:11:49.963Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "i also went into a lend metis borrow usdc usdt cycle - leveraged there pretty much everything as i was already all in in metis",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875560721469059573",
            "createdAt" : "2025-01-04T15:11:36.919Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I want to but financial I am in a bad situation right now",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875560651529318670",
            "createdAt" : "2025-01-04T15:11:20.247Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Worse days of my life. Will never do borrowing again",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875560513268293766",
            "createdAt" : "2025-01-04T15:10:47.286Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "thank you",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875560311849177306",
            "createdAt" : "2025-01-04T15:09:59.264Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "that is exactly what happened to me",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875560304370971134",
            "createdAt" : "2025-01-04T15:09:57.477Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I can't afford 20 metis for now. I got liquidated big time on that flash crash",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875559662340526416",
            "createdAt" : "2025-01-04T15:07:24.657Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "He is the biggest whale of metis over $2M in metis I think",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875559563296174104",
            "createdAt" : "2025-01-04T15:07:00.791Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will message him",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875559498901025244",
            "createdAt" : "2025-01-04T15:06:45.460Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Try @OhmyjackEth",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875559442550493520",
            "createdAt" : "2025-01-04T15:06:32.013Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ok i just read it and as i was writing the message with copilot and it skipped a pretty important part... you would lock half of the pool for a year and other half (be whatever your contribution) for 2 years\ne.g.\nyou lock 20 metis and 25 M gMetis for a year \nand 20 metis and 25M gMetis for 2 years",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875553084912414751",
            "createdAt" : "2025-01-04T14:41:16.228Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Take your tiem and let me know. I'd advice to make your decision after the testing has been completed (12-15.01)",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875550951492264144",
            "createdAt" : "2025-01-04T14:32:47.582Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "sorry for the ling message :)\nLet me know what do you think",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875550505058844682",
            "createdAt" : "2025-01-04T14:31:01.151Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I wanted to discuss an opportunity related to our project. Since our launch on MetisForge, only about 20% of our tokens have been allocated to liquidity, though they are locked permanently. Fortunately, our team has secured enough tokens to maintain a reward treasury for one year and a team budget that we will use partially for this purpose\n\nAfter speaking with Quantic from the Metis team yesterday, he mentioned that Metis won't be able to support us by providing liquidity, even if it's on their side and locked permanently, due to the current size and metrics of our project. However, he suggested reaching out to you as you might be interested.\n\nWe propose sending you up to 10% (100M gMetis) of the total gMetis pool in batches, which you would then lock as liquidity on Hercules DEX for the minimum of one year. This would result in maximum 80 Metis being locked on Hercules on your side.\n\nTo help you make an informed decision, here are some key points:\n\nPros:\n\nFinancial Benefits:\n\nYou receive up to 10% of our supply technically for free (but locked for 1 year).\nWe are currently under a 40k market cap, offering potential for growth.\nProject Credibility:\n\nWe are CVP and DOXed to the Metis team.\nI have weekly meetings with Metis officials (Quantic and Daryl) to discuss our growth direction and how we can positively contribute to their ecosystem as well as with other AI projects in the eco.\nFuture Vision:\n\nWe have a vision that extends beyond our current scope of creating an AI agent for our project. In this vision we are strategic partner of Metis offering a full blown service of Community reward program within and outside of the ecosystem.\nAs a result of our discussions with Metis, we have decided to offer a new service, Agent as a Service AND go open-source at the same time. This will ensure more potential growth for us but also a more active presence in the Metis ecosystem and help it grow.\n\nCons / Risks:\n\nFinancial Risks:\n\nYou would need to lock your assets (Metis) for 1 year.\nInevitably, we are in crypto, so there is a risk of the market going sideways or lower, which could result in some loss or no profit.\nProject Development:\n\nOur product is in the development/testing phase, which could lead to delays in delivery or negative user reactions. \n\nWe are doing everything to mitigate these risks, but for the sake of transparency, we wanted to share them.\n\nThis message will be sent to one more account for the time being. Our pool for this initiative is 100M, with a preference for an equal split between interested parties.",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875550405582827814",
            "createdAt" : "2025-01-04T14:30:37.454Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello ser, I stay anonymous even in calls. Can you write it down?",
            "mediaUrls" : [ ],
            "senderId" : "1731471720165564416",
            "id" : "1875370748136878227",
            "createdAt" : "2025-01-04T02:36:43.747Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1731471720165564416",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi there\nI wrote you on telegram but just to make sure is this you: @realmetishero\n-&gt;\nI had a discussion with Quantic and he recommended me to reach out to you about a proposal.\nWould you be interested in/ able to jump on a call (can be weekend or next week)?",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1875323874092494925",
            "createdAt" : "2025-01-03T23:30:28.120Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1780293601538285568-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello",
            "mediaUrls" : [ ],
            "senderId" : "1780293601538285568",
            "id" : "1875301597216936198",
            "createdAt" : "2025-01-03T22:01:56.884Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1854114889041874944-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1854114889041874944",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi\nFirst let me start with that I’m a big fan of your project! I think the new way of launching tokens are through platforms like yours to increase trust is the way to go and hopefully we will have different season this time than the last one on Metis with all the rugs.\n\nThat being said we made a decision to launch our token gMetis on your platform\nOther than having the benefit of an overused term as our domain we also have a quite in depth documentation and an autonomous agent in development to handle both communication and on chain transactions (rewards) leaving only the infra as the human task - that is our plan\n\nI was wondering if you’d be open to the idea of announcing our launch giving more visibility for us\n\nThanks in advance \n(And let me know if you prefer to talk on tg instead)",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1867146087506825561",
            "createdAt" : "2024-12-12T09:54:51.929Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1854286882387156992-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey we following each other now! Great 🤗 Wondering would you also follow my fav comic @CandyVigilantE. 😊",
            "mediaUrls" : [ ],
            "senderId" : "1854286882387156992",
            "id" : "1871878760800326044",
            "createdAt" : "2024-12-25T11:20:49.104Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1856948242917015552-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1856948242917015552",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Also we just launched on MetisForge. Even though its nt filling up as immediately as MEMAI I'm happy with the progress :)",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1867400182867866040",
            "createdAt" : "2024-12-13T02:44:32.903Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1856948242917015552",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/NUv6rMGu4g",
                "expanded" : "http://docs.gmetis.io",
                "display" : "docs.gmetis.io"
              }
            ],
            "text" : "HI there\nJust wanted to shortly introduce our project in case you'd find it interesting and would like to post it.\n\nyou can find out everything in our docs: https://t.co/NUv6rMGu4g but to give you a taste please have a look below.\n\nPlease let me know what do you think.\n\nIntroducing gMetis gMetis is an innovative project that merges the fun of meme tokens with the practical benefits of AI-driven community management. Built on the Metis Layer 2 of Ethereum, gMetis aims to create a lively and interactive community where members are rewarded for their participation and engagement.",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1867400009999954336",
            "createdAt" : "2024-12-13T02:43:51.783Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "2467704512-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Are you actively involved in the crypto market?",
            "mediaUrls" : [ ],
            "senderId" : "2467704512",
            "id" : "1866543866049884642",
            "createdAt" : "2024-12-10T18:01:51.069Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sounds good!",
            "mediaUrls" : [ ],
            "senderId" : "2467704512",
            "id" : "1866543819203744152",
            "createdAt" : "2024-12-10T18:01:39.898Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "2467704512",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi there\nAll good\n(I’m not a bot)\n:)",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1866401994073588158",
            "createdAt" : "2024-12-10T08:38:06.153Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello there! Hows it going?",
            "mediaUrls" : [ ],
            "senderId" : "2467704512",
            "id" : "1864451735512646021",
            "createdAt" : "2024-12-04T23:28:28.278Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1423972643250884617-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "No mattter Chief",
            "mediaUrls" : [ ],
            "senderId" : "1423972643250884617",
            "id" : "1870009497386647702",
            "createdAt" : "2024-12-20T07:33:01.986Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1423972643250884617",
            "reactions" : [
              {
                "senderId" : "1423972643250884617",
                "reactionKey" : "like",
                "eventId" : "1870009468475584516",
                "createdAt" : "2024-12-20T07:32:55.048Z"
              }
            ],
            "urls" : [ ],
            "text" : "Hi Nano,\n\nThank you for reaching out and for your interest in joining our team. We truly appreciate your enthusiasm and the work you've done within the Metis ecosystem.\n\nAt this time, we already have a community manager in place - DefibroTM and, unfortunately, we don't have the budget to bring on another person in that role. \n\nThank you again for your kind offer and support. \n\nHoping to see you around",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1869857529930346755",
            "createdAt" : "2024-12-19T21:29:10.114Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I anticipate your reply",
            "mediaUrls" : [ ],
            "senderId" : "1423972643250884617",
            "id" : "1869804023508865421",
            "createdAt" : "2024-12-19T17:56:33.196Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Excited your project is coming to Metis \nI’m Nano, a Metis contributor\nI’m the author of the series “Métis L2 Exposed” and also a member of the Metis cabal (Mabal)\n\nHeard you speak on the CEG space yesterday \n\nJust wanna pitch and let you know that I’m down for a community manager or moderator role in your team.\nI’m a community manager on a Metis project already &amp; I’m known in the ecosystem. You can verify from Cobi\n\nHope you give me a chance to contribute to gMetis’s journey",
            "mediaUrls" : [ ],
            "senderId" : "1423972643250884617",
            "id" : "1869803978609046021",
            "createdAt" : "2024-12-19T17:56:22.487Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1423972643250884617",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "gMetis friend",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1869637829636370787",
            "createdAt" : "2024-12-19T06:56:09.469Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "GMetis 🩵🌿",
            "mediaUrls" : [ ],
            "senderId" : "1423972643250884617",
            "id" : "1869629409059074213",
            "createdAt" : "2024-12-19T06:22:41.843Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1439548673495547908-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [
              {
                "senderId" : "1864044295654912000",
                "reactionKey" : "like",
                "eventId" : "1877800123574403072",
                "createdAt" : "2025-01-10T19:30:11.964Z"
              }
            ],
            "urls" : [ ],
            "text" : "for sure I'll review and help you",
            "mediaUrls" : [ ],
            "senderId" : "1439548673495547908",
            "id" : "1877787719826391430",
            "createdAt" : "2025-01-10T18:40:54.706Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1439548673495547908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I applied yesterday :) as you said whether we get it or not it wont hurt",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1877761679129202953",
            "createdAt" : "2025-01-10T16:57:26.125Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1439548673495547908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I wont be able to make it due to personal stuff",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1877761473436623277",
            "createdAt" : "2025-01-10T16:56:37.079Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1439548673495547908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "will you record the next session on Retro grants?",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1877761434118983988",
            "createdAt" : "2025-01-10T16:56:27.705Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1439548673495547908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hey",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1877761364829393063",
            "createdAt" : "2025-01-10T16:56:11.188Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1471253793631264772-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Let's continue with our discussion on telegram 👍",
            "mediaUrls" : [ ],
            "senderId" : "1471253793631264772",
            "id" : "1867567032474251587",
            "createdAt" : "2024-12-13T13:47:32.955Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Good day fam \nThanks for the response",
            "mediaUrls" : [ ],
            "senderId" : "1471253793631264772",
            "id" : "1867566999997493544",
            "createdAt" : "2024-12-13T13:47:25.211Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1471253793631264772",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "What is the question? :)",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1867290074603565306",
            "createdAt" : "2024-12-12T19:27:01.048Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1471253793631264772",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Happy to hear that you like what you see",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1867289965245149252",
            "createdAt" : "2024-12-12T19:26:34.981Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1471253793631264772",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey there",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1867289915232596110",
            "createdAt" : "2024-12-12T19:26:23.096Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1504730074486038551-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1504730074486038551",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "gMetis friend\nThank you so much for your kind words and congratulations. It's great to hear that you found the CEG AMA session informative and that you're intrigued by what we are building.\n\nWe truly appreciate your support and interest in collaborating with us as an ambassador and content creator. However, at this time, we are not looking to expand our team. We will definitely keep your offer in mind for future opportunities.\n\nThank you again for reaching out and for your enthusiasm. We wish you all the best in your endeavors!",
            "mediaUrls" : [ ],
            "senderId" : "1864044295654912000",
            "id" : "1869568460604461466",
            "createdAt" : "2024-12-19T02:20:30.619Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Gm, Gmetis!\n\nFirst, congratulations on becoming the second AI agent meme to complete its bonding curve an awesome milestone!  \n\nI wasn’t aware of Gmetis until I noticed your account following me. Out of curiosity, I checked your X page but didn’t find much information about what Gmetis is building. \n\nThat said, I was super excited to hear about your participation in the CEG AMA session! While I missed the space, I now have about 80% clarity on what Gmetis is all about, after listening to the space and I’m even more intrigued.  \n\nAs a strategic content creator and advocate in the ecosystem, I’d love to explore the possibility of collaborating with Gmetis as an ambassador and content creator. Let me know if this interests you.",
            "mediaUrls" : [ ],
            "senderId" : "1504730074486038551",
            "id" : "1869456049582866714",
            "createdAt" : "2024-12-18T18:53:49.765Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1534925673734852609-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I’m a marketing head, mod, part time trader, and Web3 ambassador with experience in launching campaigns, growing projects, and keeping communities active and excited. Memecoins are all about vibes and virality and I’ve got both covered. Let’s send this project to the moon together.\n🔥",
            "mediaUrls" : [ ],
            "senderId" : "1534925673734852609",
            "id" : "1868725612959191383",
            "createdAt" : "2024-12-16T18:31:20.078Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey team! I’m Arabcoin 🌿community builder, marketer, and Web3 hype machine. I’ve been diving deep into the Metis ecosystem and I love what you’re doing with this memecoin. I’m all about driving engagement, creating buzz, and growing solid communities. If you need someone to bring the hype and deliver results, let’s make magic happen.",
            "mediaUrls" : [ ],
            "senderId" : "1534925673734852609",
            "id" : "1868725373321560554",
            "createdAt" : "2024-12-16T18:30:22.948Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello and Gmetis👀🌿",
            "mediaUrls" : [ ],
            "senderId" : "1534925673734852609",
            "id" : "1868725261422018645",
            "createdAt" : "2024-12-16T18:29:56.253Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1580727636954710016-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey! Thank you for your follow.\nYou need to go listen to this dope special indie country singer @Rsfmusic.\nI'd really appreciate it if you would follow him, help grow the awareness for him 🙏🎸\nThanks so much 🙂",
            "mediaUrls" : [ ],
            "senderId" : "1580727636954710016",
            "id" : "1865366372269596923",
            "createdAt" : "2024-12-07T12:02:54.698Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1627573221154250752-1864044295654912000",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1864044295654912000",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello, thank you for your attention, where are you from?",
            "mediaUrls" : [ ],
            "senderId" : "1627573221154250752",
            "id" : "1865234286992908668",
            "createdAt" : "2024-12-07T03:18:03.088Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  }
]