window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "x@gmetis.io",
      "createdVia" : "oauth:3033300",
      "username" : "gMetisl2",
      "accountId" : "1864044295654912000",
      "createdAt" : "2024-12-03T20:29:38.075Z",
      "accountDisplayName" : "gMetis 🌿"
    }
  }
]