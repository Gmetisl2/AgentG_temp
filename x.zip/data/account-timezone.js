window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1864044295654912000"
    }
  }
]